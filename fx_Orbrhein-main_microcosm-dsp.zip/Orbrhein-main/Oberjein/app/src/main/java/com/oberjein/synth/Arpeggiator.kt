package com.oberjein.synth

enum class ArpDirection { UP, DOWN, UP_DOWN, DOWN_UP, AS_PLAYED, RANDOM }
enum class ArpScale(val intervals: IntArray) {
    CHROMATIC(intArrayOf(0,1,2,3,4,5,6,7,8,9,10,11)),
    MAJOR(intArrayOf(0,2,4,5,7,9,11)),
    MINOR(intArrayOf(0,2,3,5,7,8,10)),
    DORIAN(intArrayOf(0,2,3,5,7,9,10)),
    PENTATONIC(intArrayOf(0,2,4,7,9)),
    BLUES(intArrayOf(0,3,5,6,7,10)),
    HARMONIC_MINOR(intArrayOf(0,2,3,5,7,8,11))
}

data class ArpStep(
    val enabled: Boolean = true,
    val probability: Float = 1f,
    val ratchets: Int = 1,
    val octave: Int = 0,
    val velocity: Float = 1f,
    val gate: Float = 0.8f,
    val shift: Int = 0
)

data class ArpModRoute(val source: String, val target: Int, val amount: Float, val bipolar: Boolean = false)

data class ArpConfig(
    val enabled: Boolean = false,
    val hold: Boolean = false,
    val bpm: Float = 120f,
    val division: Int = 4,
    val direction: ArpDirection = ArpDirection.UP,
    val octaveRange: Int = 1,
    val scale: ArpScale = ArpScale.CHROMATIC,
    val root: Int = 0,
    val chordSize: Int = 1,
    val strumMs: Int = 0,
    val intervalShift: Int = 0,
    val randomMode: Boolean = false,
    val evolve: Boolean = false,
    val loopLength: Int = 16,
    val humanize: Float = 0f,
    val steps: List<ArpStep> = List(64) { ArpStep() },
    val routes: List<ArpModRoute> = emptyList()
)

/**
 * The 64-step sequencer now runs inside the audio callback (cpp/arp.h) on a sample clock, so the UI thread can
 * no longer delay or drift the notes. This object only converts [ArpConfig] to the flat arrays the JNI expects
 * and reads status back.
 */
object ArpNative {
    private val sourceNames = listOf("STEP", "VELOCITY", "PROBABILITY", "RANDOM", "PITCH")
    private const val STEP_FIELDS = 7
    private const val MAX_ROUTES = 16
    private val ints = IntArray(14)
    private val floats = FloatArray(2)
    private val steps = FloatArray(64 * STEP_FIELDS)
    private val routes = FloatArray(MAX_ROUTES * 4)
    private val statusBuf = FloatArray(3)
    private val stepsBuf = FloatArray(64 * STEP_FIELDS)

    data class Status(val running: Boolean, val step: Int, val mutations: Int)

    @Synchronized
    fun push(c: ArpConfig) {
        ints[0] = if (c.enabled) 1 else 0; ints[1] = if (c.hold) 1 else 0
        ints[2] = if (c.randomMode) 1 else 0; ints[3] = if (c.evolve) 1 else 0
        ints[4] = c.division; ints[5] = c.direction.ordinal; ints[6] = c.octaveRange; ints[7] = c.scale.ordinal
        ints[8] = c.root; ints[9] = c.chordSize; ints[10] = c.strumMs; ints[11] = c.intervalShift
        ints[12] = c.loopLength
        val routeList = c.routes.take(MAX_ROUTES)
        ints[13] = routeList.size
        floats[0] = c.bpm; floats[1] = c.humanize
        for (i in 0 until 64) {
            val s = c.steps.getOrNull(i) ?: ArpStep()
            val b = i * STEP_FIELDS
            steps[b] = if (s.enabled) 1f else 0f; steps[b + 1] = s.probability; steps[b + 2] = s.ratchets.toFloat()
            steps[b + 3] = s.octave.toFloat(); steps[b + 4] = s.velocity; steps[b + 5] = s.gate; steps[b + 6] = s.shift.toFloat()
        }
        routeList.forEachIndexed { i, r ->
            routes[i * 4] = sourceNames.indexOf(r.source.uppercase()).coerceAtLeast(0).toFloat()
            routes[i * 4 + 1] = r.target.toFloat(); routes[i * 4 + 2] = r.amount; routes[i * 4 + 3] = if (r.bipolar) 1f else 0f
        }
        SynthEngine.nativeArpConfig(ints, floats, steps, routes)
    }

    @Synchronized
    fun status(): Status {
        SynthEngine.nativeArpStatus(statusBuf)
        return Status(statusBuf[0] > 0.5f, statusBuf[1].toInt(), statusBuf[2].toInt())
    }

    /** The pattern as the audio thread currently holds it (it may have been mutated by RANDOM / EVOLVE). */
    @Synchronized
    fun readSteps(): List<ArpStep> {
        SynthEngine.nativeArpSteps(stepsBuf)
        return List(64) { i ->
            val b = i * STEP_FIELDS
            ArpStep(stepsBuf[b] > 0.5f, stepsBuf[b + 1], stepsBuf[b + 2].toInt(), stepsBuf[b + 3].toInt(), stepsBuf[b + 4], stepsBuf[b + 5], stepsBuf[b + 6].toInt())
        }
    }
}
