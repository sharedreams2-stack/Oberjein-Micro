package com.oberjein.synth

import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper

/** MIDI 1.0 virtual-device bridge for inter-app routing. */
object MidiBridge {
    @Volatile private var viewModel: SynthViewModel? = null
    @Volatile private var outputs: Array<MidiReceiver> = emptyArray()
    private val main = Handler(Looper.getMainLooper())

    fun attach(vm: SynthViewModel) { viewModel = vm }
    fun currentViewModel(): SynthViewModel? = viewModel
    fun stopPlayback() { viewModel?.let { it.pauseArpeggiator(); it.panic() } }
    fun detach(vm: SynthViewModel) { if (viewModel === vm) viewModel = null }
    fun setOutputs(receivers: Array<MidiReceiver>) { outputs = receivers }
    fun hasOutputs(): Boolean = outputs.isNotEmpty()

    fun send(bytes: ByteArray) {
        val now = System.nanoTime()
        outputs.forEach { receiver -> runCatching { receiver.send(bytes, 0, bytes.size, now) } }
    }

    /**
     * Called on the MIDI receive thread. Notes and pitch bend go straight to the native engine (lock-free, no UI
     * state involved), so a busy UI thread can no longer delay an external keyboard. Only CCs, which update
     * Compose state, are handed to the main thread.
     */
    fun receive(bytes: ByteArray, offset: Int, count: Int) {
        val vm = viewModel ?: return
        val end = (offset + count).coerceAtMost(bytes.size)
        var i = offset
        while (i < end) {
            val status = bytes[i].toInt() and 0xFF
            if (status < 0x80) { i++; continue }
            val kind = status and 0xF0
            val length = when (kind) { 0xC0, 0xD0 -> 2; 0xF0 -> 1; else -> 3 }
            if (i + length > end) break
            val d1 = if (length > 1) bytes[i + 1].toInt() and 0x7F else 0
            val d2 = if (length > 2) bytes[i + 2].toInt() and 0x7F else 0
            when (kind) {
                0x90 -> if (d2 > 0) vm.midiNoteOn(d1, d2 / 127f) else vm.midiNoteOff(d1)
                0x80 -> vm.midiNoteOff(d1)
                0xB0 -> main.post { vm.onMidiCC(d1, d2) }
                0xE0 -> vm.pitchBend((((d2 shl 7) or d1) - 8192) / 8192f)
            }
            i += length
        }
    }

    fun noteOn(note: Int, velocity: Float) {
        val vel = (velocity.coerceIn(0f,1f) * 127f).toInt()
        send(byteArrayOf(0x90.toByte(), (note and 0x7F).toByte(), vel.toByte()))
    }
    fun noteOff(note: Int) = send(byteArrayOf(0x80.toByte(), (note and 0x7F).toByte(), 0))
}
