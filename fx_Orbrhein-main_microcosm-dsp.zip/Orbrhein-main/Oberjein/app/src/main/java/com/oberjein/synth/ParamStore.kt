package com.oberjein.synth

import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf

/**
 * One Compose state per parameter. With a single mutableStateListOf every composable that reads ANY element
 * depends on the whole list, so dragging one knob recomposed all ~60 knobs, toggles and the cycle buttons on every
 * touch event. Here only what reads that parameter is invalidated.
 */
class ParamStore(initial: List<Float>) {
    private val states: Array<MutableFloatState> = Array(initial.size) { mutableFloatStateOf(initial[it]) }
    val size: Int get() = states.size
    val indices: IntRange get() = states.indices
    operator fun get(index: Int): Float = states[index].floatValue
    operator fun set(index: Int, value: Float) { states[index].floatValue = value }
    fun toList(): List<Float> = List(states.size) { states[it].floatValue }
    fun forEachIndexed(action: (Int, Float) -> Unit) { for (i in states.indices) action(i, states[i].floatValue) }
}
