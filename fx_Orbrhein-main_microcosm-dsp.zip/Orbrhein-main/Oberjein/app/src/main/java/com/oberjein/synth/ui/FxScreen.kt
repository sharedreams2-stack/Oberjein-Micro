package com.oberjein.synth.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.PressGestureScope
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.FX_ACTIVITY_HELP
import com.oberjein.synth.FX_EFFECT_NAMES
import com.oberjein.synth.FX_REPEATS_HELP
import com.oberjein.synth.FX_REVERB_MODES
import com.oberjein.synth.FX_SUBDIVISIONS
import com.oberjein.synth.FX_VARIATIONS
import com.oberjein.synth.FX_VARIATION_HELP
import com.oberjein.synth.FxFamily
import com.oberjein.synth.FxLoop
import com.oberjein.synth.FxP
import com.oberjein.synth.P
import com.oberjein.synth.SynthEngine
import com.oberjein.synth.SynthViewModel
import com.oberjein.synth.fxFamilyOf
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.delay

// One colour per family, as on the Microcosm panel.
private val FamilyColors = listOf(Color(0xFF5B8DEF), Color(0xFF3FC1E0), Color(0xFFE8664A), Color(0xFFE8A33D))
private val BankColors = listOf(Color(0xFFFF4B52), Color(0xFFE8C23D), Color(0xFF4FD07A), Color(0xFF3AA0FF))
private val LampGreen = Color(0xFF4FD07A)
private val Key = Color(0xFF2A2D31)

private val expTargets = listOf(
    FxP.ACTIVITY to "ACTIVITY", FxP.SHAPE to "SHAPE", FxP.FILTER to "FILTER",
    FxP.MIX to "MIX", FxP.REPEATS to "REPEATS", FxP.SPACE to "SPACE", FxP.LOOP_LEVEL to "LOOP LEVEL"
)

private fun pct(x: Float) = "${(x * 100f).roundToInt()}%"
private fun f1(fmt: String, x: Float) = String.format(java.util.Locale.US, fmt, x)

@Composable
fun FxScreen(vm: SynthViewModel) {
    val v = vm.fxValues
    val effect = (v[FxP.EFFECT] * 10f).roundToInt().coerceIn(0, 10)
    val variation = (v[FxP.VARIATION] * 3f).roundToInt().coerceIn(0, 3)
    val tint = FamilyColors[fxFamilyOf(effect).ordinal]
    var shift by remember { mutableStateOf(false) }
    var syncArp by remember { mutableStateOf(false) }

    // Live status (looper state/position, meters, beat) comes from the audio thread.
    LaunchedEffect(Unit) {
        val buf = FloatArray(9)
        while (true) {
            SynthEngine.nativeFxReadStatus(buf)
            vm.updateFxStatus(buf)
            delay(50)
        }
    }
    // Optional: follow the Super Arp tempo.
    LaunchedEffect(syncArp, vm.arpConfig.bpm) {
        if (syncArp) vm.setFx(FxP.TEMPO, vm.arpConfig.bpm, undo = false)
    }

    Column(
        Modifier.fillMaxSize().background(Chassis).verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        FxHeader(vm, tint)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1.25f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                EffectSelector(vm, effect, variation, tint)
                KnobPanel(vm, shift, { shift = it }, effect, variation, tint)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PerformancePanel(vm, tint, syncArp) { syncArp = it }
                LooperPanel(vm, tint)
                PresetPanel(vm, tint)
                GlobalPanel(vm, tint)
            }
        }
    }
}

// ------------------------------------------------------------------------------------ header
@Composable
private fun FxHeader(vm: SynthViewModel, tint: Color) {
    val on = vm.fxValues[FxP.ENABLE] > 0.5f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(Panel).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column {
            Text("OBERJEIN / FX", color = tint, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Text("MICRO LOOP • GRANULES • GLITCH • MULTIDELAY", color = Dim, fontSize = 7.sp)
        }
        Spacer(Modifier.weight(1f))
        val st = vm.fxStatus
        Column(Modifier.width(96.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            MeterBar("IN", st.inPeak, tint)
            MeterBar("OUT", st.outPeak, tint)
        }
        FxChip(if (on) "FX ON" else "BYPASS", on, tint, { vm.setFx(FxP.ENABLE, if (on) 0f else 1f) }, Modifier.width(72.dp).height(30.dp))
        FxChip("SYNTH", false, tint, { vm.setFxPage(false) }, Modifier.width(58.dp).height(30.dp))
        FxChip("SUPER ARP", false, tint, { vm.setArpPage(true) }, Modifier.width(74.dp).height(30.dp))
    }
}

@Composable
private fun MeterBar(label: String, peak: Float, tint: Color) {
    val level = sqrt(peak.coerceIn(0f, 1f))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Dim, fontSize = 6.sp, modifier = Modifier.width(18.dp))
        Canvas(Modifier.weight(1f).height(5.dp)) {
            drawRect(Color(0xFF2A2D31), size = size)
            drawRect(if (peak > 0.95f) LedRed else tint, size = Size(size.width * level, size.height))
        }
    }
}

// ------------------------------------------------------------------------- effect selection
@Composable
private fun EffectSelector(vm: SynthViewModel, effect: Int, variation: Int, tint: Color) {
    FxCard("EFFECT • 11 ALGORITHMS × 4 VARIATIONS", tint) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            FxFamily.values().forEach { fam ->
                val col = FamilyColors[fam.ordinal]
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(fam.title, color = col, fontSize = 7.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    fam.effects.forEach { e ->
                        FxChip(FX_EFFECT_NAMES[e], effect == e, col, { vm.selectFxEffect(e, variation) }, Modifier.fillMaxWidth())
                    }
                }
            }
        }
        // The four "indicator lights": variation A-D of the selected effect
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            FX_VARIATIONS.forEachIndexed { i, name ->
                val sel = variation == i
                Box(
                    Modifier.weight(1f).height(30.dp).clip(RoundedCornerShape(5.dp))
                        .background(if (sel) Brush.verticalGradient(listOf(tint, tint.copy(alpha = 0.55f))) else Brush.verticalGradient(listOf(Color(0xFF34383D), Color(0xFF1E2023))))
                        .clickable { vm.selectFxEffect(effect, i) },
                    contentAlignment = Alignment.Center
                ) { Text(name, color = if (sel) Color.Black else Dim, fontSize = 13.sp, fontWeight = FontWeight.Black) }
            }
        }
        Text(FX_VARIATION_HELP[effect][variation], color = Cream, fontSize = 9.sp, maxLines = 2)
        Text("ACTIVITY: ${FX_ACTIVITY_HELP[effect]}  •  REPEATS: ${FX_REPEATS_HELP[effect]}", color = Dim, fontSize = 7.sp, maxLines = 2)
    }
}

// ------------------------------------------------------------------------------------ knobs
private class KSpec(
    val label: String, val value: Float, val readout: String,
    val steps: Int = 0, val enabled: Boolean = true, val reset: Float? = null,
    val onChange: (Float) -> Unit
)

@Composable
private fun KnobPanel(vm: SynthViewModel, shift: Boolean, onShift: (Boolean) -> Unit, effect: Int, variation: Int, tint: Color) {
    val v = vm.fxValues
    val tempoMode = v[FxP.TEMPO_MODE] > 0.5f
    val subIdx = (v[FxP.TIME] * 5f).roundToInt().coerceIn(0, 5)
    val reverbIdx = (v[FxP.REVERB_MODE] * 3f).roundToInt().coerceIn(0, 3)
    val loopSpeed = if (abs(v[FxP.LOOP_SPEED] - 0.5f) < 0.02f) 1f else 4f.pow((v[FxP.LOOP_SPEED] - 0.5f) * 2f)

    fun live(id: Int): (Float) -> Unit = { vm.setFx(id, it, undo = false) }

    val primary = listOf(
        KSpec("ACTIVITY", v[FxP.ACTIVITY], pct(v[FxP.ACTIVITY]), reset = 0.4f, onChange = live(FxP.ACTIVITY)),
        KSpec("SHAPE", v[FxP.SHAPE], pct(v[FxP.SHAPE]), reset = 0.5f, onChange = live(FxP.SHAPE)),
        KSpec("FILTER", v[FxP.FILTER], if (v[FxP.FILTER] >= 0.99f) "OFF" else pct(v[FxP.FILTER]), reset = 1f, onChange = live(FxP.FILTER)),
        KSpec("MIX", v[FxP.MIX], pct(v[FxP.MIX]), reset = 0.35f, onChange = live(FxP.MIX)),
        if (tempoMode)
            KSpec("TEMPO", ((v[FxP.TEMPO] - 30f) / 270f).coerceIn(0f, 1f), f1("%.0f BPM", v[FxP.TEMPO]), reset = (120f - 30f) / 270f,
                onChange = { vm.setFx(FxP.TEMPO, 30f + it * 270f, undo = false) })
        else
            KSpec("TIME", v[FxP.TIME], FX_SUBDIVISIONS[subIdx], steps = 5, reset = 0.4f, onChange = live(FxP.TIME)),
        KSpec("REPEATS", v[FxP.REPEATS], pct(v[FxP.REPEATS]), reset = 0.35f, onChange = live(FxP.REPEATS)),
        KSpec("SPACE", v[FxP.SPACE], pct(v[FxP.SPACE]), reset = 0.25f, onChange = live(FxP.SPACE)),
        KSpec("LOOP LEVEL", v[FxP.LOOP_LEVEL], pct(v[FxP.LOOP_LEVEL]), reset = 0.7f, onChange = live(FxP.LOOP_LEVEL))
    )
    val secondary = listOf(
        KSpec("—", 0f, "NO SHIFT", enabled = false, onChange = {}),
        KSpec("MOD RATE", v[FxP.PITCH_RATE], f1("%.1f Hz", 0.1f * 80f.pow(v[FxP.PITCH_RATE])), reset = 0.35f, onChange = live(FxP.PITCH_RATE)),
        KSpec("RESONANCE", v[FxP.RESONANCE], pct(v[FxP.RESONANCE]), reset = 0.2f, onChange = live(FxP.RESONANCE)),
        KSpec("FX VOLUME", v[FxP.FX_MASTER], pct(v[FxP.FX_MASTER]), reset = 0.8f, onChange = live(FxP.FX_MASTER)),
        KSpec("LOOP SPEED", v[FxP.LOOP_SPEED], f1("%.2fx", loopSpeed), reset = 0.5f, onChange = live(FxP.LOOP_SPEED)),
        KSpec("MOD DEPTH", v[FxP.PITCH_DEPTH], pct(v[FxP.PITCH_DEPTH]), reset = 0f, onChange = live(FxP.PITCH_DEPTH)),
        KSpec("REVERB", v[FxP.REVERB_MODE], listOf("A ROOM", "B DARK", "C HALL", "D AMBI")[reverbIdx], steps = 3, reset = 0f, onChange = live(FxP.REVERB_MODE)),
        KSpec("LOOP FADE", v[FxP.LOOP_FADE], f1("%.2f s", 0.005f * 800f.pow(v[FxP.LOOP_FADE])), reset = 0.4f, onChange = live(FxP.LOOP_FADE))
    )
    val specs = if (shift) secondary else primary
    val knobTint = if (shift) Iris else tint

    FxCard(if (shift) "SECONDARY CONTROLS  (SHIFT)" else "PRIMARY CONTROLS", knobTint) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FxChip("SHIFT", shift, Iris, { onShift(!shift) }, Modifier.width(64.dp).height(26.dp))
            Text(if (shift) "Mod rate/depth • resonance • FX volume • reverb mode • loop speed/fade" else "Double-tap a knob to reset it", color = Dim, fontSize = 7.sp, modifier = Modifier.weight(1f), maxLines = 2)
            FxChip("FACTORY", false, tint, { vm.applyFxFactory(effect, variation) }, Modifier.width(66.dp).height(26.dp))
        }
        for (row in 0..1) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (col in 0..3) {
                    val k = specs[row * 4 + col]
                    FxKnob(k.label, k.readout, k.value, knobTint, k.onChange, steps = k.steps, enabled = k.enabled, resetTo = k.reset, onStart = { vm.beginFxEdit() })
                }
            }
        }
    }
}

@Composable
private fun FxKnob(
    label: String, readout: String, value: Float, tint: Color, onChange: (Float) -> Unit,
    modifier: Modifier = Modifier, steps: Int = 0, enabled: Boolean = true, resetTo: Float? = null, onStart: () -> Unit = {}
) {
    val current by rememberUpdatedState(value)
    val callback by rememberUpdatedState(onChange)
    val started by rememberUpdatedState(onStart)
    Column(modifier.width(66.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(54.dp)
                .pointerInput(enabled, resetTo) {
                    detectTapGestures(onDoubleTap = { if (enabled && resetTo != null) { started(); callback(resetTo) } })
                }
                .pointerInput(enabled, steps) {
                    if (!enabled) return@pointerInput
                    var acc = 0f
                    val range = if (steps > 0) 70f else 220f
                    detectVerticalDragGestures(onDragStart = { acc = current; started() }) { change, drag ->
                        change.consume()
                        acc = (acc - drag / range).coerceIn(0f, 1f)
                        callback(if (steps > 0) (acc * steps).roundToInt() / steps.toFloat() else acc)
                    }
                }
        ) {
            val radius = size.minDimension * 0.40f
            val alpha = if (enabled) 1f else 0.3f
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF73777D), Color(0xFF30343A), Color(0xFF111316)),
                    center = Offset(size.width * 0.35f, size.height * 0.28f), radius = size.minDimension * 0.78f),
                radius, center
            )
            drawCircle(Color(0xFF08090B), radius, center, style = Stroke(1.2.dp.toPx()))
            val topLeft = Offset(2.dp.toPx(), 2.dp.toPx())
            val arcSize = Size(size.width - 4.dp.toPx(), size.height - 4.dp.toPx())
            drawArc(Color(0xFF45494F), 135f, 270f, false, topLeft, arcSize, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))
            drawArc(tint.copy(alpha = alpha), 135f, 270f * value, false, topLeft, arcSize, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))
            val angle = Math.toRadians((135f + 270f * value).toDouble())
            val dir = Offset(cos(angle).toFloat(), sin(angle).toFloat())
            drawLine(Color(0xFFF4F0E8).copy(alpha = alpha), center + dir * (radius * 0.20f), center + dir * (radius * 0.78f),
                strokeWidth = 2.2.dp.toPx(), cap = StrokeCap.Round)
            if (steps > 0) {
                for (i in 0..steps) {
                    val a = Math.toRadians(135.0 + 270.0 * i / steps)
                    drawCircle(Color(0xFF9EA3A9), 1.3.dp.toPx(), center + Offset(cos(a).toFloat(), sin(a).toFloat()) * (size.minDimension * 0.5f - 0.5.dp.toPx()))
                }
            }
        }
        Text(readout, fontSize = 8.sp, color = if (enabled) tint else Dim, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, fontSize = 8.sp, color = if (enabled) Cream else Dim, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------------------ performance
@Composable
private fun PerformancePanel(vm: SynthViewModel, tint: Color, syncArp: Boolean, onSync: (Boolean) -> Unit) {
    val v = vm.fxValues
    val st = vm.fxStatus
    val tempoMode = v[FxP.TEMPO_MODE] > 0.5f
    FxCard("PERFORMANCE", tint) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FxPad(
                "HOLD", if (vm.fxHoldMomentary) "press & hold" else if (st.hold) "FROZEN" else "tap to freeze",
                vm.fxHoldActive || st.hold, tint, Modifier.weight(1f).height(54.dp)
            ) {
                if (vm.fxHoldMomentary) { vm.setFxHold(true); tryAwaitRelease(); vm.setFxHold(false) } else vm.toggleFxHold()
            }
            FxPad(
                "TAP", f1("%.1f BPM", v[FxP.TEMPO]), st.beatPhase < 0.16f && v[FxP.ENABLE] > 0.5f, tint, Modifier.weight(1f).height(54.dp)
            ) { vm.tapFxTempo() }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            FxChip("−", false, tint, { vm.setFx(FxP.TEMPO, v[FxP.TEMPO] - 1f) }, Modifier.width(30.dp))
            FxChip("+", false, tint, { vm.setFx(FxP.TEMPO, v[FxP.TEMPO] + 1f) }, Modifier.width(30.dp))
            FxChip(if (tempoMode) "TIME = BPM" else "TIME = SUBDIV", tempoMode, tint, { vm.setFx(FxP.TEMPO_MODE, if (tempoMode) 0f else 1f) }, Modifier.weight(1f))
            FxChip("SYNC ARP", syncArp, tint, { onSync(!syncArp) }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FxChip(if (v[FxP.REVERSE] > 0.5f) "◀ REV" else "FWD ▶", v[FxP.REVERSE] > 0.5f, tint, { vm.setFx(FxP.REVERSE, if (v[FxP.REVERSE] > 0.5f) 0f else 1f) }, Modifier.weight(1f))
            FxChip(if (vm.fxHoldMomentary) "HOLD: MOMENTARY" else "HOLD: LATCH", vm.fxHoldMomentary, tint, { vm.fxHoldMomentary = !vm.fxHoldMomentary }, Modifier.weight(1.5f))
        }
    }
}

// ----------------------------------------------------------------------------- phrase looper
@Composable
private fun LooperPanel(vm: SynthViewModel, tint: Color) {
    val v = vm.fxValues
    val st = vm.fxStatus
    val burst = v[FxP.LOOP_BURST] > 0.5f
    val order = v[FxP.LOOP_ORDER] > 0.5f
    val lamp = when (st.loopState) {
        FxLoop.S_REC -> LedRed
        FxLoop.S_PLAY -> LampGreen
        FxLoop.S_DUB -> Amber
        FxLoop.S_STOPPED -> Cream
        else -> Dim
    }
    val stateText = when (st.loopState) {
        FxLoop.S_REC -> "RECORDING"
        FxLoop.S_PLAY -> "PLAYING"
        FxLoop.S_DUB -> "OVERDUBBING"
        FxLoop.S_STOPPED -> "STOPPED"
        else -> "READY"
    }
    val mainLabel = when (st.loopState) {
        FxLoop.S_EMPTY -> "REC"
        FxLoop.S_REC -> if (burst) "REC" else if (order) "DUB" else "PLAY"
        FxLoop.S_PLAY -> "DUB"
        else -> "PLAY"
    }
    FxCard("PHRASE LOOPER • UP TO 60 s", tint) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Canvas(Modifier.size(12.dp)) { drawCircle(lamp) }
            Text(stateText, color = lamp, fontSize = 9.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            val shown = if (st.loopState == FxLoop.S_REC) f1("%.1f / 60 s", st.loopSecs) else f1("%.1f s", st.loopSecs)
            Text(shown, color = Cream, fontSize = 9.sp)
        }
        Canvas(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))) {
            drawRect(Color(0xFF2A2D31), size = size)
            val frac = if (st.loopState == FxLoop.S_REC) min(1f, st.loopSecs / 60f) else st.loopPos.coerceIn(0f, 1f)
            drawRect(lamp, size = Size(size.width * frac, size.height))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            FxPad(mainLabel, if (burst) "hold to record" else "REC / PLAY / DUB", st.loopState == FxLoop.S_REC || st.loopState == FxLoop.S_DUB, lamp, Modifier.weight(2f).height(46.dp)) {
                vm.fxLooperCommand(FxLoop.MAIN)
                if (burst) { tryAwaitRelease(); vm.fxLooperCommand(FxLoop.REC_RELEASE) }
            }
            Column(Modifier.weight(1.4f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FxChip("STOP", st.loopState == FxLoop.S_STOPPED, tint, { vm.fxLooperCommand(FxLoop.STOP) }, Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FxChip("UNDO", false, tint, { vm.fxLooperCommand(FxLoop.UNDO) }, Modifier.weight(1f))
                    FxChip("ERASE", false, LedRed, { vm.fxLooperCommand(FxLoop.ERASE) }, Modifier.weight(1f))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FxToggleChip("REVERSE", FxP.LOOP_REVERSE, vm, tint, Modifier.weight(1f))
            FxToggleChip("PRE-FX", FxP.LOOP_PREFX, vm, tint, Modifier.weight(1f))
            FxToggleChip("LOOPER ONLY", FxP.LOOP_ONLY, vm, tint, Modifier.weight(1.4f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            FxToggleChip("BURST", FxP.LOOP_BURST, vm, tint, Modifier.weight(1f))
            FxToggleChip("QUANTIZE", FxP.LOOP_QUANTIZE, vm, tint, Modifier.weight(1.2f))
            FxChip(if (order) "R>D>P" else "R>P>D", order, tint, { vm.setFx(FxP.LOOP_ORDER, if (order) 0f else 1f) }, Modifier.weight(1f))
        }
        Text("Speed: SHIFT + TIME knob. PRE-FX runs the loop through the effect; QUANTIZE trims to the beat.", color = Dim, fontSize = 7.sp, maxLines = 2)
    }
}

// --------------------------------------------------------------------------------- presets
@Composable
private fun PresetPanel(vm: SynthViewModel, tint: Color) {
    var activeSlot by remember { mutableIntStateOf(-1) }
    var message by remember { mutableStateOf("Tap = load • long-press = save here") }
    var presetName by remember { mutableStateOf("") }
    FxCard("16 USER PRESETS", tint) {
        for (bank in 0..3) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0..3) {
                    val slot = bank * 4 + i
                    PresetSlot(
                        (slot + 1).toString().padStart(2, '0'), BankColors[bank], activeSlot == slot, Modifier.weight(1f),
                        onTap = { vm.loadFxUserPreset(slot); activeSlot = slot; message = "LOADED  ${vm.fxUserPresets[slot].name}" },
                        onLong = {
                            vm.saveFxUserPreset(slot, presetName.ifBlank { null }); activeSlot = slot
                            message = "SAVED  ${vm.fxUserPresets[slot].name}"
                        }
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(message, color = tint, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
            FxChip("UNDO", false, tint, { vm.undo() }, Modifier.width(52.dp))
        }
        OutlinedTextField(
            value = presetName, onValueChange = { presetName = it.take(20) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp), singleLine = true,
            placeholder = { Text("name for the next save", fontSize = 9.sp) }
        )
        Text("Slots store every sound/looper setting. The recorded loop itself is not stored in a slot.", color = Dim, fontSize = 7.sp, maxLines = 2)
    }
}

@Composable
private fun PresetSlot(label: String, color: Color, selected: Boolean, modifier: Modifier, onTap: () -> Unit, onLong: () -> Unit) {
    val tap by rememberUpdatedState(onTap)
    val long by rememberUpdatedState(onLong)
    Box(
        modifier.height(30.dp).clip(RoundedCornerShape(4.dp))
            .background(if (selected) color else color.copy(alpha = 0.22f))
            .pointerInput(Unit) { detectTapGestures(onTap = { tap() }, onLongPress = { long() }) },
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.Black else Cream, fontSize = 10.sp, fontWeight = FontWeight.Black) }
}

// ----------------------------------------------------------------------------------- global
@Composable
private fun GlobalPanel(vm: SynthViewModel, tint: Color) {
    val v = vm.fxValues
    var open by remember { mutableStateOf(false) }
    var expSelection by remember { mutableIntStateOf(0) }
    FxCard("GLOBAL CONFIGURATION", tint) {
        FxChip(if (open) "HIDE ▲" else "SHOW ▼", open, tint, { open = !open }, Modifier.width(80.dp))
        if (open) {
            FxChoice("INPUT / OUTPUT", listOf("STEREO", "MONO IN", "WIDE", "MONO OUT"), (v[FxP.STEREO_MODE] * 3f).roundToInt().coerceIn(0, 3), tint) { vm.setFx(FxP.STEREO_MODE, it / 3f) }
            FxChoice("BYPASS STYLE", listOf("BUFFERED", "TRAILS", "SOFT"), (v[FxP.BYPASS_MODE] * 2f).roundToInt().coerceIn(0, 2), tint) { vm.setFx(FxP.BYPASS_MODE, it / 2f) }
            Text("Android cannot switch relays, so there is no true bypass: SOFT keeps the dry path and mutes the effect. TRAILS lets delays, loops and reverb ring out.", color = Dim, fontSize = 7.sp, maxLines = 3)
            FxChoice("EXPRESSION / CC TARGET", expTargets.map { it.second.take(8) }, expSelection, tint) {
                expSelection = it; vm.selectMidiTarget(P.COUNT + expTargets[it].first)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                FxChip(if (vm.isMidiLearning) "WAITING FOR CC…" else "MIDI LEARN", vm.isMidiLearning, tint, {
                    vm.selectMidiTarget(P.COUNT + expTargets[expSelection].first); vm.beginMidiLearn()
                }, Modifier.weight(1f))
                FxChip("CLEAR CC", false, tint, { vm.clearMidiMappings() }, Modifier.weight(1f))
                Text("${vm.midiMappings.size} mapped", color = tint, fontSize = 8.sp)
            }
        }
    }
}

// ------------------------------------------------------------------------------ small parts
@Composable
private fun FxCard(title: String, tint: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(Panel).padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, color = tint, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
        content()
    }
}

@Composable
private fun FxChip(label: String, selected: Boolean, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.heightIn(min = 26.dp).clip(RoundedCornerShape(4.dp))
            .background(if (selected) tint else Key)
            .clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) Color.Black else Cream, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun FxToggleChip(label: String, id: Int, vm: SynthViewModel, tint: Color, modifier: Modifier) {
    val on = vm.fxValues[id] > 0.5f
    FxChip(label, on, tint, { vm.setFx(id, if (on) 0f else 1f) }, modifier)
}

@Composable
private fun FxChoice(label: String, options: List<String>, selected: Int, tint: Color, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = Dim, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            options.forEachIndexed { i, name -> FxChip(name, selected == i, tint, { onSelect(i) }, Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun FxPad(label: String, sub: String, active: Boolean, tint: Color, modifier: Modifier, onPress: suspend PressGestureScope.(Offset) -> Unit) {
    val press by rememberUpdatedState(onPress)
    Box(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (active) tint else Key)
            .pointerInput(Unit) { detectTapGestures(onPress = { offset -> press(this, offset) }) },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = if (active) Color.Black else Cream, fontSize = 14.sp, fontWeight = FontWeight.Black)
            if (sub.isNotEmpty()) Text(sub, color = if (active) Color.Black else Dim, fontSize = 7.sp, maxLines = 1)
        }
    }
}
