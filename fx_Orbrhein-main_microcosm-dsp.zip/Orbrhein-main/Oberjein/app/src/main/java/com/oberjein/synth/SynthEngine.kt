package com.oberjein.synth

/** Thin JNI bridge to the C++ synth (cpp/native-lib.cpp). All calls are real-time safe. */
object SynthEngine {
    init { System.loadLibrary("oberjein") }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeSetParam(id: Int, value: Float)
    external fun nativeNoteOn(note: Int, velocity: Float)
    external fun nativeNoteOff(note: Int)
    external fun nativeAllNotesOff()
    external fun nativePitchBend(value: Float)
    external fun nativeSetFxParam(id: Int, value: Float)
    external fun nativeFxTapTempo(bpm: Float)
    external fun nativeFxHold(enabled: Boolean)
    external fun nativeFxLooperCommand(command: Int)
    // Keys go through the native arpeggiator when it is on. echo = also mirror the note to the virtual MIDI output.
    external fun nativeKeyOn(note: Int, velocity: Float, echo: Boolean)
    external fun nativeKeyOff(note: Int, echo: Boolean)
    external fun nativePanic()
    external fun nativeArpConfig(ints: IntArray, floats: FloatArray, steps: FloatArray, routes: FloatArray)
    external fun nativeArpStatus(out: FloatArray)
    external fun nativeArpSteps(out: FloatArray)
    external fun nativeDrainMidiOut(out: IntArray): Int
    /** Fills a FloatArray(9): loopState, loopPos, loopSecs, inPeak, outPeak, beatPhase, hold, onsets, voices. */
    external fun nativeFxReadStatus(out: FloatArray)
}
