package com.oberjein.synth

/** Parameter ids shared with the native FxEngine (cpp/fx_engine.h, enum FxParam). Keep in sync. */
object FxP {
    const val ENABLE = 0
    const val EFFECT = 1          // effect index / 10
    const val VARIATION = 2       // variation index / 3
    const val TIME = 3            // subdivision step / 5 (1/4, 1/2, TAP, 2x, 4x, 8x)
    const val ACTIVITY = 4
    const val REPEATS = 5
    const val SHAPE = 6
    const val FILTER = 7          // 1.0 = filter bypassed
    const val MIX = 8
    const val SPACE = 9
    const val LOOP_LEVEL = 10
    const val PITCH_DEPTH = 11
    const val PITCH_RATE = 12
    const val RESONANCE = 13
    const val REVERB_MODE = 14    // mode index / 3 (A..D)
    const val BYPASS_MODE = 15    // 0 buffered, .5 trails, 1 soft/true bypass
    const val TRAILS = 16
    const val REVERSE = 17        // effect direction (FWD/REV)
    const val STEREO_MODE = 18    // index / 3: STEREO, MONO IN, WIDE, MONO OUT
    const val TEMPO = 19          // BPM 30..300
    const val TEMPO_MODE = 20     // 0 = TIME knob picks subdivision, 1 = TIME knob sets BPM
    const val FX_MASTER = 21      // effect volume
    const val LOOP_FADE = 22
    const val LOOP_SPEED = 23     // 0.5 = 1x, 0 = 1/4x, 1 = 4x
    const val LOOP_PREFX = 24
    const val LOOP_ONLY = 25
    const val LOOP_QUANTIZE = 26
    const val LOOP_BURST = 27
    const val LOOP_ORDER = 28     // 0 = REC>PLAY>DUB, 1 = REC>DUB>PLAY
    const val LOOP_REVERSE = 29
    const val COUNT = 30
}

/** Looper commands (FxEngine::LoopCommand). */
object FxLoop {
    const val STOP = 0
    const val RECORD = 1
    const val PLAY = 2
    const val DUB = 3
    const val ERASE = 4
    const val UNDO = 5
    const val REC_RELEASE = 6
    const val MAIN = 7            // single REC/PLAY/DUB footswitch logic
    const val S_EMPTY = 0
    const val S_REC = 1
    const val S_PLAY = 2
    const val S_DUB = 3
    const val S_STOPPED = 4
}

/** Live status polled from the audio thread (see SynthEngine.nativeFxReadStatus). */
data class FxStatus(
    val loopState: Int = 0, val loopPos: Float = 0f, val loopSecs: Float = 0f,
    val inPeak: Float = 0f, val outPeak: Float = 0f, val beatPhase: Float = 0f,
    val hold: Boolean = false, val onsets: Int = 0, val voices: Int = 0
)

// Families and effect order follow the Microcosm manual.
enum class FxFamily(val title: String, val effects: IntRange) {
    MICRO_LOOP("MICRO LOOP", 0..2),
    GRANULES("GRANULES", 3..5),
    GLITCH("GLITCH", 6..8),
    MULTIDELAY("MULTIDELAY", 9..10)
}

val FX_EFFECT_NAMES = listOf("MOSAIC", "SEQ", "GLIDE", "HAZE", "TUNNEL", "STRUM", "BLOCKS", "INTERRUPT", "ARP", "PATTERN", "WARP")
val FX_VARIATIONS = listOf("A", "B", "C", "D")
val FX_REVERB_MODES = listOf("BRIGHT ROOM", "DARK MEDIUM", "LARGE HALL", "AMBIENT")
val FX_SUBDIVISIONS = listOf("1/4", "1/2", "TAP", "2x", "4x", "8x")

fun fxFamilyOf(effect: Int): FxFamily = FxFamily.values().first { effect in it.effects }

/** What Activity does for each effect (from the manual). */
val FX_ACTIVITY_HELP = listOf(
    "Number of active loopers", "Variation of the sequence (see variation)", "Rate of the pitch glide",
    "Grain density and spread", "Depth of the variation's modifier", "Density of the pattern",
    "Amount of variation and sample manipulation", "Amount of variation and sample manipulation", "Number of steps in the arpeggio",
    "Number of active delay taps", "Number of active delay taps"
)
val FX_REPEATS_HELP = listOf(
    "How long the loops sustain", "How long the sequence rings", "How long the glides sustain",
    "How long the cloud lingers", "How long the drone takes to decay", "How long the chain keeps repeating",
    "How long recent notes stay in play", "How often glitches are triggered", "How long the arpeggio lasts",
    "Feedback time of the delay line", "Feedback time of the delay line"
)
val FX_VARIATION_HELP = listOf(
    listOf("Micro loops at normal and double speed: octave-up harmonies", "Normal and half speed: an octave below your input", "All loops at double speed", "Half, normal, double and quad speed: -1 to +2 octaves"),
    listOf("Live samples filtered and shuffled into random rhythms", "Samples bounce between normal and half speed; a pad joins at max Activity", "Overlapping layers with filter sweeps", "Interlocking rhythmic samples with bit-crushing; crushed sub-octave at max"),
    listOf("Glides between half and normal speed", "Glides between double and half speed", "Glides between normal and double speed", "Overlapping samples glide in both directions at once"),
    listOf("Short diffused texture from stretched overlapping samples", "Many simultaneous randomized grains", "Mix of normal and double speed grains", "Mix of normal and half speed grains"),
    listOf("Drone loop length compresses and lengthens", "Sub-octave drone with filter sweeps", "Drone samples with resonant band-pass filters", "Loop length follows your playing dynamics"),
    listOf("Repeats the most recent note continuously", "Many copies of the last onset overlap: phasing", "Cascading chains of recent note onsets", "Cascading chains plus double speed grains"),
    listOf("Rearranges your playing; bursts of runs of recent notes", "Rearranges and pitch-shifts the incoming signal", "Soft filtered overlapping samples: a gentler glitch", "Pitch-shifts and bit-crushes the rearranged signal"),
    listOf("Glitches and rearranged versions interrupt the live signal", "Interruptions include pitch-shifted samples", "Interruptions include filter sweeps and echoes", "Bit-crushing and more drastic manipulation"),
    listOf("Basic arpeggios made of your most recent notes", "Arpeggio steps at various speeds: a pitch-shifted pattern", "Each step gets a random filter", "Bit-crushed arpeggios"),
    listOf("Pattern 1: classic linear delay", "Pattern 2: dotted rhythm", "Pattern 3: triplet cross-rhythm", "Pattern 4: bouncing-ball taps"),
    listOf("Envelope-controlled filter on every tap", "Resonant band-pass filter on every tap", "Pitch-shifted delay taps", "Taps cross-fade with double speed grains")
)

data class FxUserPreset(val name: String, val values: List<Float>)

val FX_DEFAULTS = listOf(
    0f, 0f, 0f, 0.4f, 0.4f, 0.35f, 0.5f, 1.0f, 0.35f, 0.25f, 0.7f,   // ENABLE .. LOOP_LEVEL
    0f, 0.35f, 0.2f, 0f, 0f, 0f, 0f, 0f, 120f, 0f, 0.8f, 0.4f,        // PITCH_DEPTH .. LOOP_FADE
    0.5f, 0f, 0f, 0f, 0f, 0f, 0f                                        // LOOP_SPEED .. LOOP_REVERSE
)

/** Pads/clips an old backup or preset vector to the current parameter count. */
fun fxMigrate(values: List<Float>): List<Float> = List(FxP.COUNT) { values.getOrNull(it) ?: FX_DEFAULTS[it] }

private fun fp(name: String, effect: Int, variation: Int, activity: Float, repeats: Float, shape: Float, timeStep: Int,
               mix: Float = 0.5f, space: Float = 0.3f, filter: Float = 1f, mod: Float = 0f) =
    FxUserPreset(name, FX_DEFAULTS.toMutableList().also {
        it[FxP.ENABLE] = 1f; it[FxP.EFFECT] = effect / 10f; it[FxP.VARIATION] = variation / 3f
        it[FxP.ACTIVITY] = activity; it[FxP.REPEATS] = repeats; it[FxP.SHAPE] = shape; it[FxP.TIME] = timeStep / 5f
        it[FxP.MIX] = mix; it[FxP.SPACE] = space; it[FxP.FILTER] = filter; it[FxP.PITCH_DEPTH] = mod
    })

/** 44 factory starting points, index = effect * 4 + variation. They only touch the "sound" knobs. */
val FX_FACTORY_PRESETS = listOf(
    fp("Mosaic Shimmer", 0, 0, 0.55f, 0.55f, 0.55f, 2, 0.5f, 0.35f),
    fp("Mosaic Depth", 0, 1, 0.6f, 0.6f, 0.5f, 2, 0.5f, 0.4f, 0.85f),
    fp("Mosaic Rush", 0, 2, 0.45f, 0.45f, 0.3f, 3, 0.45f, 0.3f),
    fp("Mosaic Spectrum", 0, 3, 0.8f, 0.75f, 0.6f, 2, 0.55f, 0.45f),
    fp("Seq Scatter", 1, 0, 0.6f, 0.5f, 0.5f, 2, 0.5f, 0.3f),
    fp("Seq Bounce", 1, 1, 0.65f, 0.55f, 0.5f, 2, 0.5f, 0.35f),
    fp("Seq Sweep", 1, 2, 0.5f, 0.6f, 0.6f, 1, 0.55f, 0.4f),
    fp("Seq Machine", 1, 3, 0.7f, 0.5f, 0.4f, 3, 0.5f, 0.25f),
    fp("Glide Sigh", 2, 0, 0.35f, 0.7f, 0.2f, 1, 0.5f, 0.45f),
    fp("Glide Dive", 2, 1, 0.5f, 0.65f, 0.1f, 1, 0.5f, 0.4f),
    fp("Glide Rise", 2, 2, 0.45f, 0.6f, 0.85f, 1, 0.5f, 0.4f),
    fp("Glide Tide", 2, 3, 0.55f, 0.75f, 0.45f, 0, 0.55f, 0.5f),
    fp("Haze Breath", 3, 0, 0.4f, 0.5f, 0.5f, 2, 0.5f, 0.45f),
    fp("Haze Cloud", 3, 1, 0.75f, 0.7f, 0.5f, 2, 0.55f, 0.5f, 0.8f),
    fp("Haze Bloom", 3, 2, 0.6f, 0.65f, 0.5f, 2, 0.5f, 0.5f, 0.9f),
    fp("Haze Abyss", 3, 3, 0.65f, 0.75f, 0.5f, 2, 0.55f, 0.55f, 0.7f),
    fp("Tunnel Breathe", 4, 0, 0.5f, 0.8f, 0.6f, 2, 0.55f, 0.4f),
    fp("Tunnel Sub", 4, 1, 0.55f, 0.85f, 0.4f, 2, 0.55f, 0.4f, 0.75f),
    fp("Tunnel Choir", 4, 2, 0.6f, 0.85f, 0.7f, 2, 0.5f, 0.5f),
    fp("Tunnel Pulse", 4, 3, 0.7f, 0.75f, 0.55f, 2, 0.5f, 0.4f),
    fp("Strum Latch", 5, 0, 0.4f, 0.7f, 0.5f, 2, 0.5f, 0.3f),
    fp("Strum Phase", 5, 1, 0.5f, 0.75f, 0.5f, 2, 0.5f, 0.35f),
    fp("Strum Cascade", 5, 2, 0.6f, 0.7f, 0.5f, 3, 0.5f, 0.35f),
    fp("Strum Rain", 5, 3, 0.75f, 0.65f, 0.5f, 3, 0.5f, 0.4f),
    fp("Blocks Shuffle", 6, 0, 0.55f, 0.5f, 0.5f, 3, 0.55f, 0.25f),
    fp("Blocks Shift", 6, 1, 0.6f, 0.5f, 0.5f, 3, 0.55f, 0.3f),
    fp("Blocks Velvet", 6, 2, 0.5f, 0.55f, 0.5f, 2, 0.55f, 0.35f),
    fp("Blocks Crunch", 6, 3, 0.7f, 0.5f, 0.5f, 3, 0.6f, 0.2f),
    fp("Interrupt Cut", 7, 0, 0.5f, 0.45f, 0.5f, 3, 0.85f, 0.25f),
    fp("Interrupt Pitch", 7, 1, 0.6f, 0.4f, 0.5f, 3, 0.85f, 0.3f),
    fp("Interrupt Sweep", 7, 2, 0.55f, 0.45f, 0.5f, 2, 0.85f, 0.35f),
    fp("Interrupt Mayhem", 7, 3, 0.85f, 0.6f, 0.5f, 4, 0.9f, 0.2f),
    fp("Arp Pearl", 8, 0, 0.5f, 0.6f, 0.5f, 2, 0.5f, 0.35f),
    fp("Arp Ladder", 8, 1, 0.6f, 0.6f, 0.5f, 2, 0.5f, 0.35f),
    fp("Arp Prism", 8, 2, 0.55f, 0.65f, 0.5f, 3, 0.5f, 0.4f),
    fp("Arp Arcade", 8, 3, 0.7f, 0.55f, 0.5f, 3, 0.5f, 0.25f),
    fp("Pattern Echo", 9, 0, 0.35f, 0.45f, 0.4f, 2, 0.4f, 0.3f, 0.85f),
    fp("Pattern Dotted", 9, 1, 0.45f, 0.5f, 0.4f, 2, 0.4f, 0.3f, 0.85f),
    fp("Pattern Triplet", 9, 2, 0.55f, 0.5f, 0.45f, 2, 0.4f, 0.3f, 0.85f),
    fp("Pattern Bounce", 9, 3, 0.6f, 0.55f, 0.5f, 2, 0.45f, 0.3f, 0.85f),
    fp("Warp Tape", 10, 0, 0.4f, 0.6f, 0.5f, 2, 0.5f, 0.4f),
    fp("Warp Ring", 10, 1, 0.5f, 0.65f, 0.5f, 2, 0.5f, 0.4f),
    fp("Warp Drift", 10, 2, 0.55f, 0.7f, 0.5f, 2, 0.5f, 0.45f, 1f, 0.15f),
    fp("Warp Halo", 10, 3, 0.6f, 0.7f, 0.5f, 2, 0.5f, 0.5f)
)
