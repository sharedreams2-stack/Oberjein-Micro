package com.oberjein.synth

import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

class SynthViewModel : ViewModel() {
    val values = ParamStore(DEFAULTS.toList())
    var presetIndex by mutableIntStateOf(0); private set
    var octave by mutableIntStateOf(3); private set
    var midiTarget by mutableIntStateOf(P.CUTOFF); private set
    var isMidiLearning by mutableStateOf(false); private set
    val midiMappings = mutableStateMapOf<Int, Int>()
    var arpConfig by mutableStateOf(ArpConfig()); private set
    var showArp by mutableStateOf(false)
    var showFx by mutableStateOf(false)
    val fxValues = ParamStore(FX_DEFAULTS)
    val fxUserPresets = mutableStateListOf<FxUserPreset>().apply { repeat(16) { add(FxUserPreset("USER ${(it + 1).toString().padStart(2, '0')}", FX_DEFAULTS)) } }
    private val tapTimes = ArrayDeque<Long>()
    var fxHoldActive by mutableStateOf(false); private set
    var fxLoopState by mutableIntStateOf(0); private set
    var fxStatus by mutableStateOf(FxStatus()); private set
    /** HOLD pad behaviour: false = latch (toggle), true = momentary (frozen only while pressed). */
    var fxHoldMomentary by mutableStateOf(false)
    var arpStep by mutableIntStateOf(0); private set
    private data class Snapshot(val values: List<Float>, val arp: ArpConfig, val mappings: Map<Int, Int>, val preset: Int, val octave: Int, val fx: List<Float>, val fxUsers: List<FxUserPreset>)
    private val undoStack = ArrayDeque<Snapshot>()
    private val redoStack = ArrayDeque<Snapshot>()
    // Notes the engine played (keys with echo + arpeggiator) are mirrored to the virtual MIDI output from a
    // background thread, so the MIDI side never touches the UI thread.
    private val pumpThread = HandlerThread("oberjein-midi-out").apply { start() }
    private val pumpHandler = Handler(pumpThread.looper)
    private val pumpBuf = IntArray(128)
    private val pump = object : Runnable {
        override fun run() {
            val n = SynthEngine.nativeDrainMidiOut(pumpBuf)
            val connected = MidiBridge.hasOutputs()
            if (n > 0 && connected) {
                for (i in 0 until n) {
                    val e = pumpBuf[i]
                    val note = (e shr 8) and 0x7F
                    if (e and 0x10000 != 0) MidiBridge.noteOn(note, (e and 0x7F) / 127f) else MidiBridge.noteOff(note)
                }
            }
            pumpHandler.postDelayed(this, if (connected) 5L else 100L)
        }
    }
    private var lastArpMutations = 0
    init { pumpHandler.post(pump) }

    override fun onCleared() {
        pumpHandler.removeCallbacksAndMessages(null)
        pumpThread.quitSafely()
        super.onCleared()
    }

    /** Called ~20x/s while the arp screen is open (and before saving): playing step + pattern mutated by RANDOM/EVOLVE. */
    fun pollArp() {
        val st = ArpNative.status()
        if (arpStep != st.step) arpStep = st.step
        if (st.mutations != lastArpMutations) {
            lastArpMutations = st.mutations
            arpConfig = arpConfig.copy(steps = ArpNative.readSteps())   // already in the engine: do not push it back
        }
    }

    val firstNote: Int get() = 12 * (octave + 1)

    private fun snapshot() = Snapshot(values.toList(), arpConfig, midiMappings.toMap(), presetIndex, octave, fxValues.toList(), fxUserPresets.toList())
    private var lastRememberKey = -1
    private var lastRememberAt = 0L
    /**
     * Pushes an undo snapshot. Edits of the same control ([key] >= 0) within 700 ms count as ONE step, so dragging
     * a knob no longer copies every list ~100 times per second nor floods the undo stack.
     */
    private fun remember(key: Int = -1) {
        val now = SystemClock.uptimeMillis()
        if (key >= 0 && key == lastRememberKey && now - lastRememberAt < 700L) { lastRememberAt = now; return }
        lastRememberKey = key; lastRememberAt = now
        undoStack.addLast(snapshot()); while (undoStack.size > 100) undoStack.removeFirst(); redoStack.clear()
    }
    /** Call once when a knob drag starts so a whole drag is ONE undo step instead of hundreds. */
    fun beginFxEdit() = remember(3000)
    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()
    private fun applySnapshot(s: Snapshot) {
        s.values.forEachIndexed { id, v -> values[id] = v }
        presetIndex = s.preset; octave = s.octave
        midiMappings.clear(); midiMappings.putAll(s.mappings)
        s.fx.forEachIndexed { id, value -> fxValues[id] = value; SynthEngine.nativeSetFxParam(id, value) }
        s.fxUsers.forEachIndexed { index, preset -> fxUserPresets[index] = preset }
        SynthEngine.nativeAllNotesOff(); pushAll()
        arpConfig = s.arp; ArpNative.push(arpConfig)
    }
    fun undo() { if (undoStack.isNotEmpty()) { redoStack.addLast(snapshot()); applySnapshot(undoStack.removeLast()) } }
    fun redo() { if (redoStack.isNotEmpty()) { undoStack.addLast(snapshot()); applySnapshot(redoStack.removeLast()) } }

    fun set(id: Int, value: Float) {
        if (id !in values.indices) return
        val v = value.coerceIn(0f, 1f)
        if (kotlin.math.abs(values[id] - v) < 0.0001f) return
        remember(id)
        values[id] = v
        SynthEngine.nativeSetParam(id, v)
    }

    fun updateArp(transform: (ArpConfig) -> ArpConfig) {
        val next = transform(arpConfig)
        if (next == arpConfig) return
        remember(2000); arpConfig = next
        ArpNative.push(next)
    }
    fun toggleArp() { updateArp { it.copy(enabled = !it.enabled) } }
    fun arpNoteOn(note: Int, velocity: Float) = SynthEngine.nativeKeyOn(note, velocity, true)
    fun arpNoteOff(note: Int) = SynthEngine.nativeKeyOff(note, true)
    fun setArpPage(show: Boolean) { showArp = show; if (show) showFx = false }
    fun setFxPage(show: Boolean) { showFx = show; if (show) showArp = false }

    fun pushFxAll() = fxValues.forEachIndexed { id, value -> SynthEngine.nativeSetFxParam(id, value) }

    /** [undo] = false is used for continuous/automatic changes (e.g. following the arp BPM). */
    fun setFx(id: Int, value: Float, undo: Boolean = true) {
        if (id !in fxValues.indices) return
        val v = if (id == FxP.TEMPO) value.coerceIn(30f, 300f) else value.coerceIn(0f, 1f)
        if (kotlin.math.abs(fxValues[id] - v) < 0.0001f) return
        if (undo) remember(1000 + id)
        fxValues[id] = v; SynthEngine.nativeSetFxParam(id, v)
    }

    /** Like the hardware: choosing an effect/variation keeps your knob settings. */
    fun selectFxEffect(effect: Int, variation: Int) {
        val e = effect.coerceIn(0, 10); val va = variation.coerceIn(0, 3)
        remember()
        fxValues[FxP.EFFECT] = e / 10f; fxValues[FxP.VARIATION] = va / 3f
        SynthEngine.nativeSetFxParam(FxP.EFFECT, fxValues[FxP.EFFECT])
        SynthEngine.nativeSetFxParam(FxP.VARIATION, fxValues[FxP.VARIATION])
    }

    /** Loads the factory starting point for an effect/variation (sound knobs only: no tempo/looper/bypass). */
    fun applyFxFactory(effect: Int, variation: Int) {
        val index = (effect.coerceIn(0, 10) * 4 + variation.coerceIn(0, 3)).coerceIn(0, FX_FACTORY_PRESETS.lastIndex)
        val preset = FX_FACTORY_PRESETS[index].values
        remember()
        for (id in intArrayOf(FxP.EFFECT, FxP.VARIATION, FxP.TIME, FxP.ACTIVITY, FxP.REPEATS, FxP.SHAPE, FxP.FILTER, FxP.MIX, FxP.SPACE, FxP.PITCH_DEPTH)) {
            fxValues[id] = preset[id]; SynthEngine.nativeSetFxParam(id, preset[id])
        }
    }

    fun tapFxTempo(now: Long = android.os.SystemClock.elapsedRealtime()) {
        if (tapTimes.isNotEmpty() && now - tapTimes.last() > 2500L) tapTimes.clear()
        if (tapTimes.isNotEmpty()) {
            val delta = now - tapTimes.last()
            if (delta in 250L..2000L) {
                tapTimes.addLast(now); while (tapTimes.size > 5) tapTimes.removeFirst()
                val intervals = tapTimes.zipWithNext { a, b -> b - a }
                val bpm = (60000.0 / intervals.average()).toFloat().coerceIn(30f, 240f)
                setFx(FxP.TEMPO, bpm); SynthEngine.nativeFxTapTempo(bpm)
            } else { tapTimes.clear(); tapTimes.addLast(now) }
        } else tapTimes.addLast(now)
    }

    fun setFxHold(active: Boolean) { fxHoldActive = active; SynthEngine.nativeFxHold(active) }
    fun toggleFxHold() = setFxHold(!fxHoldActive)
    /** The audio thread owns the looper state machine; the UI just sends commands and polls the status. */
    fun fxLooperCommand(command: Int) { SynthEngine.nativeFxLooperCommand(command) }
    fun updateFxStatus(a: FloatArray) {
        if (a.size < 9) return
        val st = FxStatus(a[0].toInt(), a[1], a[2], a[3], a[4], a[5], a[6] > 0.5f, a[7].toInt(), a[8].toInt())
        fxStatus = st
        if (fxLoopState != st.loopState) fxLoopState = st.loopState
    }
    fun saveFxUserPreset(slot: Int, name: String? = null) {
        if (slot !in 0..15) return
        remember()
        fxUserPresets[slot] = FxUserPreset(name?.take(20)?.ifBlank { "USER ${slot + 1}" } ?: "USER ${(slot + 1).toString().padStart(2, '0')}", fxValues.toList())
    }
    fun loadFxUserPreset(slot: Int) {
        if (slot !in 0..15) return
        remember()
        // the bypass state is a performance switch, not part of a sound: loading a slot never toggles it
        fxMigrate(fxUserPresets[slot].values).forEachIndexed { id, value ->
            if (id == FxP.ENABLE) return@forEachIndexed
            fxValues[id] = value; SynthEngine.nativeSetFxParam(id, value)
        }
    }


    fun pushAll() = values.forEachIndexed { id, v -> SynthEngine.nativeSetParam(id, v) }

    fun loadPreset(index: Int) {
        remember()
        val i = Math.floorMod(index, PRESETS.size)
        presetIndex = i
        PRESETS[i].values.forEachIndexed { id, v -> values[id] = v }
        SynthEngine.nativeAllNotesOff()
        pushAll()
    }

    fun selectMidiTarget(id: Int) { midiTarget = id }

    fun beginMidiLearn() { isMidiLearning = true }

    fun clearMidiMappings() { if (midiMappings.isNotEmpty()) remember(); midiMappings.clear(); isMidiLearning = false }

    fun onMidiCC(controller: Int, value: Int) {
        // Reserve All Notes Off so MIDI Learn can never steal the panic command.
        if (controller == 123) { panic(); return }
        if (isMidiLearning) {
            remember()
            midiMappings[controller] = midiTarget
            isMidiLearning = false
            return
        }
        val target = midiMappings[controller]
        if (target != null) {
            val normalized = value.coerceIn(0, 127) / 127f
            if (target >= P.COUNT) setFx(target - P.COUNT, normalized)
            else set(target, if (target == P.OVERSAMPLING) (normalized * 2f).roundToInt() / 2f else normalized)
        } else if (controller == 1) {
            set(P.LFO_PITCH, value.coerceIn(0, 127) / 127f)
        }
    }

    fun shiftOctave(delta: Int) {
        remember()
        octave = (octave + delta).coerceIn(1, 6)
        SynthEngine.nativePanic()   // also clears the arp's held/latched keys (the keyboard loses its touches when the range moves)
    }

    // All of these are lock-free JNI calls and safe from any thread (the MIDI thread uses them directly).
    // The native engine decides whether a key plays a voice or feeds the arpeggiator.
    fun noteOn(note: Int, velocity: Float) = SynthEngine.nativeKeyOn(note, velocity, true)
    fun noteOff(note: Int) = SynthEngine.nativeKeyOff(note, true)
    fun midiNoteOn(note: Int, velocity: Float) = SynthEngine.nativeKeyOn(note, velocity, false)
    fun midiNoteOff(note: Int) = SynthEngine.nativeKeyOff(note, false)
    /** The sequencer lives in the audio thread: it keeps running with the engine, so there is nothing to resume. */
    fun resumeArpeggiator() { ArpNative.push(arpConfig) }
    fun pauseArpeggiator() { /* the engine owns the clock; stopping the audio stream stops the arp */ }
    fun pitchBend(value: Float) = SynthEngine.nativePitchBend(value)
    fun panic() { SynthEngine.nativePanic(); MidiBridge.send(byteArrayOf(0xB0.toByte(), 123, 0)) }

    fun exportStateJson(): String {
        pollArp()   // pick up steps mutated by RANDOM / EVOLVE before saving
        val savedArp = arpConfig
        val root = JSONObject()
        root.put("format", "oberjein-state-v1")
        root.put("parameters", JSONArray(values.toList()))
        root.put("presetIndex", presetIndex)
        root.put("octave", octave)
        root.put("midiMappings", JSONObject().also { obj -> midiMappings.forEach { (cc, id) -> obj.put(cc.toString(), id) } })
        val a = JSONObject()
        a.put("enabled", savedArp.enabled); a.put("hold", savedArp.hold); a.put("bpm", savedArp.bpm)
        a.put("division", savedArp.division); a.put("direction", savedArp.direction.name)
        a.put("octaveRange", savedArp.octaveRange); a.put("scale", savedArp.scale.name); a.put("root", savedArp.root)
        a.put("chordSize", savedArp.chordSize); a.put("strumMs", savedArp.strumMs); a.put("intervalShift", savedArp.intervalShift)
        a.put("randomMode", savedArp.randomMode); a.put("evolve", savedArp.evolve); a.put("loopLength", savedArp.loopLength); a.put("humanize", savedArp.humanize)
        a.put("steps", JSONArray().also { arr -> savedArp.steps.forEach { st -> arr.put(JSONObject().put("enabled",st.enabled).put("probability",st.probability).put("ratchets",st.ratchets).put("octave",st.octave).put("velocity",st.velocity).put("gate",st.gate).put("shift",st.shift)) } })
        a.put("routes", JSONArray().also { arr -> savedArp.routes.forEach { route -> arr.put(JSONObject().put("source",route.source).put("target",route.target).put("amount",route.amount).put("bipolar",route.bipolar)) } })
        root.put("arpeggiator", a)
        root.put("fxParameters", JSONArray(fxValues.toList()))
        root.put("fxUserPresets", JSONArray().also { arr -> fxUserPresets.forEach { preset -> arr.put(JSONObject().put("name", preset.name).put("values", JSONArray(preset.values))) } })
        return root.toString(2)
    }

    fun restoreStateJson(json: String) {
        val root = JSONObject(json)
        val params = root.getJSONArray("parameters")
        if (params.length() == 0) throw IllegalArgumentException("Empty parameter list")
        remember()
        // older/newer backups may have a different parameter count: keep defaults for anything missing
        for (i in 0 until P.COUNT) values[i] = if (i < params.length()) params.getDouble(i).toFloat().coerceIn(0f, 1f) else DEFAULTS[i]
        presetIndex = root.optInt("presetIndex", 0).coerceIn(0, PRESETS.lastIndex)
        octave = root.optInt("octave", 3).coerceIn(1,6)
        midiMappings.clear()
        val maps = root.optJSONObject("midiMappings") ?: JSONObject()
        maps.keys().forEach { key -> midiMappings[key.toIntOrNull() ?: -1] = maps.optInt(key) }
        val a = root.optJSONObject("arpeggiator") ?: JSONObject()
        val stepArray = a.optJSONArray("steps") ?: JSONArray()
        val steps = List(64) { i ->
            val st = stepArray.optJSONObject(i) ?: JSONObject()
            ArpStep(st.optBoolean("enabled",true),st.optDouble("probability",1.0).toFloat(),st.optInt("ratchets",1),st.optInt("octave",0),st.optDouble("velocity",1.0).toFloat(),st.optDouble("gate",0.8).toFloat(),st.optInt("shift",0))
        }
        val routeArray = a.optJSONArray("routes") ?: JSONArray()
        val routes = (0 until routeArray.length()).mapNotNull { i -> routeArray.optJSONObject(i)?.let { ArpModRoute(it.optString("source"),it.optInt("target"),it.optDouble("amount").toFloat(),it.optBoolean("bipolar")) } }
        arpConfig = ArpConfig(a.optBoolean("enabled",false),a.optBoolean("hold",false),a.optDouble("bpm",120.0).toFloat(),a.optInt("division",4),runCatching { ArpDirection.valueOf(a.optString("direction","UP")) }.getOrDefault(ArpDirection.UP),a.optInt("octaveRange",1),runCatching { ArpScale.valueOf(a.optString("scale","CHROMATIC")) }.getOrDefault(ArpScale.CHROMATIC),a.optInt("root",0),a.optInt("chordSize",1),a.optInt("strumMs",0),a.optInt("intervalShift",0),a.optBoolean("randomMode",false),a.optBoolean("evolve",false),a.optInt("loopLength",16),a.optDouble("humanize",0.0).toFloat(),steps,routes)
        root.optJSONArray("fxParameters")?.let { array ->
            val loaded = fxMigrate(List(array.length()) { array.getDouble(it).toFloat() })  // older backups have fewer params
            for (i in 0 until FxP.COUNT) { fxValues[i] = loaded[i]; SynthEngine.nativeSetFxParam(i, fxValues[i]) }
        }
        root.optJSONArray("fxUserPresets")?.let { array ->
            for (i in 0 until minOf(16, array.length())) {
                val item = array.optJSONObject(i) ?: continue
                val vals = item.optJSONArray("values") ?: continue
                fxUserPresets[i] = FxUserPreset(item.optString("name", "USER ${i+1}"), fxMigrate(List(vals.length()) { vals.getDouble(it).toFloat() }))
            }
        }
        SynthEngine.nativeAllNotesOff(); pushAll(); ArpNative.push(arpConfig)
    }

}
