#pragma once
/*
 * Microcosm-style FX engine for Oberjein.
 *
 * Signal path (as in the Hologram Microcosm manual):
 *   input -> [looper pre-FX] -> hold sampler -> EFFECT -> pitch modulation -> reverb -> low-pass filter
 *         -> mix with dry -> [looper post-FX] -> output
 *
 * The 11 effects x 4 variations are distinct algorithms built from a shared toolbox:
 *   - capture ring (6 s) with onset detection ("recent note onsets")
 *   - loop / one-shot voices that own private slice copies, with click-free two-tap Hann looping
 *   - granular cloud (Hann grains, Hermite-interpolated pitch shifting)
 *   - feedback multitap delay with per-tap filters and delay-line pitch shifters
 *   - FDN reverb, resonant TPT state-variable filter, modulated-delay pitch modulation
 *   - 60 s phrase looper with separate overdub layer, undo, quantize, burst, pre/post-FX routing
 *
 * Layout: this file = public API + control + signal chain. fx_engine_body.inc (included inside the
 * class) = voices, grains, the 11 effect algorithms, multi-delay, hold sampler and phrase looper.
 * Audio-thread safe: nothing allocates outside setSampleRate().
 */
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <vector>

#include "fx_dsp.h"

class FxEngine {
public:
    enum FxParam : int {
        ENABLE = 0, EFFECT, VARIATION, TIME, ACTIVITY, REPEATS, SHAPE, FILTER,
        MIX, SPACE, LOOP_LEVEL, PITCH_DEPTH, PITCH_RATE, RESONANCE, REVERB_MODE,
        BYPASS_MODE, TRAILS, REVERSE, STEREO_MODE, TEMPO, TEMPO_MODE,
        FX_MASTER, LOOP_FADE,
        LOOP_SPEED, LOOP_PREFX, LOOP_ONLY, LOOP_QUANTIZE, LOOP_BURST, LOOP_ORDER, LOOP_REVERSE,
        FX_PARAM_COUNT
    };
    enum LoopCommand : int {
        LOOP_STOP = 0, LOOP_RECORD = 1, LOOP_PLAY = 2, LOOP_DUB = 3, LOOP_ERASE = 4,
        LOOP_UNDO = 5, LOOP_REC_RELEASE = 6, LOOP_MAIN = 7, LOOP_CMD_COUNT = 8
    };
    enum LoopState : int { LS_EMPTY = 0, LS_REC = 1, LS_PLAY = 2, LS_DUB = 3, LS_STOPPED = 4 };
    enum Status : int {
        ST_LOOP_STATE = 0, ST_LOOP_POS, ST_LOOP_SECS, ST_IN_PEAK, ST_OUT_PEAK,
        ST_BEAT_PHASE, ST_HOLD, ST_ONSETS, ST_VOICES, ST_COUNT
    };

    FxEngine() {
        for (auto& p : params_) p.store(0.0f, std::memory_order_relaxed);
        for (auto& q : cmdQ_) q.store(-1, std::memory_order_relaxed);
        for (auto& s : status_) s.store(0.0f, std::memory_order_relaxed);
        setParam(MIX, 0.35f); setParam(SPACE, 0.25f); setParam(LOOP_LEVEL, 0.7f);
        setParam(TEMPO, 120.0f); setParam(FX_MASTER, 0.8f); setParam(LOOP_FADE, 0.4f);
        setParam(ACTIVITY, 0.4f); setParam(REPEATS, 0.35f); setParam(SHAPE, 0.5f);
        setParam(FILTER, 1.0f); setParam(TIME, 0.4f); setParam(PITCH_RATE, 0.35f);
        setParam(RESONANCE, 0.2f); setParam(LOOP_SPEED, 0.5f);
    }

    // ------------------------------------------------------------------ control surface
    void setSampleRate(float sr) {
        ready_ = false;
        sr_ = sr;
        ring_[0].init(static_cast<size_t>(6.0f * sr)); ring_[1].init(static_cast<size_t>(6.0f * sr));
        ringN_ = static_cast<int64_t>(ring_[0].size());
        dl_[0].init(static_cast<size_t>(4.0f * sr)); dl_[1].init(static_cast<size_t>(4.0f * sr));
        dlN_ = static_cast<int64_t>(dl_[0].size());
        vcap_ = static_cast<int>(0.6f * sr);
        for (auto& v : voices_) { v.bl.assign(vcap_ + 4, 0.0f); v.br.assign(vcap_ + 4, 0.0f); v.active = false; }
        holdCap_ = static_cast<int>(1.6f * sr);
        holdL_.assign(holdCap_ + 4, 0.0f); holdR_.assign(holdCap_ + 4, 0.0f);
        loopMax_ = std::min(static_cast<int>(60.0f * sr), 2880000);
        phr_[0].assign(loopMax_ + 4, 0.0f); phr_[1].assign(loopMax_ + 4, 0.0f);
        lay_[0].assign(loopMax_ + 4, 0.0f); lay_[1].assign(loopMax_ + 4, 0.0f);
        reverb_.init(sr);
        mod_.init(sr);
        gateC_ = 1.0f / (0.005f * sr);
        resetAll();
        ready_ = true;
    }
    void setParam(int id, float value) {
        if (id < 0 || id >= FX_PARAM_COUNT) return;
        params_[id].store(std::isfinite(value) ? value : 0.0f, std::memory_order_relaxed);
    }
    float getParam(int id) const {
        return (id < 0 || id >= FX_PARAM_COUNT) ? 0.0f : params_[id].load(std::memory_order_relaxed);
    }
    void tapTempo(float bpm) { setParam(TEMPO, bpm); }
    void setHold(bool on) { holdReq_.store(on, std::memory_order_release); }
    void commandLooper(int cmd) {
        if (cmd < 0 || cmd >= LOOP_CMD_COUNT) return;
        const uint32_t i = qHead_.fetch_add(1, std::memory_order_acq_rel);
        cmdQ_[i & 15].store(cmd, std::memory_order_release);
    }
    // Called by the synth on note-on so "recent note onsets" are exact even for soft attacks.
    void onsetHint() { hint_.store(true, std::memory_order_release); }
    bool loopHasAudio() const { return loopLenPub_.load(std::memory_order_relaxed) > 0; }
    void readStatus(float* out, int n) const {
        for (int i = 0; i < n && i < ST_COUNT; ++i) out[i] = status_[i].load(std::memory_order_relaxed);
    }

    // ------------------------------------------------------------------------------ process
    void process(float& left, float& right) {
        if (!ready_) return;
        const float dryL = left, dryR = right;
        drainCommands();
        if ((ctlCount_++ & 31) == 0) updateControl();
        const bool enabled = c_.enabled;
        if (enabled) { idle_ = false; quiet_ = 0; }

        inGate_ += ((enabled ? 1.0f : 0.0f) - inGate_) * gateC_;
        const float wetTarget = (enabled || c_.trails) ? 1.0f : 0.0f;
        wetGate_ += (wetTarget - wetGate_) * gateC_;
        const bool loopBusy = loopState_ == LS_REC || loopState_ == LS_PLAY || loopState_ == LS_DUB;

        if (idle_ && !loopBusy && !holdActive_) {
            if ((statCount_++ & 1023) == 0) publishStatus();
            return;
        }
        const bool fxRun = !idle_;

        // ---------------------------------------------------------------- input stage
        float fl = dryL, fr = dryR;
        if (c_.stereoMode == 1) { fl = fr = 0.5f * (dryL + dryR); }
        const float gl = fl * inGate_, gr = fr * inGate_;
        inPeak_ = std::max(std::max(std::fabs(fl), std::fabs(fr)), inPeak_ * 0.9998f);

        // looper playback (read first so pre-FX routing can feed the effect)
        float lpL = 0.0f, lpR = 0.0f;
        loopRead(lpL, lpR);
        float effL = gl, effR = gr;
        if (c_.prefx) { effL += lpL; effR += lpR; }

        // hold sampler: the effects section sees the frozen loop instead of live input
        stepHold(effL, effR);

        float wetL = 0.0f, wetR = 0.0f;
        if (fxRun) {
            trig_ = false;
            detectOnsets(gl, gr);

            ring_[0].put(writeAbs_, effL); ring_[1].put(writeAbs_, effR);
            ++writeAbs_;
            sigEnv_ = std::max(std::fabs(effL) + std::fabs(effR), sigEnv_ * sigDecay_);
            ++sinceTrig_;

            if (c_.looperOnly) {
                wetL = effL; wetR = effR;
            } else if (wetGate_ > 0.0005f) {
                runEffect(effL, effR);
                renderBuses(wetL, wetR);
                runMultiDelay(effL, effR, wetL, wetR);
                // effects that replace the dry stream (Blocks / Interrupt) cross-fade the input back in
                passGate_ += (passTarget_ - passGate_) * gateC_;
                wetL += effL * passGate_; wetR += effR * passGate_;
            }
            if (c_.stereoMode == 2) {  // WIDE: decorrelate the wet side
                const float m = 0.5f * (wetL + wetR), s = 0.5f * (wetL - wetR);
                wetL = m + s * 1.6f; wetR = m - s * 1.6f;
            }
            wetL *= wetGate_; wetR *= wetGate_;

            // ---- pitch modulation -> reverb -> filter (always on the wet signal)
            mod_.process(wetL, wetR, c_.modDepth, c_.modRate);
            float rl, rr;
            reverb_.process(wetL, wetR, rl, rr);
            wetL = wetL * (1.0f - c_.space) + rl * c_.space * 1.2f;
            wetR = wetR * (1.0f - c_.space) + rr * c_.space * 1.2f;
            filterTick(wetL, wetR);
            // DC block + soft limiter
            dcL_ += 0.0004f * (wetL - dcL_); wetL -= dcL_;
            dcR_ += 0.0004f * (wetR - dcR_); wetR -= dcR_;
            wetL = ob::fxdsp::softClip(wetL * 0.9f); wetR = ob::fxdsp::softClip(wetR * 0.9f);

            const float tail = std::fabs(wetL) + std::fabs(wetR);
            tailEnv_ = std::max(tail, tailEnv_ * 0.9995f);
            if (!enabled) {
                if (!c_.trails && wetGate_ < 0.001f) { killAll(); idle_ = true; }
                else if (tailEnv_ < 1e-5f && ++quiet_ > static_cast<int>(sr_)) { killAll(); idle_ = true; }
            }
        }

        // dry level: balanced by MIX while engaged, full level when bypassed (tails ring on top of it)
        dryG_ += ((enabled ? c_.dg : 1.0f) - dryG_) * gateC_;
        float outL = dryL * dryG_ + wetL * c_.wg;
        float outR = dryR * dryG_ + wetR * c_.wg;

        // looper record/overdub source: post-FX = what the effect section produced, pre-FX = the input
        if (c_.prefx) loopWrite(gl, gr); else loopWrite(outL, outR);
        loopAdvance();
        if (!c_.prefx) {
            loopOutGate_ += (((enabled || c_.trails) ? 1.0f : 0.0f) - loopOutGate_) * gateC_;
            outL += lpL * loopOutGate_; outR += lpR * loopOutGate_;
        }
        if (c_.stereoMode == 3) { const float m = 0.5f * (outL + outR); outL = outR = m; }
        outPeak_ = std::max(std::max(std::fabs(outL), std::fabs(outR)), outPeak_ * 0.9998f);
        if ((statCount_++ & 1023) == 0) publishStatus();
        left = outL; right = outR;
    }

private:
    // ============================================================================== constants
    static constexpr int kVoices = 12;
    static constexpr int kGrains = 40;
    static constexpr int kOnsets = 8;
    enum Fx : int { MOSAIC = 0, SEQ, GLIDE, HAZE, TUNNEL, STRUM, BLOCKS, INTERRUPT, ARP, PATTERN, WARP };

    using Voice = ob::fxdsp::Voice;
    using VoiceParams = ob::fxdsp::VoiceParams;

    struct Grain {
        bool active = false;
        double pos = 0.0; float speed = 1.0f;
        int age = 0, len = 1;
        float amp = 1.0f, pl = 1.0f, pr = 1.0f;
        int win = 0;                  // 0 Hann, 1 trapezoid (hard-edged blocks)
        float lpc = 1.0f, lpl = 0.0f, lpr = 0.0f;
        float crush = 0.0f; int cc = 0; float hl = 0.0f, hr = 0.0f;
    };
    struct Stepper {
        double acc = 0.0; int idx = 0;
        bool tick(double stepLen) { acc += 1.0; if (acc >= stepLen) { acc -= stepLen; ++idx; return true; } return false; }
        void reset() { acc = 0.0; idx = 0; }
    };
    struct Cache {
        bool enabled = false, trails = false, looperOnly = false, prefx = false, revFx = false;
        int effect = 0, var = 0, stereoMode = 0, reverbMode = 1;
        float A = 0.4f, R = 0.35f, S = 0.5f;
        float beatS = 24000.0f, period = 24000.0f, rate = 1.0f;
        float decayT = 1.0f, attack = 0.01f;
        float dg = 1.0f, wg = 0.0f, space = 0.0f;
        float modDepth = 0.0f, modRate = 1.0f;
        float spread = 0.9f;
        float fb = 0.3f;
        float loopSpeed = 1.0f, loopLevel = 0.7f, loopFadeSec = 0.1f;
        bool loopRev = false, quant = false, burst = false, order = false;
    };

    // ================================================================================ helpers
    float param(int id) const { return params_[id].load(std::memory_order_relaxed); }
    float rnd() { rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5; return (rng_ & 0xFFFFFF) * (1.0f / 16777216.0f); }
    float rndS() { return rnd() * 2.0f - 1.0f; }
    static void panGains(float pan, float& l, float& r) {
        const float th = (std::clamp(pan, -1.0f, 1.0f) + 1.0f) * 0.78539816f;
        l = std::cos(th) * 1.41421356f; r = std::sin(th) * 1.41421356f;
    }
    float ageGain(int64_t srcAbs) const {
        if (c_.decayT <= 0.0f) return 1.0f;
        const float age = static_cast<float>(writeAbs_ - srcAbs) / sr_;
        return std::exp(-4.6052f * std::max(0.0f, age) / c_.decayT);
    }
    // Loop length for micro-loop style effects, kept in a musically useful 30..500 ms window.
    int microLen() const {
        float L = c_.period;
        while (L > 0.5f * sr_) L *= 0.5f;
        while (L < 0.03f * sr_) L *= 2.0f;
        return std::min(static_cast<int>(L), vcap_);
    }

    void resetAll() {
        for (auto& r : ring_) r.clear();
        for (auto& d : dl_) d.clear();
        dlActive_ = false;
        killAll();
        writeAbs_ = 0; dlW_ = 0;
        holdActive_ = false; holdXf_ = 0.0f;
        loopState_ = LS_EMPTY; loopLen_ = 0; loopLenPub_.store(0);
        layerClearing_ = false; layerMute_ = false;
        reverb_.reset(); mod_.reset();
        idle_ = true; quiet_ = 0; ctlCount_ = 0;
        beatSm_ = 60.0f / std::clamp(param(TEMPO), 30.0f, 300.0f);
        updateControl();
    }
    void killAll() {
        for (auto& v : voices_) v.active = false;
        for (auto& g : grains_) g.active = false;
        for (auto& t : tapG_) t = 0.0f;
        for (auto& o : onsets_) o = -1;
        onsetCount_ = 0; pendA_ = -1; hintPending_ = -1;
        fbL_ = fbR_ = 0.0f; tailEnv_ = 0.0f; sigEnv_ = 0.0f;
        passGate_ = 0.0f; passTarget_ = 0.0f; interruptSteps_ = 0;
        if (dlActive_) { dl_[0].clear(); dl_[1].clear(); dlActive_ = false; }
    }
    void drainCommands() {
        for (;;) {
            const uint32_t t = qTail_;
            const int c = cmdQ_[t & 15].load(std::memory_order_acquire);
            if (c < 0) break;
            cmdQ_[t & 15].store(-1, std::memory_order_release);
            qTail_ = t + 1;
            applyLoopCommand(c);
        }
        if (hint_.exchange(false, std::memory_order_acq_rel)) hintPending_ = static_cast<int>(0.004f * sr_);
        const bool req = holdReq_.load(std::memory_order_acquire);
        if (req != holdActive_) setHoldInternal(req);
    }

    // ================================================================================ control
    void updateControl() {
        Cache& c = c_;
        c.enabled = param(ENABLE) > 0.5f;
        c.effect = std::clamp(static_cast<int>(std::lround(param(EFFECT) * 10.0f)), 0, 10);
        c.var = std::clamp(static_cast<int>(std::lround(param(VARIATION) * 3.0f)), 0, 3);
        c.A = std::clamp(param(ACTIVITY), 0.0f, 1.0f);
        c.R = std::clamp(param(REPEATS), 0.0f, 1.0f);
        c.S = std::clamp(param(SHAPE), 0.0f, 1.0f);
        c.stereoMode = std::clamp(static_cast<int>(std::lround(param(STEREO_MODE) * 3.0f)), 0, 3);
        c.reverbMode = std::clamp(static_cast<int>(std::lround(param(REVERB_MODE) * 3.0f)), 0, 3);
        const int bm = std::clamp(static_cast<int>(std::lround(param(BYPASS_MODE) * 2.0f)), 0, 2);
        c.trails = (bm == 1) || (param(TRAILS) > 0.5f && bm != 2);
        c.looperOnly = param(LOOP_ONLY) > 0.5f;
        c.prefx = param(LOOP_PREFX) > 0.5f;
        c.revFx = param(REVERSE) > 0.5f;
        c.spread = (c.stereoMode == 0 || c.stereoMode == 3) ? 0.85f : (c.stereoMode == 1 ? 0.7f : 1.0f);

        // tempo: global BPM (slewed so tempo changes accelerate/decelerate smoothly) and subdivision
        const float target = 60.0f / std::clamp(param(TEMPO), 30.0f, 300.0f);
        beatSm_ += (target - beatSm_) * std::min(1.0f, 32.0f / (0.25f * sr_));
        static const float rates[6] = {0.25f, 0.5f, 1.0f, 2.0f, 4.0f, 8.0f};
        const int si = std::clamp(static_cast<int>(std::lround(param(TIME) * 5.0f)), 0, 5);
        c.rate = param(TEMPO_MODE) > 0.5f ? 1.0f : rates[si];
        c.beatS = beatSm_ * sr_;
        c.period = c.beatS / c.rate;
        beatPhase_ += 32.0f / c.beatS; if (beatPhase_ >= 1.0f) beatPhase_ -= 1.0f;

        // Shape -> envelope contour (percussive .. swelling)
        // Repeats -> time to fall 40 dB: 0.4 s .. ~25 s, infinite at the top of the knob
        float dT = c.R >= 0.97f ? 0.0f : 0.4f * std::pow(64.0f, c.R);
        if (c.S < 0.5f && dT > 0.0f) dT *= 0.35f + c.S * 1.3f;
        c.decayT = dT;
        c.attack = 0.004f + std::max(0.0f, c.S - 0.5f) * 0.7f;
        c.fb = 0.05f + 0.88f * c.R;
        sigDecay_ = std::exp(-1.0f / (std::max(0.3f, c.decayT > 0.0f ? c.decayT * 0.5f : 4.0f) * sr_));

        // mix: equal-power balance, effect volume as master
        const float mx = std::clamp(param(MIX), 0.0f, 1.0f);
        c.dg = std::cos(mx * 1.5707963f);
        c.wg = std::sin(mx * 1.5707963f) * (0.2f + 1.6f * std::clamp(param(FX_MASTER), 0.0f, 1.0f));
        c.space = std::clamp(param(SPACE), 0.0f, 1.0f);
        reverb_.setMode(c.reverbMode, c.space);
        c.modDepth = std::clamp(param(PITCH_DEPTH), 0.0f, 1.0f);
        c.modRate = 0.1f * std::pow(80.0f, std::clamp(param(PITCH_RATE), 0.0f, 1.0f));

        // filter at the end of the chain: fully clockwise = bypassed, fully CCW = kills the effect
        const float fx = std::clamp(param(FILTER), 0.0f, 1.0f);
        filtBypassT_ = fx >= 0.99f ? 1.0f : 0.0f;
        const float fc = 40.0f * std::pow(500.0f, std::pow(fx, 0.85f));
        const float res = std::clamp(param(RESONANCE), 0.0f, 1.0f);
        filtCoef_.set(fc, 0.7f + 7.3f * res * res, sr_);

        // looper
        const float sp = std::clamp(param(LOOP_SPEED), 0.0f, 1.0f);
        c.loopSpeed = std::fabs(sp - 0.5f) < 0.02f ? 1.0f : std::pow(4.0f, (sp - 0.5f) * 2.0f);
        c.loopRev = param(LOOP_REVERSE) > 0.5f;
        const float ll = std::clamp(param(LOOP_LEVEL), 0.0f, 1.0f);
        c.loopLevel = ll * ll * 1.6f;
        c.loopFadeSec = 0.005f * std::pow(800.0f, std::clamp(param(LOOP_FADE), 0.0f, 1.0f));
        c.quant = param(LOOP_QUANTIZE) > 0.5f;
        c.burst = param(LOOP_BURST) > 0.5f;
        c.order = param(LOOP_ORDER) > 0.5f;

        calGain_ = std::pow(10.0f, kCalDb[c.effect][c.var] * 0.05f);
        if (!idle_) effectControl();
    }

    void filterTick(float& l, float& r) {
        filtBypass_ += (filtBypassT_ - filtBypass_) * 0.002f;
        float lpL, bpL, lpR, bpR;
        fl_.run(l, filtCoef_, lpL, bpL);
        fr_.run(r, filtCoef_, lpR, bpR);
        l = lpL * (1.0f - filtBypass_) + l * filtBypass_;
        r = lpR * (1.0f - filtBypass_) + r * filtBypass_;
    }

    void publishStatus() {
        status_[ST_LOOP_STATE].store(static_cast<float>(loopState_), std::memory_order_relaxed);
        status_[ST_LOOP_POS].store(loopLen_ > 0 ? static_cast<float>(loopPos_ / loopLen_) : 0.0f, std::memory_order_relaxed);
        status_[ST_LOOP_SECS].store(loopState_ == LS_REC ? recW_ / sr_ : loopLen_ / sr_, std::memory_order_relaxed);
        status_[ST_IN_PEAK].store(inPeak_, std::memory_order_relaxed);
        status_[ST_OUT_PEAK].store(outPeak_, std::memory_order_relaxed);
        status_[ST_BEAT_PHASE].store(beatPhase_, std::memory_order_relaxed);
        status_[ST_HOLD].store(holdActive_ ? 1.0f : 0.0f, std::memory_order_relaxed);
        status_[ST_ONSETS].store(static_cast<float>(onsetCount_), std::memory_order_relaxed);
        int n = 0; for (const auto& v : voices_) n += v.active ? 1 : 0;
        status_[ST_VOICES].store(static_cast<float>(n), std::memory_order_relaxed);
    }

#include "fx_engine_body.inc"

    // ============================================================================ state
    std::atomic<float> params_[FX_PARAM_COUNT];
    std::atomic<int> cmdQ_[16];
    std::atomic<uint32_t> qHead_{0};
    uint32_t qTail_ = 0;
    std::atomic<bool> holdReq_{false}, hint_{false};
    std::atomic<int> loopLenPub_{0};
    std::atomic<float> status_[ST_COUNT];

    bool ready_ = false, idle_ = true;
    float sr_ = 48000.0f, gateC_ = 0.004f;
    uint32_t rng_ = 0x9E3779B9u;
    int ctlCount_ = 0, statCount_ = 0, quiet_ = 0;
    Cache c_;
    float beatSm_ = 0.5f, beatPhase_ = 0.0f;

    // gates / meters
    float dryG_ = 1.0f, inGate_ = 0.0f, wetGate_ = 0.0f, loopOutGate_ = 0.0f, passGate_ = 0.0f, passTarget_ = 0.0f;
    float inPeak_ = 0.0f, outPeak_ = 0.0f, tailEnv_ = 0.0f, dcL_ = 0.0f, dcR_ = 0.0f;

    // capture ring + onsets
    ob::fxdsp::Ring ring_[2];
    int64_t ringN_ = 0, writeAbs_ = 0;
    float sigEnv_ = 0.0f, sigDecay_ = 0.9999f;
    float envFast_ = 0.0f, envSlow_ = 0.0f;
    bool trig_ = false;
    int hintPending_ = -1, refractory_ = 0, sinceTrig_ = 0;
    int64_t onsets_[kOnsets];
    int onsetCount_ = 0;

    // voices / grains
    Voice voices_[kVoices];
    Grain grains_[kGrains];
    int vcap_ = 0;
    uint32_t birthCtr_ = 0;

    // per-effect scheduler state
    Stepper stepA_, stepB_, stepC_, stepD_;
    int pendA_ = -1;
    int grainCd_ = 0;
    int interruptSteps_ = 0;
    float lfoPh_ = 0.0f, lfoPh2_ = 0.0f;
    float seqFilt_ = 0.0f;
    float envFollow_ = 0.0f;

    // multi-delay
    ob::fxdsp::Ring dl_[2];
    int64_t dlN_ = 0, dlW_ = 0;
    bool dlActive_ = false;
    static constexpr int kTaps = 8;
    int nTaps_ = 0;
    float tapT_[kTaps] = {}, tapTgt_[kTaps] = {}, tapG_[kTaps] = {}, tapGt_[kTaps] = {};
    float tapPl_[kTaps] = {}, tapPr_[kTaps] = {}, tapRatio_[kTaps] = {}, tapPhi_[kTaps] = {}, tapMix_[kTaps] = {};
    ob::fxdsp::SvfCoef tapCoef_[kTaps];
    ob::fxdsp::Svf tapSvfL_[kTaps], tapSvfR_[kTaps];
    float fbL_ = 0.0f, fbR_ = 0.0f, mdGate_ = 0.0f;

    // hold sampler
    bool holdActive_ = false;
    std::vector<float> holdL_, holdR_;
    int holdCap_ = 0, holdLen_ = 0;
    float holdPh_ = 0.0f, holdXf_ = 0.0f;

    // reverb / modulation / filter
    ob::fxdsp::FdnReverb reverb_;
    ob::fxdsp::PitchMod mod_;
    ob::fxdsp::SvfCoef filtCoef_;
    ob::fxdsp::Svf fl_, fr_;
    float filtBypass_ = 1.0f, filtBypassT_ = 1.0f;

    // phrase looper
    std::vector<float> phr_[2], lay_[2];
    int loopMax_ = 0, loopLen_ = 0, recW_ = 0;
    int loopState_ = LS_EMPTY;
    double loopPos_ = 0.0;
    float loopFadeG_ = 0.0f;
    bool loopStopping_ = false, layerClearing_ = false, layerMute_ = false;
    int layerClearPos_ = 0;
};
