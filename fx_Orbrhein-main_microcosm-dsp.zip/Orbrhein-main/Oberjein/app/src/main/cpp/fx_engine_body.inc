// Included INSIDE class FxEngine (see fx_engine.h). Not a standalone header.

// ================================================================================== onsets
void registerOnset(int lateSamples) {
    onsets_[onsetCount_ % kOnsets] = writeAbs_ - lateSamples - static_cast<int64_t>(0.003f * sr_);
    ++onsetCount_;
    trig_ = true;
    refractory_ = static_cast<int>(0.055f * sr_);
}
int64_t onsetAbs(int k) const {  // k = 0 newest
    if (k < 0 || k >= kOnsets || k >= onsetCount_) return -1;
    const int64_t v = onsets_[(onsetCount_ - 1 - k) % kOnsets];
    if (v < 0 || writeAbs_ - v > std::min<int64_t>(ringN_ - 512, static_cast<int64_t>(8.0f * sr_))) return -1;
    return v;
}
int liveOnsets() const {
    int n = 0;
    for (int k = 0; k < 4; ++k) if (onsetAbs(k) >= 0) ++n;
    return n;
}
void detectOnsets(float gl, float gr) {
    const float x = std::fabs(gl) + std::fabs(gr);
    const float k48 = 48000.0f / sr_;
    // fast follower: quick attack, ~30 ms release (rides over the ripple of sustained harmonic material)
    envFast_ += (x - envFast_) * (x > envFast_ ? 0.25f : 0.0007f) * k48;
    // slow follower: ~100 ms memory. A real onset is a fast jump well above it.
    envSlow_ += (x - envSlow_) * (x > envSlow_ ? 0.002f : 0.0002f) * k48;
    envFollow_ += (std::min(1.0f, x * 2.0f) - envFollow_) * 0.0008f * k48;
    if (refractory_ > 0) --refractory_;
    if (holdXf_ > 0.5f) { hintPending_ = -1; return; }
    if (hintPending_ >= 0 && --hintPending_ < 0) {
        if (refractory_ <= 0) registerOnset(static_cast<int>(0.004f * sr_));
    }
    if (refractory_ <= 0 && envFast_ > 0.02f && envFast_ > envSlow_ * 2.0f + 0.012f) registerOnset(0);
}

// ================================================================================== voices
Voice* allocVoice() {
    Voice* best = nullptr; float bq = 1e9f;
    for (auto& v : voices_) {
        if (!v.active) return &v;
        const float q = v.amp * v.level;
        if (q < bq) { bq = q; best = &v; }
    }
    return best;
}
Voice* spawnVoice(int64_t srcStart, int len, const VoiceParams& p, bool loop, float startPh = 0.5f) {
    const int64_t avail = writeAbs_ - srcStart;
    if (len < 64 || avail < 64 || srcStart < writeAbs_ - (ringN_ - 256)) return nullptr;
    len = std::min(std::min(len, vcap_), static_cast<int>(std::min<int64_t>(avail, vcap_)));
    if (len < 64) return nullptr;
    Voice* v = allocVoice();
    for (int i = 0; i < len; ++i) {
        v->bl[i] = ring_[0].at(srcStart + i);
        v->br[i] = ring_[1].at(srcStart + i);
    }
    v->active = true; v->loop = loop; v->len = len; v->loopLen = static_cast<float>(len);
    v->ph = std::clamp(startPh, 0.0f, 0.999f);
    const bool rev = c_.revFx;
    v->speed = v->speedTarget = p.speed * ((rev && loop) ? -1.0f : 1.0f);
    if (!loop && rev) v->speed = v->speedTarget = -std::fabs(p.speed);
    v->pos = (!loop && rev) ? static_cast<double>(len - 1) : 0.0;
    v->slew = p.slew;
    v->level = 1.0f; v->amp = 0.0f; v->ampTarget = 1.0f; v->gain = p.gain;
    v->decayMul = p.decayT > 0.0f ? std::exp(-4.6052f / (p.decayT * sr_)) : 1.0f;
    v->atkC = 1.0f - std::exp(-1.0f / (std::max(0.0005f, p.attack) * sr_));
    v->relC = 1.0f - std::exp(-1.0f / (std::max(0.002f, p.release) * sr_));
    panGains(p.pan * c_.spread, v->pl, v->pr);
    v->fmode = p.fmode;
    if (p.fmode) v->fc.set(p.fcut, p.fq, sr_);
    v->sl.reset(); v->sr.reset();
    v->crush = p.crush; v->crushCnt = 0; v->hl = v->hr = 0.0f;
    v->fadeS = std::max(8.0f, p.fade * sr_);
    v->birth = ++birthCtr_; v->tag = p.tag; v->aux = 0;
    return v;
}

void releaseVoice(Voice& v, float sec) {
    v.ampTarget = 0.0f;
    v.relC = 1.0f - std::exp(-1.0f / (std::max(0.005f, sec) * sr_));
}
void releaseTag(int tag, float sec) {
    for (auto& v : voices_) if (v.active && v.tag == tag && v.ampTarget > 0.0f) releaseVoice(v, sec);
}
int countTag(int tag) const {
    int n = 0;
    for (const auto& v : voices_) if (v.active && v.tag == tag && v.ampTarget > 0.0f) ++n;
    return n;
}
void capTag(int tag, int cap) {
    for (;;) {
        int n = 0; Voice* oldest = nullptr;
        for (auto& v : voices_) {
            if (v.active && v.tag == tag && v.ampTarget > 0.0f) {
                ++n; if (!oldest || v.birth < oldest->birth) oldest = &v;
            }
        }
        if (n <= cap || !oldest) break;
        releaseVoice(*oldest, 0.15f);
    }
}
static inline int wrapIdx(int i, int len) { while (i >= len) i -= len; while (i < 0) i += len; return i; }
static inline float vreadLoop(const std::vector<float>& b, int len, float p) {
    const int i = static_cast<int>(p);
    const float t = p - static_cast<float>(i);
    return ob::fxdsp::hermite(b[wrapIdx(i - 1, len)], b[wrapIdx(i, len)], b[wrapIdx(i + 1, len)], b[wrapIdx(i + 2, len)], t);
}
static inline float vreadOnce(const std::vector<float>& b, int len, double p) {
    const int i = static_cast<int>(std::floor(p));
    const float t = static_cast<float>(p - i);
    auto at = [&](int k) { return b[std::clamp(k, 0, len - 1)]; };
    return ob::fxdsp::hermite(at(i - 1), at(i), at(i + 1), at(i + 2), t);
}
inline void voiceTick(Voice& v, float& oL, float& oR) {
    v.speed += (v.speedTarget - v.speed) * v.slew;
    v.amp += (v.ampTarget - v.amp) * (v.ampTarget > v.amp ? v.atkC : v.relC);
    v.level *= v.decayMul;
    if (v.level < 1e-4f || (v.ampTarget <= 0.0f && v.amp < 1e-4f)) { v.active = false; oL = oR = 0.0f; return; }
    float sL, sR, w = 1.0f;
    if (v.loop) {
        const float L = std::max(32.0f, std::min(v.loopLen, static_cast<float>(v.len)));
        const float x1 = v.ph;
        float x2 = x1 + 0.5f; if (x2 >= 1.0f) x2 -= 1.0f;
        const float s = std::sin(ob::fxdsp::kPi * x1), c = std::cos(ob::fxdsp::kPi * x1);
        const float w1 = s * s, w2 = c * c;
        const float p1 = x1 * L, p2 = x2 * L;
        sL = w1 * vreadLoop(v.bl, v.len, p1) + w2 * vreadLoop(v.bl, v.len, p2);
        sR = w1 * vreadLoop(v.br, v.len, p1) + w2 * vreadLoop(v.br, v.len, p2);
        v.ph += v.speed / L;
        if (v.ph >= 1.0f) v.ph -= 1.0f; else if (v.ph < 0.0f) v.ph += 1.0f;
    } else {
        if (v.pos < 0.0 || v.pos >= v.len - 1) { v.active = false; oL = oR = 0.0f; return; }
        const float e = static_cast<float>(std::min(v.pos, static_cast<double>(v.len - 1) - v.pos)) / v.fadeS;
        w = std::min(1.0f, e);
        sL = vreadOnce(v.bl, v.len, v.pos);
        sR = vreadOnce(v.br, v.len, v.pos);
        v.pos += v.speed;
    }
    if (v.fmode) {
        float lp, bp;
        v.sl.run(sL, v.fc, lp, bp); sL = v.fmode == 1 ? lp : bp;
        v.sr.run(sR, v.fc, lp, bp); sR = v.fmode == 1 ? lp : bp;
    }
    if (v.crush > 0.0f) {
        const int div = 1 + static_cast<int>(v.crush * 6.0f);
        if (v.crushCnt++ % div == 0) {
            const float q = std::exp2(11.0f - 8.0f * v.crush);
            v.hl = std::round(sL * q) / q; v.hr = std::round(sR * q) / q;
        }
        sL = v.hl; sR = v.hr;
    }
    const float g = v.amp * v.level * v.gain * w;
    oL = sL * g * v.pl; oR = sR * g * v.pr;
}

// ================================================================================== grains
bool placeGrain(double& start, int& len, float speed) {
    const float as = std::max(0.05f, std::fabs(speed));
    const double latest = static_cast<double>(writeAbs_) - 8.0 - static_cast<double>(len) * as;
    if (start > latest) {  // too close to the write head: pull back before shortening
        start = latest;
    }
    if (start < static_cast<double>(writeAbs_ - (ringN_ - 256))) return false;
    return len >= 48;
}
void spawnGrain(double start, int len, float speed, float amp, float pan, int win, float lpc, float crush, bool forceRev = false) {
    if (amp < 1e-4f) return;
    if (!placeGrain(start, len, speed)) return;
    Grain* g = nullptr; int maxAge = -1;
    for (auto& c : grains_) {
        if (!c.active) { g = &c; break; }
        if (c.age > maxAge) { maxAge = c.age; g = &c; }
    }
    const bool rev = c_.revFx != forceRev;
    g->active = true; g->age = 0; g->len = len; g->amp = amp; g->win = win;
    g->speed = rev ? -std::fabs(speed) : std::fabs(speed);
    g->pos = rev ? start + static_cast<double>(len) * std::fabs(speed) : start;
    panGains(pan * c_.spread, g->pl, g->pr);
    g->lpc = lpc; g->lpl = g->lpr = 0.0f;
    g->crush = crush; g->cc = 0; g->hl = g->hr = 0.0f;
}
inline void grainTick(Grain& g, float& oL, float& oR) {
    if (g.pos > static_cast<double>(writeAbs_) - 4.0 || g.pos < static_cast<double>(writeAbs_ - (ringN_ - 64))) {
        g.active = false; oL = oR = 0.0f; return;
    }
    float w;
    if (g.win == 0) {
        const float s = std::sin(ob::fxdsp::kPi * static_cast<float>(g.age) / static_cast<float>(g.len));
        w = s * s;
    } else {
        const float ramp = std::max(8.0f, 0.003f * sr_);
        w = std::min(1.0f, static_cast<float>(std::min(g.age, g.len - g.age)) / ramp);
    }
    float sL = ring_[0].read(g.pos), sR = ring_[1].read(g.pos);
    if (g.lpc < 1.0f) {
        g.lpl += g.lpc * (sL - g.lpl); g.lpr += g.lpc * (sR - g.lpr);
        sL = g.lpl; sR = g.lpr;
    }
    if (g.crush > 0.0f) {
        const int div = 1 + static_cast<int>(g.crush * 6.0f);
        if (g.cc++ % div == 0) {
            const float q = std::exp2(11.0f - 8.0f * g.crush);
            g.hl = std::round(sL * q) / q; g.hr = std::round(sR * q) / q;
        }
        sL = g.hl; sR = g.hr;
    }
    g.pos += g.speed;
    if (++g.age >= g.len) g.active = false;
    oL = sL * w * g.amp * g.pl; oR = sR * w * g.amp * g.pr;
}
void renderBuses(float& wetL, float& wetR) {
    float aL = 0.0f, aR = 0.0f, l, r;
    for (auto& v : voices_) if (v.active) { voiceTick(v, l, r); aL += l; aR += r; }
    for (auto& g : grains_) if (g.active) { grainTick(g, l, r); aL += l; aR += r; }
    wetL += aL * 0.8f * calGain_; wetR += aR * 0.8f * calGain_;
}

// ============================================================================ effect control
// Runs every 32 samples: slow modulators, glide speeds, tunnel modulation, multi-delay taps.
void effectControl() {
    const int e = c_.effect;
    if (e != prevEffect_ || c_.var != prevVar_) {
        // loop-type voices from the previous algorithm fade out (grains/one-shots end on their own)
        if (e != prevEffect_) { releaseTag(1, 0.35f); releaseTag(2, 0.35f); releaseTag(3, 0.35f); releaseTag(9, 0.35f); }
        else { releaseTag(2, 0.2f); releaseTag(3, 0.2f); }
        stepA_.reset(); stepB_.reset(); stepC_.reset(); stepD_.reset();
        pendA_ = -1; burstLeft_ = 0; interruptSteps_ = 0; passTarget_ = 1.0f;
        prevEffect_ = e; prevVar_ = c_.var;
    }
    // Blocks/Interrupt pass the (time-aligned) input; everything else leaves the dry to the mix knob
    if (e != BLOCKS && e != INTERRUPT) passTarget_ = 0.0f;
    lfoPh_ += 32.0f / (c_.period * 8.0f); if (lfoPh_ >= 1.0f) lfoPh_ -= 1.0f;

    if (e == GLIDE) updateGlide();
    if (e == TUNNEL) updateTunnel();
    if (!(e == SEQ && c_.var == 1 && c_.A > 0.97f)) releaseTag(9, 0.5f);
    updateTaps(e);
}

// ===================================================================================== effects
void runEffect(float, float) {
    switch (c_.effect) {
        case MOSAIC: runMosaic(); break;
        case SEQ: runSeq(); break;
        case GLIDE: runGlide(); break;
        case HAZE: runHaze(); break;
        case TUNNEL: runTunnel(); break;
        case STRUM: runStrum(); break;
        case BLOCKS: runBlocks(); break;
        case INTERRUPT: runInterrupt(); break;
        case ARP: runArp(); break;
        default: break;  // PATTERN / WARP live in the multi-delay
    }
}

// Shared "when do we (re)capture a micro-loop" logic: shortly after each onset, and periodically
// while sustained material is playing. Returns true when a capture should happen now.
bool captureTrigger(int L, float& startPh) {
    const int delay = std::min(L / 2, static_cast<int>(0.15f * sr_));
    if (trig_ && pendA_ < 0) pendA_ = delay;  // one pending capture at a time (bursts of onsets share it)
    startPh = 0.5f;
    if (pendA_ >= 0 && --pendA_ < 0) {
        startPh = std::clamp(1.0f - static_cast<float>(delay) / static_cast<float>(L), 0.0f, 0.99f);
        sinceTrig_ = 0;
        return true;
    }
    const int recap = static_cast<int>(std::clamp(c_.period * 4.0f, 0.25f * sr_, 1.2f * sr_));
    if (pendA_ < 0 && sinceTrig_ > recap && sigEnv_ > 0.02f) { sinceTrig_ = 0; return true; }
    return false;
}
VoiceParams baseVoice(int tag, float gain) const {
    VoiceParams p; p.tag = tag; p.gain = gain; p.decayT = c_.decayT; p.attack = c_.attack; p.release = 0.12f;
    return p;
}

// ------------------------------------------------------------------------------------ MOSAIC
void runMosaic() {
    const int L = microLen();
    float ph;
    if (!captureTrigger(L, ph)) return;
    static const float spd[4][4] = {{1, 2, 1, 2}, {1, 0.5f, 1, 0.5f}, {2, 2, 2, 2}, {0.5f, 1, 2, 4}};
    static const float lm[4] = {1.0f, 0.75f, 1.5f, 0.5f};
    const int K = c_.var == 3 ? 4 : 2;
    for (int k = 0; k < K; ++k) {
        const int len = std::max(64, static_cast<int>(L * lm[k]));
        VoiceParams p = baseVoice(1, c_.var == 3 ? 0.4f : 0.5f);
        p.speed = spd[c_.var][k];
        p.pan = ((k & 1) ? 1.0f : -1.0f) * (0.35f + 0.35f * static_cast<float>(k / 2));
        spawnVoice(writeAbs_ - len, len, p, true, ph);
    }
    capTag(1, 2 + static_cast<int>(std::lround(c_.A * 6.0f)));
}

// --------------------------------------------------------------------------------------- SEQ
void runSeq() {
    const double step = std::max<double>(c_.period * 0.5, 0.045 * sr_);
    if (!stepA_.tick(step)) return;
    const int n = liveOnsets();
    if (n == 0) return;
    const int idx = stepA_.idx;
    const float A = c_.A;
    bool fire = true; int layers = 1;
    switch (c_.var) {
        case 0: fire = rnd() < 0.55f + 0.25f * A; break;
        case 1: break;
        case 2: fire = rnd() < 0.8f; layers = 1 + static_cast<int>(std::lround(A * 2.0f)); break;
        default: { static const bool pat[8] = {1, 0, 1, 1, 0, 1, 0, 1}; fire = pat[idx & 7] || rnd() < A * 0.35f; layers = 1 + (A > 0.5f ? 1 : 0); }
    }
    if (c_.var == 1 && A > 0.97f && countTag(9) == 0) {  // sustainer pad under the sequence
        const int len = static_cast<int>(0.4f * sr_);
        VoiceParams p = baseVoice(9, 0.3f); p.decayT = 0.0f; p.attack = 0.5f; p.pan = 0.0f;
        spawnVoice(writeAbs_ - len, len, p, true, 0.5f);
    }
    if (!fire) return;
    for (int l = 0; l < layers; ++l) {
        const int64_t src = onsetAbs(static_cast<int>(rnd() * n));
        if (src < 0) continue;
        VoiceParams p = baseVoice(0, 0.62f / std::sqrt(static_cast<float>(layers)));
        p.decayT = 0.0f; p.gain *= ageGain(src); p.pan = rndS() * 0.8f; p.fade = 0.004f;
        float spd = 1.0f;
        if (c_.var == 0) {
            p.fmode = 1; p.fq = 1.2f;
            p.fcut = 400.0f * std::pow(30.0f, 0.9f * (1.0f - A) + A * rnd());
        } else if (c_.var == 1) {
            spd = rnd() < (0.15f + 0.7f * A) ? 0.5f : 1.0f;
        } else if (c_.var == 2) {
            p.fmode = 1; p.fq = 2.0f;
            p.fcut = 300.0f * std::pow(40.0f, 0.5f - 0.5f * std::cos(idx * 0.37f + l * 2.0f));
        } else {
            spd = l == 1 ? 2.0f : 1.0f; p.crush = 0.45f;
        }
        p.speed = spd;
        const int len = static_cast<int>(step * (0.95f + (layers > 1 ? 0.6f : 0.0f)) * spd);
        spawnVoice(src - static_cast<int64_t>(0.002f * sr_), len, p, false);
    }
    if (c_.var == 3 && A > 0.97f) {  // bit-crushed sub-octave layer
        const int64_t src = onsetAbs(0);
        if (src >= 0) {
            VoiceParams p = baseVoice(0, 0.5f); p.decayT = 0.0f; p.speed = 0.5f; p.crush = 0.8f; p.gain *= ageGain(src);
            spawnVoice(src - static_cast<int64_t>(0.002f * sr_), static_cast<int>(step * 0.5), p, false);
        }
    }
}

// ------------------------------------------------------------------------------------- GLIDE
static float glideShape(float ph, float S) {
    const float sine = 0.5f - 0.5f * std::cos(ob::fxdsp::kTwoPi * ph);
    const float tri = 1.0f - std::fabs(2.0f * ph - 1.0f);
    const float arr[4] = {sine, tri, ph, 1.0f - ph};
    const float s4 = std::clamp(S, 0.0f, 1.0f) * 3.0f;
    const int seg = std::min(2, static_cast<int>(s4));
    const float f = s4 - static_cast<float>(seg);
    return arr[seg] * (1.0f - f) + arr[seg + 1] * f;
}
void runGlide() {
    const int L = microLen();
    float ph;
    if (!captureTrigger(L, ph) ) return;
    releaseTag(2, 0.2f);
    const int nG = c_.var == 3 ? 3 : 2;
    for (int j = 0; j < nG; ++j) {
        const int len = std::max(64, static_cast<int>(L * (1.0f + 0.17f * j)));
        VoiceParams p = baseVoice(2, 0.5f);
        p.attack = 0.15f; p.slew = 0.01f; p.pan = (j == 0 ? -0.5f : (j == 1 ? 0.5f : 0.0f));
        Voice* v = spawnVoice(writeAbs_ - len, len, p, true, ph);
        if (v) v->aux = j;
    }
    updateGlide();
}
void updateGlide() {
    glidePh_ += 32.0f / (c_.period * (16.0f - 14.5f * c_.A));
    if (glidePh_ >= 1.0f) glidePh_ -= 1.0f;
    float lo = 0.5f, hi = 1.0f;
    if (c_.var == 1 || c_.var == 3) { lo = 0.5f; hi = 2.0f; } else if (c_.var == 2) { lo = 1.0f; hi = 2.0f; }
    for (auto& v : voices_) {
        if (!v.active || v.tag != 2 || v.ampTarget <= 0.0f) continue;
        float ph = glidePh_ + 0.5f * v.aux; ph -= std::floor(ph);
        float lfo = glideShape(ph, c_.S);
        if (c_.var == 3 && (v.aux & 1)) lfo = 1.0f - lfo;
        const float sp = lo * std::pow(hi / lo, lfo);
        v.speedTarget = c_.revFx ? -sp : sp;
    }
}

// -------------------------------------------------------------------------------------- HAZE
void runHaze() {
    if (--grainCd_ > 0) return;
    if (sigEnv_ < 0.003f) { grainCd_ = 256; return; }
    const float A = c_.A;
    const float dens = (4.0f + A * 70.0f) * (c_.var == 1 ? 1.6f : 1.0f);
    grainCd_ = std::max(1, static_cast<int>(sr_ / dens * (0.5f + rnd())));
    float lenS, spreadS, speed = 1.0f;
    switch (c_.var) {
        case 0: lenS = 0.09f; spreadS = 0.05f + 0.5f * A; break;
        case 1: lenS = 0.2f * (0.7f + 0.6f * rnd()); spreadS = 0.2f + 2.5f * A; break;
        case 2: lenS = 0.12f; spreadS = 0.1f + 1.2f * A; speed = rnd() < 0.5f ? 1.0f : 2.0f; break;
        default: lenS = 0.12f; spreadS = 0.1f + 1.2f * A; speed = rnd() < 0.5f ? 1.0f : 0.5f; break;
    }
    int len = static_cast<int>(lenS * sr_);
    double start = static_cast<double>(writeAbs_) - (0.04f + rnd() * spreadS) * sr_ - len * speed;
    const float amp = 0.85f / std::sqrt(std::max(1.0f, dens * lenS)) * ageGain(static_cast<int64_t>(start));
    spawnGrain(start, len, speed, amp, rndS() * (0.3f + 0.7f * A), 0, 1.0f, 0.0f);
}

// ------------------------------------------------------------------------------------ TUNNEL
void runTunnel() {
    const int L = microLen();
    float ph;
    if (!captureTrigger(L, ph)) return;
    releaseTag(3, 0.3f);
    static const float lm[3] = {1.0f, 1.5f, 0.75f};
    const int nV = 2 + (c_.A > 0.5f ? 1 : 0);
    for (int j = 0; j < nV; ++j) {
        const int len = std::max(64, static_cast<int>(L * lm[j]));
        VoiceParams p = baseVoice(3, 0.45f);
        p.attack = 0.25f; p.release = 0.3f; p.speed = c_.var == 1 ? 0.5f : 1.0f;
        p.pan = (j == 0 ? -0.6f : (j == 1 ? 0.6f : 0.0f));
        if (c_.var == 1) { p.fmode = 1; p.fcut = 800.0f; p.fq = 1.3f; }
        if (c_.var == 2) { p.fmode = 2; p.fcut = 440.0f * std::pow(2.0f, j); p.fq = 6.0f + 8.0f * c_.A; p.gain *= 3.0f; }
        Voice* v = spawnVoice(writeAbs_ - len, len, p, true, ph);
        if (v) { v->aux = j; v->auxLen = static_cast<float>(v->len); }
    }
    updateTunnel();
}
void updateTunnel() {
    tunPh_ += 32.0f / (c_.period * (24.0f - 18.0f * c_.A));
    if (tunPh_ >= 1.0f) tunPh_ -= 1.0f;
    const float A = c_.A;
    for (auto& v : voices_) {
        if (!v.active || v.tag != 3 || v.ampTarget <= 0.0f) continue;
        const float lfo = 0.5f + 0.5f * std::sin(ob::fxdsp::kTwoPi * (tunPh_ + 0.33f * v.aux));
        switch (c_.var) {
            case 0: v.loopLen = std::max(64.0f, v.auxLen * std::exp2(-A * lfo)); break;
            case 1: { const float x = 0.5f + (lfo - 0.5f) * (0.3f + 0.7f * A);
                      v.fc.set(150.0f * std::pow(80.0f, x), 1.3f, sr_); break; }
            case 2: { const float fc = 220.0f * std::exp2(v.aux * 1.5f + 2.0f * A * lfo);
                      v.fc.set(fc, 6.0f + 8.0f * A, sr_); break; }
            default: v.loopLen = std::max(64.0f, v.auxLen * std::exp2(-A * 2.0f * envFollow_)); break;
        }
    }
}

// ------------------------------------------------------------------------------------ STRUM
void runStrum() {
    const int n = liveOnsets();
    if (n == 0) return;
    const int steps = 1 + static_cast<int>(std::lround(c_.A * 5.0f));
    const double step = std::max<double>(c_.period / steps, 0.03 * sr_);
    if (stepA_.tick(step)) strumGrain(stepA_.idx, n, step, 0);
    if (c_.var == 1) {  // phasing: slightly detuned copies of the same onset
        if (stepB_.tick(step * 1.013)) strumGrain(stepB_.idx, n, step, 1);
        if (stepC_.tick(step * 1.031)) strumGrain(stepC_.idx, n, step, 2);
    }
}
void strumGrain(int idx, int n, double step, int copy) {
    const int k = (c_.var >= 2) ? idx % std::min(n, 4) : 0;
    const int64_t src = onsetAbs(k);
    if (src < 0) return;
    const float speed = (c_.var == 3 && (idx & 1)) ? 2.0f : 1.0f;
    int len = static_cast<int>(std::clamp(step * 0.85, 0.03 * sr_, 0.18 * sr_));
    const float amp = (c_.var == 1 ? 0.5f : 0.75f) * ageGain(src);
    const float pan = c_.var == 1 ? (copy - 1) * 0.6f : ((idx & 1) ? 0.3f : -0.3f);
    spawnGrain(static_cast<double>(src), len, speed, amp, pan, 0, 1.0f, 0.0f);
}

// ----------------------------------------------------------------- BLOCKS / INTERRUPT / ARP
struct Burst { int64_t src = 0; int len = 0; float speed = 1.0f, lpc = 1.0f, crush = 0.0f, amp = 0.7f; bool rev = false, onsets = false; int idx = 0; int win = 1; double stepLen = 0.0; };
Burst burst_;
int burstLeft_ = 0;

void burstSpawn() {
    Burst& b = burst_;
    int64_t src = b.src;
    if (b.onsets) { const int n = liveOnsets(); if (n > 0) { const int64_t o = onsetAbs(b.idx % n); if (o >= 0) src = o; } ++b.idx; }
    // live blocks are gated by signal presence; only re-used (older) note onsets decay with age
    spawnGrain(static_cast<double>(src), b.len, b.speed, b.amp * (b.onsets ? ageGain(src) : 1.0f), rndS() * 0.5f, b.win, b.lpc, b.crush, b.rev);
}
float pitchPick() { static const float set[6] = {0.5f, 0.75f, 1.25f, 1.5f, 2.0f, 1.0f}; return set[static_cast<int>(rnd() * 6.0f) % 6]; }

void runBlocks() {
    const double blk = std::clamp<double>(c_.period * 0.5, 0.04 * sr_, 0.4 * sr_);
    if (burstLeft_ > 0 && stepC_.tick(burst_.stepLen)) { --burstLeft_; burstSpawn(); }
    if (!stepB_.tick(blk)) return;
    const float A = c_.A;
    if (sigEnv_ < 0.003f || rnd() >= 0.25f + 0.65f * A) { passTarget_ = 1.0f; return; }
    passTarget_ = 0.0f;
    Burst& b = burst_;
    b = Burst();
    b.len = static_cast<int>(blk);
    const int back = static_cast<int>((1 + static_cast<int>(rnd() * 4.0f)) * blk);
    b.src = writeAbs_ - back;
    b.amp = 0.8f;
    switch (c_.var) {
        case 0: {
            const int ratchets = 1 + (rnd() < A ? 1 + static_cast<int>(rnd() * 3.0f) : 0);
            b.len = static_cast<int>(blk / ratchets); b.stepLen = blk / ratchets;
            if (ratchets > 1 && liveOnsets() > 0) { b.onsets = true; b.idx = static_cast<int>(rnd() * 4.0f); }
            burstLeft_ = ratchets - 1; stepC_.reset();
            break; }
        case 1: b.speed = rnd() < A ? pitchPick() : 1.0f; break;
        case 2: b.len = static_cast<int>(blk * 1.8); b.win = 0; b.lpc = 0.12f + 0.2f * (1.0f - A); b.amp = 0.6f; break;
        default: b.speed = pitchPick(); b.crush = 0.35f + 0.4f * A; break;
    }
    burstSpawn();
}
void runInterrupt() {
    const double blk = std::clamp<double>(c_.period * 0.5, 0.04 * sr_, 0.4 * sr_);
    if (burstLeft_ > 0 && stepC_.tick(burst_.stepLen)) { --burstLeft_; burstSpawn(); }
    if (!stepB_.tick(blk)) return;
    const float A = c_.A;
    if (sigEnv_ < 0.003f) { interruptSteps_ = 0; passTarget_ = 1.0f; return; }
    if (interruptSteps_ > 0) {
        if (--interruptSteps_ == 0) { passTarget_ = 1.0f; return; }
    } else {
        if (rnd() >= 0.04f + 0.5f * c_.R) { passTarget_ = 1.0f; return; }
        interruptSteps_ = 1 + static_cast<int>(rnd() * (1.0f + 3.0f * A));
        passTarget_ = 0.0f;
    }
    // a stutter of the most recent slice, optionally pitch-shifted / filtered / crushed / echoed
    Burst& b = burst_;
    b = Burst();
    const int ratchets = rnd() < 0.5f ? 1 : (rnd() < 0.5f ? 2 : 4);
    b.len = static_cast<int>(blk / ratchets); b.stepLen = blk / ratchets;
    b.src = writeAbs_ - static_cast<int64_t>(b.len * 1.5) - 16;
    b.amp = 0.85f;
    const bool vary = rnd() < 0.2f + 0.8f * A;
    switch (c_.var) {
        case 0: b.rev = vary && rnd() < 0.5f; break;
        case 1: b.speed = vary ? pitchPick() : 1.0f; break;
        case 2: b.lpc = 0.05f + 0.45f * rnd(); b.win = 1;
                spawnGrain(static_cast<double>(b.src - b.len), b.len, 1.0f, 0.35f, rndS() * 0.6f, 1, b.lpc, 0.0f); break;
        default: b.speed = vary ? pitchPick() : 1.0f; b.crush = 0.5f + 0.4f * rnd(); b.rev = vary && rnd() < 0.5f; break;
    }
    burstLeft_ = ratchets - 1; stepC_.reset();
    burstSpawn();
}
void runArp() {
    const double step = std::max<double>(c_.period * 0.5, 0.05 * sr_);
    if (!stepA_.tick(step)) return;
    const int n = liveOnsets();
    if (n == 0) return;
    const int steps = 2 + static_cast<int>(std::lround(c_.A * 6.0f));
    const int s = stepA_.idx % steps;
    int k = 0;
    if (n > 1) { const int cyc = 2 * n - 2; const int m = s % cyc; k = m < n ? m : cyc - m; }
    const int64_t src = onsetAbs(k);
    if (src < 0) return;
    VoiceParams p = baseVoice(0, 0.66f);
    p.decayT = 0.0f; p.gain *= ageGain(src); p.pan = (s & 1) ? 0.4f : -0.4f; p.fade = 0.003f;
    float spd = 1.0f;
    static const float ratios[6] = {1.0f, 1.5f, 2.0f, 0.75f, 1.25f, 0.5f};
    if (c_.var == 1) spd = ratios[s % 6];
    if (c_.var == 2) { p.fmode = rnd() < 0.7f ? 1 : 2; p.fcut = 300.0f * std::pow(27.0f, rnd()); p.fq = 2.5f; }
    if (c_.var == 3) { p.crush = 0.45f; spd = (s & 1) ? 0.5f : 1.0f; }
    p.speed = spd;
    spawnVoice(src - static_cast<int64_t>(0.002f * sr_), static_cast<int>(step * 0.95 * spd), p, false);
}

// ===================================================================== PATTERN / WARP (multi-delay)
void updateTaps(int e) {
    const bool md = (e == PATTERN || e == WARP);
    if (md) dlActive_ = true;
    for (int k = 0; k < kTaps; ++k) tapGt_[k] = 0.0f;
    if (!md) { nTaps_ = 0; return; }
    static const float pat[4][8] = {
        {1, 2, 3, 4, 5, 6, 7, 8},
        {0.75f, 1.5f, 2.25f, 3, 3.75f, 4.5f, 5.25f, 6},
        {1, 1.667f, 2, 2.667f, 3.333f, 4, 4.667f, 5.333f},
        {2, 3, 3.5f, 3.75f, 5.75f, 6.75f, 7.25f, 7.5f}};
    static const float gold[6] = {0.5f, 1.0f, 1.618f, 2.618f, 3.5f, 4.236f};
    float T; float mult[kTaps]; int n;
    if (e == PATTERN) {
        n = 1 + static_cast<int>(std::lround(c_.A * 7.0f)); T = c_.period;
        for (int k = 0; k < n; ++k) mult[k] = pat[c_.var][k];
    } else {
        n = 1 + static_cast<int>(std::lround(c_.A * 5.0f)); T = c_.period * 0.5f;
        for (int k = 0; k < n; ++k) mult[k] = gold[k];
    }
    float maxM = 0.0f; for (int k = 0; k < n; ++k) maxM = std::max(maxM, mult[k]);
    while (T < 0.06f * sr_) T *= 2.0f;
    while (maxM * T > 3.5f * sr_) T *= 0.5f;
    nTaps_ = n;
    // Shape: contour of tap levels (decaying .. flat .. crescendo)
    const float slope = (0.5f - c_.S) * 2.0f;
    float gmax = 0.0f; float g[kTaps];
    for (int k = 0; k < n; ++k) { g[k] = std::exp(-slope * 0.45f * k); gmax = std::max(gmax, g[k]); }
    const float norm = 1.15f / std::sqrt(static_cast<float>(n));
    for (int k = 0; k < n; ++k) {
        tapTgt_[k] = mult[k] * T;
        if (tapG_[k] < 1e-4f) tapT_[k] = tapTgt_[k];
        tapGt_[k] = g[k] / gmax * norm;
        const float pan = ((k & 1) ? 1.0f : -1.0f) * 0.7f * c_.spread;
        panGains(pan, tapPl_[k], tapPr_[k]);
        tapPl_[k] *= 0.71f; tapPr_[k] *= 0.71f;
    }
    if (e == WARP) {
        static const float shiftSet[6] = {1.5f, 0.75f, 2.0f, 1.25f, 0.5f, 1.125f};
        for (int k = 0; k < n; ++k) {
            if (c_.var == 0) {  // envelope-controlled low-pass per tap
                const float x = std::clamp(envFollow_ * (0.5f + 0.8f * k / n) * (0.5f + c_.A), 0.0f, 1.0f);
                tapCoef_[k].set(250.0f * std::pow(32.0f, x), 1.4f, sr_);
            } else if (c_.var == 1) {  // resonant band-pass per tap
                const float fc = 300.0f * std::exp2(k * 0.75f + 0.5f * std::sin(ob::fxdsp::kTwoPi * (lfoPh_ + 0.17f * k)));
                tapCoef_[k].set(fc, 7.0f, sr_);
            } else if (c_.var == 2) {
                tapRatio_[k] = shiftSet[k % 6];
            } else {
                tapRatio_[k] = 2.0f;
                tapMix_[k] = 0.5f + 0.5f * std::sin(ob::fxdsp::kTwoPi * (lfoPh_ * 2.0f + 0.21f * k));
            }
        }
    }
}
inline void readShifted(int k, float d0, float W, float ratio, float& l, float& r) {
    float phi = tapPhi_[k];
    phi += (1.0f - ratio) / W;
    phi -= std::floor(phi);
    tapPhi_[k] = phi;
    float phi2 = phi + 0.5f; phi2 -= std::floor(phi2);
    const float s = std::sin(ob::fxdsp::kPi * phi), c = std::cos(ob::fxdsp::kPi * phi);
    const float w1 = s * s, w2 = c * c;
    const double p1 = static_cast<double>(dlW_) - (d0 + phi * W);
    const double p2 = static_cast<double>(dlW_) - (d0 + phi2 * W);
    l = w1 * dl_[0].read(p1) + w2 * dl_[0].read(p2);
    r = w1 * dl_[1].read(p1) + w2 * dl_[1].read(p2);
}
void runMultiDelay(float inL, float inR, float& wetL, float& wetR) {
    mdGate_ += (((c_.effect == PATTERN || c_.effect == WARP) ? 1.0f : 0.0f) - mdGate_) * gateC_;
    if (!dlActive_) return;
    const float W = 0.06f * sr_;
    float oL = 0.0f, oR = 0.0f, lastL = 0.0f, lastR = 0.0f;
    int lastK = -1;
    for (int k = 0; k < nTaps_; ++k) if (tapGt_[k] > 0.0f) lastK = k;
    float anyGain = 0.0f;
    for (int k = 0; k < kTaps; ++k) {
        tapT_[k] += (tapTgt_[k] - tapT_[k]) * 0.0006f;
        tapG_[k] += (tapGt_[k] - tapG_[k]) * 0.001f;
        anyGain += tapG_[k];
        if (tapG_[k] < 1e-4f && tapGt_[k] <= 0.0f) continue;
        const float d = std::clamp(tapT_[k], 4.0f, static_cast<float>(dlN_) - W - 16.0f);
        float l, r;
        if (c_.effect == WARP && c_.var == 2) {
            readShifted(k, d, W, tapRatio_[k], l, r);
        } else if (c_.effect == WARP && c_.var == 3) {
            const double p = static_cast<double>(dlW_) - d;
            const float nl = dl_[0].read(p), nr = dl_[1].read(p);
            float sl, sr2; readShifted(k, d, W, 2.0f, sl, sr2);
            const float m = tapMix_[k];
            l = nl * (1.0f - m) + sl * m; r = nr * (1.0f - m) + sr2 * m;
        } else {
            const double p = static_cast<double>(dlW_) - d;
            l = dl_[0].read(p); r = dl_[1].read(p);
            if (c_.effect == WARP && c_.var <= 1) {
                float lp, bp;
                tapSvfL_[k].run(l, tapCoef_[k], lp, bp); l = c_.var == 0 ? lp : bp * 1.6f;
                tapSvfR_[k].run(r, tapCoef_[k], lp, bp); r = c_.var == 0 ? lp : bp * 1.6f;
            }
        }
        oL += l * tapG_[k] * tapPl_[k]; oR += r * tapG_[k] * tapPr_[k];
        if (k == lastK) { lastL = l; lastR = r; }
    }
    // damped, cross-fed (ping-pong) feedback from the longest tap
    // Repeats sets the decay TIME (not a raw gain): feedback per pass follows the longest tap so that
    // the tail takes ~decayT seconds to fall 60 dB whatever the loop length is.
    float fb = 0.97f;
    if (c_.decayT > 0.0f && lastK >= 0) {
        const float passSec = std::max(0.05f, tapTgt_[lastK] / sr_);
        fb = std::min(0.97f, std::pow(10.0f, -2.0f * passSec / c_.decayT));
    }
    fbL_ = ob::fxdsp::flush(fbL_ + 0.45f * (lastL - fbL_));
    fbR_ = ob::fxdsp::flush(fbR_ + 0.45f * (lastR - fbR_));
    const float wl = inL * mdGate_ + fb * fbR_;
    const float wr = inR * mdGate_ + fb * fbL_;
    dl_[0].put(dlW_, ob::fxdsp::softClip(wl));
    dl_[1].put(dlW_, ob::fxdsp::softClip(wr));
    ++dlW_;
    wetL += oL * 0.95f * calGain_; wetR += oR * 0.95f * calGain_;
    if (c_.effect != PATTERN && c_.effect != WARP && anyGain < 1e-4f && std::fabs(fbL_) + std::fabs(fbR_) < 1e-6f) {
        dl_[0].clear(); dl_[1].clear(); dlActive_ = false;
    }
}

// ================================================================================ hold sampler
void setHoldInternal(bool on) {
    if (on) {
        holdLen_ = std::clamp(static_cast<int>(c_.beatS), static_cast<int>(0.3f * sr_), std::min(holdCap_, static_cast<int>(1.5f * sr_)));
        for (int i = 0; i < holdLen_; ++i) {
            holdL_[i] = ring_[0].at(writeAbs_ - holdLen_ + i);
            holdR_[i] = ring_[1].at(writeAbs_ - holdLen_ + i);
        }
        holdPh_ = 0.0f;
        idle_ = false; quiet_ = 0;
    }
    holdActive_ = on;
}
void stepHold(float& effL, float& effR) {
    holdXf_ += ((holdActive_ ? 1.0f : 0.0f) - holdXf_) * (1.0f / (0.04f * sr_));
    if (holdXf_ < 1e-4f) { if (!holdActive_) holdXf_ = 0.0f; return; }
    const int len = holdLen_;
    const float x1 = holdPh_;
    float x2 = x1 + 0.5f; if (x2 >= 1.0f) x2 -= 1.0f;
    const float s = std::sin(ob::fxdsp::kPi * x1), c = std::cos(ob::fxdsp::kPi * x1);
    const int i1 = std::min(len - 1, static_cast<int>(x1 * len)), i2 = std::min(len - 1, static_cast<int>(x2 * len));
    const float hl = s * s * holdL_[i1] + c * c * holdL_[i2];
    const float hr = s * s * holdR_[i1] + c * c * holdR_[i2];
    holdPh_ += 1.0f / static_cast<float>(len);
    if (holdPh_ >= 1.0f) holdPh_ -= 1.0f;
    effL = effL * (1.0f - holdXf_) + hl * holdXf_;
    effR = effR * (1.0f - holdXf_) + hr * holdXf_;
}

// ================================================================================ phrase looper
void beginLayerClear() { layerClearing_ = true; layerClearPos_ = 0; layerMute_ = true; }
void resyncClock() { stepA_.reset(); stepB_.reset(); stepC_.reset(); stepD_.reset(); beatPhase_ = 0.0f; pendA_ = -1; }
void startRec() {
    loopState_ = LS_REC; recW_ = 0; loopLen_ = 0; loopLenPub_.store(0);
    loopStopping_ = false; beginLayerClear();
    if (c_.quant) resyncClock();
}
void startPlay() { loopPos_ = 0.0; loopFadeG_ = 0.0f; loopStopping_ = false; loopState_ = LS_PLAY; }
void finishRecord() {
    int len = recW_;
    if (len < 256) { loopState_ = LS_EMPTY; loopLen_ = 0; loopLenPub_.store(0); return; }
    if (c_.quant) {
        const float beat = c_.beatS;
        const int n = std::max(1, static_cast<int>(std::lround(len / beat)));
        const int L = std::min(static_cast<int>(n * beat), loopMax_);
        for (int i = len; i < L; ++i) { phr_[0][i] = 0.0f; phr_[1][i] = 0.0f; }
        len = std::max(256, L);
    }
    const int f = std::min(len / 4, static_cast<int>(0.005f * sr_));
    for (int i = 0; i < f; ++i) {
        const float g = static_cast<float>(i) / static_cast<float>(f);
        for (int ch = 0; ch < 2; ++ch) { phr_[ch][i] *= g; phr_[ch][len - 1 - i] *= g; }
    }
    loopLen_ = len; loopLenPub_.store(len);
    loopPos_ = 0.0; loopFadeG_ = 1.0f; loopStopping_ = false;
    loopState_ = (c_.order && !c_.burst) ? LS_DUB : LS_PLAY;
}
void applyLoopCommand(int cmd) {
    if (cmd == LOOP_MAIN && c_.burst) { startRec(); return; }
    switch (cmd) {
        case LOOP_MAIN:
            switch (loopState_) {
                case LS_EMPTY: startRec(); break;
                case LS_REC: finishRecord(); break;
                case LS_PLAY: loopState_ = LS_DUB; break;
                case LS_DUB: loopState_ = LS_PLAY; break;
                default: startPlay(); break;
            }
            break;
        case LOOP_RECORD: if (loopState_ == LS_REC) finishRecord(); else startRec(); break;
        case LOOP_PLAY:
            if (loopState_ == LS_REC) finishRecord();
            else if (loopLen_ > 0) { if (loopState_ == LS_STOPPED) startPlay(); else if (loopState_ == LS_DUB) loopState_ = LS_PLAY; }
            break;
        case LOOP_DUB:
            if (c_.burst) break;
            if (loopState_ == LS_PLAY) loopState_ = LS_DUB;
            else if (loopState_ == LS_DUB) loopState_ = LS_PLAY;
            else if (loopState_ == LS_STOPPED && loopLen_ > 0) { startPlay(); loopState_ = LS_DUB; }
            break;
        case LOOP_STOP:
            if (loopState_ == LS_REC) { finishRecord(); }
            if (loopState_ == LS_PLAY || loopState_ == LS_DUB) loopStopping_ = true;
            break;
        case LOOP_ERASE:
            loopState_ = LS_EMPTY; loopLen_ = 0; loopLenPub_.store(0); loopStopping_ = false; beginLayerClear(); break;
        case LOOP_UNDO:
            if (loopLen_ > 0) beginLayerClear();
            if (loopState_ == LS_DUB) loopState_ = LS_PLAY;
            break;
        case LOOP_REC_RELEASE:
            if (loopState_ == LS_REC && c_.burst) finishRecord();
            break;
        default: break;
    }
}
void loopRead(float& oL, float& oR) {
    oL = oR = 0.0f;
    if (loopState_ != LS_PLAY && loopState_ != LS_DUB) return;
    const float step = 1.0f / (std::max(0.002f, c_.loopFadeSec) * sr_);
    const float target = loopStopping_ ? 0.0f : 1.0f;
    loopFadeG_ += std::clamp(target - loopFadeG_, -step, step);
    if (loopStopping_ && loopFadeG_ <= 0.0f) { loopState_ = LS_STOPPED; loopStopping_ = false; loopPos_ = 0.0; loopFadeG_ = 0.0f; return; }
    const int i0 = static_cast<int>(loopPos_);
    const float t = static_cast<float>(loopPos_ - i0);
    const int i1 = i0 + 1 >= loopLen_ ? 0 : i0 + 1;
    float a = phr_[0][i0] * (1.0f - t) + phr_[0][i1] * t;
    float b = phr_[1][i0] * (1.0f - t) + phr_[1][i1] * t;
    if (!layerMute_) {
        a += lay_[0][i0] * (1.0f - t) + lay_[0][i1] * t;
        b += lay_[1][i0] * (1.0f - t) + lay_[1][i1] * t;
    }
    const float g = loopFadeG_ * c_.loopLevel;
    oL = ob::fxdsp::softClip(a) * g; oR = ob::fxdsp::softClip(b) * g;
}
void loopWrite(float sL, float sR) {
    if (loopState_ == LS_REC) {
        if (recW_ < loopMax_) { phr_[0][recW_] = sL; phr_[1][recW_] = sR; ++recW_; }
        if (recW_ >= loopMax_) finishRecord();
    } else if (loopState_ == LS_DUB && !layerClearing_ && !c_.burst && loopLen_ > 0) {
        int i = static_cast<int>(loopPos_ + 0.5); if (i >= loopLen_) i = 0;
        lay_[0][i] += sL; lay_[1][i] += sR;
    }
}
void loopAdvance() {
    if (loopState_ == LS_PLAY || loopState_ == LS_DUB) {
        loopPos_ += static_cast<double>(c_.loopSpeed) * (c_.loopRev ? -1.0 : 1.0);
        while (loopPos_ >= loopLen_) loopPos_ -= loopLen_;
        while (loopPos_ < 0.0) loopPos_ += loopLen_;
    }
    if (layerClearing_) {  // incremental wipe of the overdub layer (no audio-thread hiccup)
        const int total = loopMax_ + 4;
        const int n = std::min(4096, total - layerClearPos_);
        std::fill(lay_[0].begin() + layerClearPos_, lay_[0].begin() + layerClearPos_ + n, 0.0f);
        std::fill(lay_[1].begin() + layerClearPos_, lay_[1].begin() + layerClearPos_ + n, 0.0f);
        layerClearPos_ += n;
        if (layerClearPos_ >= total) { layerClearing_ = false; layerMute_ = false; }
    }
}

// Per effect/variation output trim (dB), measured with the host test harness so that every algorithm
// sits at a comparable loudness. Rows: MOSAIC SEQ GLIDE HAZE TUNNEL STRUM BLOCKS INTERRUPT ARP PATTERN WARP.
static constexpr float kCalDb[11][4] = {
    {3.6f, 3.9f, 3.6f, 2.1f},
    {9.1f, 9.7f, 3.0f, 11.2f},
    {7.3f, 7.3f, 7.4f, 5.7f},
    {1.7f, 7.8f, 4.9f, 3.8f},
    {6.5f, 7.2f, 13.3f, 7.5f},
    {6.2f, 4.6f, 9.8f, 10.6f},
    {0.0f, 0.0f, 0.0f, 0.0f},
    {0.0f, 0.0f, 0.0f, 0.0f},
    {6.0f, 6.1f, 6.0f, 6.0f},
    {-3.9f, -4.8f, -3.5f, -3.5f},
    {-4.0f, 6.3f, -3.4f, -1.7f}};
float calGain_ = 1.0f;
int prevEffect_ = -1, prevVar_ = -1;
float glidePh_ = 0.0f, tunPh_ = 0.0f;
