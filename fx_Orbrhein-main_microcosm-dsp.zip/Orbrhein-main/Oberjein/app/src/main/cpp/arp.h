#pragma once
/*
 * Native 64-step arpeggiator. Runs on the audio thread with a sample clock, so timing is exact and
 * independent of the UI (the previous Kotlin version used Handler.postDelayed on the main thread:
 * every recomposition delayed the notes and the delays accumulated).
 *
 * Threading: configuration is staged from any thread (tiny spin lock, try-lock on the audio side so the
 * audio thread never blocks); everything else (keys, held/latched sets, scheduling) lives on the audio thread.
 */
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

namespace ob {

constexpr int kArpSteps = 64;
constexpr int kArpRoutes = 16;
constexpr int kArpEvents = 512;
constexpr int kArpMaxParams = 128;
constexpr int kArpStepFields = 7;   // enabled, probability, ratchets, octave, velocity, gate, shift
constexpr int kArpRouteFields = 4;  // source, target, amount, bipolar

enum ArpDir { ARP_UP = 0, ARP_DOWN, ARP_UP_DOWN, ARP_DOWN_UP, ARP_AS_PLAYED, ARP_RANDOM };
enum ArpSrc { SRC_STEP = 0, SRC_VELOCITY, SRC_PROBABILITY, SRC_RANDOM, SRC_PITCH };

struct ArpStepData {
    float enabled = 1.0f, probability = 1.0f, ratchets = 1.0f, octave = 0.0f, velocity = 1.0f, gate = 0.8f, shift = 0.0f;
};
struct ArpRouteData { int source = 0, target = 0; float amount = 0.0f; bool bipolar = false; };

struct ArpConfigData {
    bool enabled = false, hold = false, randomMode = false, evolve = false;
    float bpm = 120.0f, humanize = 0.0f;
    int division = 4, direction = ARP_UP, octaveRange = 1, scale = 0, root = 0, chordSize = 1;
    int strumMs = 0, intervalShift = 0, loopLength = 16, nRoutes = 0;
    ArpStepData steps[kArpSteps];
    ArpRouteData routes[kArpRoutes];
};

// Receives what the arpeggiator plays (implemented by the synth).
struct ArpSink {
    virtual void arpNoteOn(int note, float velocity) = 0;
    virtual void arpNoteOff(int note) = 0;
    virtual void arpMod(int paramId, float offset) = 0;
    virtual void arpModeChanged(bool enabled) = 0;
    virtual ~ArpSink() = default;
};

inline const int* arpScaleIntervals(int scale, int& n) {
    static const int chromatic[12] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    static const int major[7] = {0, 2, 4, 5, 7, 9, 11};
    static const int minor[7] = {0, 2, 3, 5, 7, 8, 10};
    static const int dorian[7] = {0, 2, 3, 5, 7, 9, 10};
    static const int penta[5] = {0, 2, 4, 7, 9};
    static const int blues[6] = {0, 3, 5, 6, 7, 10};
    static const int harmonic[7] = {0, 2, 3, 5, 7, 8, 11};
    switch (scale) {
        case 1: n = 7; return major;
        case 2: n = 7; return minor;
        case 3: n = 7; return dorian;
        case 4: n = 5; return penta;
        case 5: n = 6; return blues;
        case 6: n = 7; return harmonic;
        default: n = 12; return chromatic;
    }
}

class Arp {
public:
    void setSink(ArpSink* s) { sink_ = s; }
    void setSampleRate(float sr) { sr_ = sr; }

    // ---------------------------------------------------------------- any thread
    void stage(const ArpConfigData& c) {
        while (lock_.test_and_set(std::memory_order_acquire)) {}
        staging_ = c;
        stagedVersion_.fetch_add(1, std::memory_order_release);
        lock_.clear(std::memory_order_release);
    }
    void requestPanic() { panicReq_.store(true, std::memory_order_release); }
    int currentStep() const { return curStep_.load(std::memory_order_relaxed); }
    bool isRunning() const { return running_pub_.load(std::memory_order_relaxed); }
    int mutationCount() const { return mutation_.load(std::memory_order_relaxed); }
    void readSteps(float* out) const {
        for (int i = 0; i < kArpSteps * kArpStepFields; ++i) out[i] = pubSteps_[i].load(std::memory_order_relaxed);
    }

    // ---------------------------------------------------------------- audio thread
    void applyStaged() {
        if (panicReq_.exchange(false, std::memory_order_acq_rel)) panic();
        const uint32_t v = stagedVersion_.load(std::memory_order_acquire);
        if (v == appliedVersion_) return;
        if (lock_.test_and_set(std::memory_order_acquire)) return;  // producer busy: try next block
        applyConfig(staging_);
        appliedVersion_ = v;
        lock_.clear(std::memory_order_release);
    }

    bool enabled() const { return cfg_.enabled; }

    void keyOn(int note) {
        const bool wasEmpty = pool().n == 0;
        if (cfg_.hold) {
            // latch is edge-triggered: a fresh key-down toggles exactly this pitch
            if (!latched_.remove(note)) latched_.add(note);
        } else {
            held_.add(note);
        }
        // first key after silence: start the pattern right away instead of waiting for the next grid tick
        if (running_ && wasEmpty && pool().n > 0) { stepIndex_ = 0; noteIndex_ = 0; nextStepAt_ = static_cast<double>(clock_); refreshDue(); }
    }
    void keyOff(int note) { held_.remove(note); }

    inline void tick() {
        ++clock_;
        if (clock_ >= nextDue_) service();
    }

    void panic() {
        held_.clear(); latched_.clear();
        allNotesOff();
    }

private:
    struct NoteSet {
        int n = 0; uint8_t v[32];
        bool contains(int x) const { for (int i = 0; i < n; ++i) if (v[i] == x) return true; return false; }
        void add(int x) { if (!contains(x) && n < 32) v[n++] = static_cast<uint8_t>(x); }
        bool remove(int x) {
            for (int i = 0; i < n; ++i) if (v[i] == x) { for (int j = i; j + 1 < n; ++j) v[j] = v[j + 1]; --n; return true; }
            return false;
        }
        void clear() { n = 0; }
    };
    struct Ev { int64_t due = 0; int note = 0; float vel = 0.0f; int token = 0; int64_t dur = 0; bool on = false; bool used = false; };

    const NoteSet& pool() const { return cfg_.hold ? latched_ : held_; }
    float rnd() { rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5; return (rng_ & 0xFFFFFF) * (1.0f / 16777216.0f); }
    double stepSamples() const {
        const double bpm = std::clamp<double>(cfg_.bpm, 30.0, 300.0);
        return sr_ * 60.0 / bpm * 4.0 / std::clamp(cfg_.division, 1, 32);
    }
    int64_t msToSamples(double ms) const { return static_cast<int64_t>(ms * 0.001 * sr_); }

    void applyConfig(const ArpConfigData& n) {
        const bool wasEnabled = cfg_.enabled, wasHold = cfg_.hold;
        cfg_ = n;
        cfg_.loopLength = std::clamp(cfg_.loopLength, 1, kArpSteps);
        cfg_.nRoutes = std::clamp(cfg_.nRoutes, 0, kArpRoutes);
        if (cfg_.hold != wasHold) {
            if (cfg_.hold) { for (int i = 0; i < held_.n; ++i) latched_.add(held_.v[i]); }  // keep what is already held
            else latched_.clear();                                                           // leaving latch releases it
        }
        if (cfg_.enabled != wasEnabled && sink_) sink_->arpModeChanged(cfg_.enabled);
        if (!cfg_.enabled && running_) stop();
        else if (cfg_.enabled && !running_) start();
        publishAllSteps();
    }

    void start() {
        running_ = true; running_pub_.store(true, std::memory_order_relaxed);
        stepIndex_ = 0; noteIndex_ = 0;
        nextStepAt_ = static_cast<double>(clock_);
        refreshDue();
    }
    void stop() {
        running_ = false; running_pub_.store(false, std::memory_order_relaxed);
        allNotesOff();
        nextDue_ = INT64_MAX;
    }
    void allNotesOff() {
        for (int n = 0; n < 128; ++n) if (active_[n]) { active_[n] = false; if (sink_) sink_->arpNoteOff(n); }
        for (auto& e : ev_) e.used = false;
        evCount_ = 0;
        for (int i = 0; i < 128; ++i) token_[i] = 0;
        clearMods();
        refreshDue();
    }
    void clearMods() {
        for (int i = 0; i < nMod_; ++i) if (sink_) sink_->arpMod(modIds_[i], 0.0f);
        nMod_ = 0;
    }

    void refreshDue() {
        int64_t d = running_ ? static_cast<int64_t>(std::ceil(nextStepAt_)) : INT64_MAX;
        if (evCount_ > 0) for (const auto& e : ev_) if (e.used && e.due < d) d = e.due;
        nextDue_ = d;
    }

    void schedule(int64_t due, int note, float vel, int64_t dur) {
        if (due <= clock_) { triggerNote(note, vel, dur); return; }
        for (auto& e : ev_) {
            if (!e.used) { e = Ev{due, note, vel, 0, dur, true, true}; ++evCount_; return; }
        }
        triggerNote(note, vel, dur);  // queue full (should not happen): play immediately rather than lose it
    }
    void scheduleOff(int64_t due, int note, int token) {
        for (auto& e : ev_) {
            if (!e.used) { e = Ev{due, note, 0.0f, token, 0, false, true}; ++evCount_; return; }
        }
        if (token_[note] == token) { active_[note] = false; token_[note] = 0; if (sink_) sink_->arpNoteOff(note); }
    }
    void triggerNote(int note, float vel, int64_t dur) {
        note = std::clamp(note, 0, 127);
        const int token = ++token_[note];
        if (sink_) sink_->arpNoteOn(note, std::clamp(vel, 0.0f, 1.0f));
        active_[note] = true;
        scheduleOff(clock_ + std::max<int64_t>(dur, msToSamples(12.0)), note, token);
    }

    void service() {
        if (evCount_ > 0) {
            for (auto& e : ev_) {
                if (!e.used || e.due > clock_) continue;
                const Ev x = e;
                e.used = false; --evCount_;
                if (x.on) triggerNote(x.note, x.vel, x.dur);
                else if (token_[x.note] == x.token) {   // stale offs (pitch already retriggered) are ignored
                    active_[x.note] = false; token_[x.note] = 0;
                    if (sink_) sink_->arpNoteOff(x.note);
                }
            }
        }
        if (running_ && static_cast<double>(clock_) >= nextStepAt_) {
            const double stepLen = stepSamples();
            playStep(stepLen);
            nextStepAt_ += stepLen;
            if (nextStepAt_ < static_cast<double>(clock_)) nextStepAt_ = static_cast<double>(clock_);
        }
        refreshDue();
    }

    static int floorMod(int a, int b) { const int m = a % b; return m < 0 ? m + b : m; }
    static int floorDiv(int a, int b) { return (a - floorMod(a, b)) / b; }

    void playStep(double stepLen) {
        clearMods();
        // pool: sorted pitches (as-played keeps insertion order), expanded over the octave range
        int raw[32]; int nRaw = 0;
        { const NoteSet& p = pool(); for (int i = 0; i < p.n; ++i) raw[nRaw++] = p.v[i]; }
        if (cfg_.direction != ARP_AS_PLAYED) std::sort(raw, raw + nRaw);
        int notes[128]; int nNotes = 0;
        const int octaves = std::clamp(cfg_.octaveRange, 1, 4);
        for (int o = 0; o < octaves; ++o) for (int i = 0; i < nRaw && nNotes < 128; ++i) notes[nNotes++] = raw[i] + o * 12;

        if (nNotes > 0) {
            const ArpStepData& step = cfg_.steps[std::clamp(stepIndex_, 0, kArpSteps - 1)];
            if (step.enabled > 0.5f && rnd() <= std::clamp(step.probability, 0.0f, 1.0f)) {
                applyRoutes(step, notes, nNotes);
                const int idx = noteIndex_;
                int selected;
                switch (cfg_.direction) {
                    case ARP_DOWN: selected = notes[nNotes - 1 - floorMod(idx, nNotes)]; break;
                    case ARP_RANDOM: selected = notes[std::min(nNotes - 1, static_cast<int>(rnd() * nNotes))]; break;
                    case ARP_UP_DOWN: {   // 1 2 3 4 3 2 | 1 ...
                        const int L = nNotes < 2 ? nNotes : 2 * nNotes - 2;
                        const int i = floorMod(idx, L);
                        selected = i < nNotes ? notes[i] : notes[nNotes - 2 - (i - nNotes)];
                        break;
                    }
                    case ARP_DOWN_UP: {   // 4 3 2 1 2 3 | 4 ...  (the old code only reversed UP_DOWN, which is not down-then-up)
                        const int L = nNotes < 2 ? nNotes : 2 * nNotes - 2;
                        const int i = floorMod(idx, L);
                        selected = i < nNotes ? notes[nNotes - 1 - i] : notes[1 + (i - nNotes)];
                        break;
                    }
                    default: selected = notes[floorMod(idx, nNotes)]; break;  // UP and AS_PLAYED
                }
                triggerStepNotes(step, selected, stepLen);
                ++noteIndex_;
            }
        }
        curStep_.store(stepIndex_, std::memory_order_relaxed);
        stepIndex_ = (stepIndex_ + 1) % cfg_.loopLength;
        if (cfg_.randomMode || cfg_.evolve) evolvePattern();
    }

    void applyRoutes(const ArpStepData& step, const int* notes, int nNotes) {
        for (int r = 0; r < cfg_.nRoutes; ++r) {
            const ArpRouteData& rt = cfg_.routes[r];
            if (rt.target < 0 || rt.target >= kArpMaxParams) continue;
            float src;
            switch (rt.source) {
                case SRC_VELOCITY: src = step.velocity; break;
                case SRC_PROBABILITY: src = step.probability; break;
                case SRC_RANDOM: src = rnd(); break;
                case SRC_PITCH: src = static_cast<float>(notes[floorMod(noteIndex_, nNotes)] % 12) / 11.0f; break;
                default: src = static_cast<float>(stepIndex_) / static_cast<float>(std::max(1, cfg_.loopLength - 1)); break;
            }
            if (sink_) sink_->arpMod(rt.target, (rt.bipolar ? src * 2.0f - 1.0f : src) * rt.amount);
            if (nMod_ < kArpRoutes) modIds_[nMod_++] = rt.target;
        }
    }

    void triggerStepNotes(const ArpStepData& step, int selected, double stepLen) {
        int nIntervals = 0;
        const int* intv = arpScaleIntervals(cfg_.scale, nIntervals);
        const int rootBase = selected - floorMod(selected, 12) + cfg_.root;
        const int target = selected + cfg_.intervalShift + static_cast<int>(step.shift);
        const int rel = target - rootBase;
        const int oct = floorDiv(rel, 12), pc = floorMod(rel, 12);
        int bestDeg = 0, bestDist = 1000;
        for (int d = 0; d < nIntervals; ++d) { const int dist = std::abs(intv[d] - pc); if (dist < bestDist) { bestDist = dist; bestDeg = d; } }
        const int pitch = rootBase + oct * 12 + intv[bestDeg];

        // chord: stacked thirds inside the scale (chromatic uses a fixed major-7th style stack)
        static const int chromaticStack[8] = {0, 4, 7, 11, 14, 17, 21, 24};
        const int chordSize = std::clamp(cfg_.chordSize, 1, 8);
        int chord[8];
        for (int k = 0; k < chordSize; ++k) {
            if (cfg_.scale == 0) chord[k] = pitch + chromaticStack[k];
            else { const int d = bestDeg + 2 * k; chord[k] = rootBase + oct * 12 + intv[d % nIntervals] + 12 * (d / nIntervals); }
        }

        const int ratchets = std::clamp(static_cast<int>(step.ratchets), 1, 8);
        const double stepMs = stepLen / sr_ * 1000.0;
        const int64_t dur = std::max<int64_t>(msToSamples(12.0), static_cast<int64_t>(msToSamples(stepMs / ratchets) * std::clamp(step.gate, 0.0f, 1.0f)));
        // humanize delays the notes (never advances them), the grid itself stays exact
        const int64_t human = cfg_.humanize > 0.0f ? static_cast<int64_t>(rnd() * std::clamp(cfg_.humanize, 0.0f, 1.0f) * 0.18 * stepLen) : 0;
        const int64_t strumStep = msToSamples(stepMs / chordSize);
        for (int k = 0; k < chordSize; ++k) {
            const int note = std::clamp(chord[k] + static_cast<int>(step.octave) * 12, 0, 127);
            const int64_t delay = static_cast<int64_t>(k) * std::min<int64_t>(msToSamples(cfg_.strumMs), strumStep) + human;
            schedule(clock_ + delay, note, step.velocity, dur);
        }
        for (int r = 1; r < ratchets; ++r) {
            const int64_t d = static_cast<int64_t>(r) * std::max<int64_t>(msToSamples(12.0), msToSamples(stepMs / ratchets));
            schedule(clock_ + d + human, std::clamp(pitch, 0, 127), step.velocity, dur);
        }
    }

    void evolvePattern() {
        ArpStepData& s = cfg_.steps[std::clamp(stepIndex_, 0, kArpSteps - 1)];
        const float amount = cfg_.evolve ? 0.18f : 0.45f;
        if (rnd() < amount) {
            s.probability = std::clamp(s.probability + rnd() * 0.35f - 0.12f, 0.0f, 1.0f);
            if (rnd() < 0.25f) s.ratchets = static_cast<float>(1 + static_cast<int>(rnd() * 4.0f));
            if (rnd() < 0.2f) s.octave = static_cast<float>(static_cast<int>(rnd() * 3.0f) - 1);
            publishStep(std::clamp(stepIndex_, 0, kArpSteps - 1));
            mutation_.fetch_add(1, std::memory_order_relaxed);
        }
    }

    void publishStep(int i) {
        const ArpStepData& s = cfg_.steps[i];
        const float f[kArpStepFields] = {s.enabled, s.probability, s.ratchets, s.octave, s.velocity, s.gate, s.shift};
        for (int k = 0; k < kArpStepFields; ++k) pubSteps_[i * kArpStepFields + k].store(f[k], std::memory_order_relaxed);
    }
    void publishAllSteps() { for (int i = 0; i < kArpSteps; ++i) publishStep(i); }

    ArpSink* sink_ = nullptr;
    float sr_ = 48000.0f;
    ArpConfigData cfg_, staging_;
    std::atomic_flag lock_ = ATOMIC_FLAG_INIT;
    std::atomic<uint32_t> stagedVersion_{0};
    uint32_t appliedVersion_ = 0;
    std::atomic<bool> panicReq_{false};

    NoteSet held_, latched_;
    bool running_ = false;
    int stepIndex_ = 0, noteIndex_ = 0;
    int64_t clock_ = 0, nextDue_ = INT64_MAX;
    double nextStepAt_ = 0.0;
    Ev ev_[kArpEvents];
    int evCount_ = 0;
    bool active_[128] = {};
    int token_[128] = {};
    int modIds_[kArpRoutes] = {};
    int nMod_ = 0;
    uint32_t rng_ = 0xC0FFEE11u;

    std::atomic<int> curStep_{0}, mutation_{0};
    std::atomic<bool> running_pub_{false};
    std::atomic<float> pubSteps_[kArpSteps * kArpStepFields];
};

}  // namespace ob
