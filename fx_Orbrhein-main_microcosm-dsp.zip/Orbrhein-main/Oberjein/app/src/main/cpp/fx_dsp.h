#pragma once
// DSP building blocks for the Microcosm-style FX engine (fx_engine.h).
// Everything here is allocation-free after init() and safe for the audio thread.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace ob {
namespace fxdsp {

constexpr float kPi = 3.14159265358979f;
constexpr float kTwoPi = 6.28318530717959f;

inline float flush(float x) { return std::fabs(x) < 1e-18f ? 0.0f : x; }

// Smooth saturator (Pade tanh approximation). Unity-ish slope at the origin.
inline float softClip(float x) {
    x = std::clamp(x, -3.0f, 3.0f);
    return x * (27.0f + x * x) / (27.0f + 9.0f * x * x);
}

// 4-point, 3rd-order Hermite interpolation (much cleaner than linear for pitch shifting).
inline float hermite(float y0, float y1, float y2, float y3, float t) {
    const float c1 = 0.5f * (y2 - y0);
    const float c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
    return ((c3 * t + c2) * t + c1) * t + y1;
}

inline size_t nextPow2(size_t v) { size_t p = 16; while (p < v) p <<= 1; return p; }

// Circular buffer with power-of-two size, addressed by an absolute (ever-increasing) index.
struct Ring {
    std::vector<float> d;
    size_t mask = 0;
    void init(size_t minSize) { d.assign(nextPow2(minSize), 0.0f); mask = d.size() - 1; }
    void clear() { std::fill(d.begin(), d.end(), 0.0f); }
    size_t size() const { return d.size(); }
    inline float at(int64_t i) const { return d[static_cast<size_t>(i) & mask]; }
    inline void put(int64_t i, float v) { d[static_cast<size_t>(i) & mask] = v; }
    inline float read(double pos) const {
        const int64_t i = static_cast<int64_t>(std::floor(pos));
        const float t = static_cast<float>(pos - static_cast<double>(i));
        return hermite(at(i - 1), at(i), at(i + 1), at(i + 2), t);
    }
};

// Zavalishin TPT state-variable filter (12 dB/oct), stable under fast modulation.
struct SvfCoef {
    float g = 0.1f, k = 1.0f, a1 = 0.0f, a2 = 0.0f, a3 = 0.0f;
    void set(float fc, float q, float sr) {
        fc = std::clamp(fc, 20.0f, 0.45f * sr);
        g = std::tan(kPi * fc / sr);
        k = 1.0f / std::max(0.3f, q);
        a1 = 1.0f / (1.0f + g * (g + k));
        a2 = g * a1;
        a3 = g * a2;
    }
};
struct Svf {
    float ic1 = 0.0f, ic2 = 0.0f;
    inline void run(float x, const SvfCoef& c, float& lp, float& bp) {
        const float v3 = x - ic2;
        const float v1 = c.a1 * ic1 + c.a2 * v3;
        const float v2 = ic2 + c.a2 * ic1 + c.a3 * v3;
        ic1 = flush(2.0f * v1 - ic1);
        ic2 = flush(2.0f * v2 - ic2);
        lp = v2;
        bp = v1 * c.k;  // unity-gain band-pass
    }
    void reset() { ic1 = ic2 = 0.0f; }
};

// ---------------------------------------------------------------------------------------------
// Stereo feedback-delay-network reverb: 8 modulated lines, Hadamard mixing, per-line damping,
// input diffusion and pre-delay. Four voicings follow the Microcosm manual:
//   A Bright Room, B Dark Medium, C Large Hall, D Ambient.
// ---------------------------------------------------------------------------------------------
class FdnReverb {
public:
    static constexpr int N = 8;

    void init(float sr) {
        sr_ = sr;
        for (auto& l : line_) l.init(static_cast<size_t>(0.40f * sr));
        pre_[0].init(static_cast<size_t>(0.09f * sr));
        pre_[1].init(static_cast<size_t>(0.09f * sr));
        static const int apLen[2][4] = {{142, 107, 379, 277}, {167, 113, 349, 251}};
        for (int c = 0; c < 2; ++c)
            for (int a = 0; a < 4; ++a) {
                const size_t n = std::max<size_t>(8, static_cast<size_t>(apLen[c][a] * sr / 44100.0f));
                ap_[c][a].assign(n, 0.0f);
                apPos_[c][a] = 0;
            }
        reset();
        setMode(1, 0.3f, true);
    }

    void reset() {
        for (auto& l : line_) l.clear();
        pre_[0].clear(); pre_[1].clear();
        for (int c = 0; c < 2; ++c) for (auto& a : ap_[c]) std::fill(a.begin(), a.end(), 0.0f);
        lp_.fill(0.0f);
        wr_ = 0;
        for (int i = 0; i < N; ++i) lfo_[i] = 0.37f * i;
        hpL_ = hpR_ = 0.0f;
    }

    // mode: 0..3 (A..D), space: 0..1 (also stretches decay a little)
    void setMode(int mode, float space, bool snap = false) {
        static const float sizeMul[4] = {0.50f, 0.85f, 1.40f, 1.95f};
        static const float rt60[4]    = {0.80f, 1.80f, 3.80f, 8.50f};
        static const float damp[4]    = {0.18f, 0.55f, 0.34f, 0.42f};
        static const float preMs[4]   = {0.0f, 4.0f, 22.0f, 38.0f};
        static const float modMs[4]   = {0.10f, 0.25f, 0.45f, 1.10f};
        static const float apG[4]     = {0.55f, 0.62f, 0.68f, 0.72f};
        mode = std::clamp(mode, 0, 3);
        static const float baseMs[N] = {29.7f, 37.1f, 41.1f, 43.7f, 53.3f, 61.7f, 67.1f, 79.3f};
        const float rt = rt60[mode] * (0.65f + 0.7f * space);
        for (int i = 0; i < N; ++i) {
            lenT_[i] = baseMs[i] * 0.001f * sr_ * sizeMul[mode];
            gain_[i] = std::pow(10.0f, -3.0f * lenT_[i] / (rt * sr_));
            if (snap) len_[i] = lenT_[i];
        }
        dampC_ = damp[mode];
        preT_ = preMs[mode] * 0.001f * sr_;
        modDepth_ = modMs[mode] * 0.001f * sr_;
        apG_ = apG[mode];
        static const float outG[4] = {0.95f, 1.20f, 0.95f, 0.95f};  // keeps modes at comparable loudness
        outG_ = outG[mode];
        if (snap) pre_s_ = preT_;
    }

    inline void process(float inL, float inR, float& outL, float& outR) {
        // slew line lengths so a mode change glides instead of clicking
        for (int i = 0; i < N; ++i) len_[i] += (lenT_[i] - len_[i]) * 0.0004f;
        pre_s_ += (preT_ - pre_s_) * 0.0008f;

        pre_[0].put(wr_, inL); pre_[1].put(wr_, inR);
        float xl = pre_[0].read(static_cast<double>(wr_) - std::max(1.0f, pre_s_));
        float xr = pre_[1].read(static_cast<double>(wr_) - std::max(1.0f, pre_s_));
        for (int a = 0; a < 4; ++a) { xl = allpass(0, a, xl); xr = allpass(1, a, xr); }

        float y[N], z[N];
        for (int i = 0; i < N; ++i) {
            lfo_[i] += (0.07f + 0.031f * i) * kTwoPi / sr_;
            if (lfo_[i] > kTwoPi) lfo_[i] -= kTwoPi;
            const double d = len_[i] + modDepth_ * std::sin(lfo_[i]);
            const double rp = static_cast<double>(wr_) - d;
            const int64_t i0 = static_cast<int64_t>(std::floor(rp));
            const float t = static_cast<float>(rp - static_cast<double>(i0));
            y[i] = line_[i].at(i0) * (1.0f - t) + line_[i].at(i0 + 1) * t;
            lp_[i] = flush(lp_[i] * dampC_ + y[i] * (1.0f - dampC_));
            z[i] = lp_[i] * gain_[i];
        }
        // 8x8 Hadamard (fast Walsh) mixing, orthonormal scaling
        for (int s = 1; s < N; s <<= 1)
            for (int i = 0; i < N; i += 2 * s)
                for (int j = i; j < i + s; ++j) { const float a = z[j], b = z[j + s]; z[j] = a + b; z[j + s] = a - b; }
        const float norm = 0.35355339f;
        for (int i = 0; i < N; ++i) {
            const float inj = (i < 4 ? xl : xr) * ((i & 1) ? -0.5f : 0.5f);
            line_[i].put(wr_, flush(z[i] * norm + inj));
        }
        ++wr_;
        float oL = (lp_[0] - lp_[2] + lp_[4] - lp_[6]) * outG_;
        float oR = (lp_[1] - lp_[3] + lp_[5] - lp_[7]) * outG_;
        // DC blocker
        hpL_ += 0.0005f * (oL - hpL_); oL -= hpL_;
        hpR_ += 0.0005f * (oR - hpR_); oR -= hpR_;
        outL = oL; outR = oR;
    }

private:
    inline float allpass(int c, int a, float x) {
        auto& buf = ap_[c][a];
        size_t& p = apPos_[c][a];
        const float d = buf[p];
        const float v = x - apG_ * d;
        buf[p] = flush(v);
        if (++p >= buf.size()) p = 0;
        return d + apG_ * v;
    }
    float sr_ = 48000.0f;
    std::array<Ring, N> line_;
    Ring pre_[2];
    std::vector<float> ap_[2][4];
    size_t apPos_[2][4]{};
    std::array<float, N> lp_{}, len_{}, lenT_{}, gain_{}, lfo_{};
    float outG_ = 0.95f, dampC_ = 0.3f, preT_ = 0.0f, pre_s_ = 0.0f, modDepth_ = 0.0f, apG_ = 0.6f;
    int64_t wr_ = 0;
    float hpL_ = 0.0f, hpR_ = 0.0f;
};

// ---------------------------------------------------------------------------------------------
// Pitch modulation: stereo modulated delay (quadrature LFOs). Low depth = chorus, high = wobble.
// ---------------------------------------------------------------------------------------------
class PitchMod {
public:
    void init(float sr) { sr_ = sr; l_.init(static_cast<size_t>(0.06f * sr)); r_.init(static_cast<size_t>(0.06f * sr)); reset(); }
    void reset() { l_.clear(); r_.clear(); w_ = 0; phase_ = 0.0f; depthS_ = 0.0f; }
    inline void process(float& l, float& r, float depth, float rateHz) {
        depthS_ += (depth - depthS_) * 0.001f;
        l_.put(w_, l); r_.put(w_, r);
        const float amt = std::min(1.0f, depthS_ * 25.0f);  // fades the effect in instead of switching
        if (amt > 1e-4f) {
            phase_ += rateHz / sr_;
            if (phase_ >= 1.0f) phase_ -= 1.0f;
            const float dMs = depthS_ * 0.009f * sr_;
            const float base = 0.012f * sr_;
            const float dl = base + dMs * std::sin(kTwoPi * phase_);
            const float dr = base + dMs * std::sin(kTwoPi * (phase_ + 0.25f));
            const float ml = l_.read(static_cast<double>(w_) - dl);
            const float mr = r_.read(static_cast<double>(w_) - dr);
            // keep the dry path time-aligned with the modulated one
            const float al = l_.at(w_ - static_cast<int64_t>(base));
            const float ar = r_.at(w_ - static_cast<int64_t>(base));
            l = al * (1.0f - amt) + ml * amt;
            r = ar * (1.0f - amt) + mr * amt;
        }
        ++w_;
    }
private:
    float sr_ = 48000.0f, phase_ = 0.0f, depthS_ = 0.0f;
    Ring l_, r_;
    int64_t w_ = 0;
};

// ---------------------------------------------------------------------------------------------
// Loop / one-shot voice used by the micro-loop, glitch and arpeggio algorithms.
// Owns a private copy of a captured slice so it keeps sounding while the capture ring moves on.
// Looping uses two Hann-windowed read taps half a loop apart (sum of windows == 1), so the loop
// point is click-free at any speed, and loop length can be modulated live.
// ---------------------------------------------------------------------------------------------
struct VoiceParams {
    float speed = 1.0f;
    float gain = 0.6f;
    float pan = 0.0f;        // -1..1
    float decayT = 0.0f;     // seconds to -60 dB (0 = sustain forever)
    float attack = 0.01f;
    float release = 0.08f;
    int fmode = 0;           // 0 off, 1 low-pass, 2 band-pass
    float fcut = 2000.0f, fq = 1.0f;
    float crush = 0.0f;
    float fade = 0.004f;     // one-shot edge fades
    float slew = 0.002f;     // speed slew per sample (glides)
    int tag = 0;
};

struct Voice {
    std::vector<float> bl, br;
    bool active = false, loop = true;
    int len = 0;
    float loopLen = 0.0f;       // live (modulatable) loop length for loop mode
    float ph = 0.0f;            // loop: normalised phase
    double pos = 0.0;           // one-shot: position
    float speed = 1.0f, speedTarget = 1.0f, slew = 0.002f;
    float level = 1.0f, decayMul = 1.0f, amp = 0.0f, ampTarget = 1.0f, atkC = 0.01f, relC = 0.002f, gain = 1.0f;
    float pl = 1.0f, pr = 1.0f;
    int fmode = 0; SvfCoef fc; Svf sl, sr;
    float crush = 0.0f; int crushCnt = 0; float hl = 0.0f, hr = 0.0f;
    float fadeS = 128.0f;
    uint32_t birth = 0; int tag = 0;
    int aux = 0; float auxLen = 0.0f;   // per-effect scratch (voice index in a set, nominal loop length)
};

}  // namespace fxdsp
}  // namespace ob
