#include <jni.h>
#include <oboe/Oboe.h>

#include <atomic>
#include <memory>
#include <mutex>

#include "synth.h"

// Owns the Oboe output stream and the synth. Param/note calls are lock-free;
// the mutex only guards stream start/stop.
class Engine : public oboe::AudioStreamDataCallback,
               public oboe::AudioStreamErrorCallback,
               public std::enable_shared_from_this<Engine> {
public:
    ob::Synth synth;

    bool start() {
        std::lock_guard<std::mutex> lock(mutex_);
        wantRunning_ = true;
        if (stream_) return true;
        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Exclusive)
            ->setFormat(oboe::AudioFormat::Float)
            ->setFormatConversionAllowed(true)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setChannelConversionAllowed(true)
            ->setUsage(oboe::Usage::Game)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());
        if (builder.openStream(stream_) != oboe::Result::OK) {
            stream_.reset();
            return false;
        }
        synth.setSampleRate(static_cast<float>(stream_->getSampleRate()));
        stream_->setBufferSizeInFrames(stream_->getFramesPerBurst() * 2);
        tuner_ = std::make_unique<oboe::LatencyTuner>(*stream_);
        if (stream_->requestStart() != oboe::Result::OK) {
            stream_->close();
            stream_.reset();
            return false;
        }
        return true;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mutex_);
        wantRunning_ = false;
        if (stream_) {
            stream_->stop();
            tuner_.reset();
            stream_->close();
            stream_.reset();
        }
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData,
                                          int32_t numFrames) override {
        synth.render(static_cast<float*>(audioData), numFrames);
        if (tuner_) tuner_->tune();  // grows the buffer by one burst whenever an underrun is detected
        return oboe::DataCallbackResult::Continue;
    }

    // Headphones unplugged, route changed, etc.: reopen on the new device.
    void onErrorAfterClose(oboe::AudioStream*, oboe::Result error) override {
        if (error != oboe::Result::ErrorDisconnected) return;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            tuner_.reset();
            stream_.reset();
        }
        if (wantRunning_) start();
    }

private:
    std::mutex mutex_;
    std::shared_ptr<oboe::AudioStream> stream_;
    std::unique_ptr<oboe::LatencyTuner> tuner_;
    std::atomic<bool> wantRunning_{false};
};

static std::shared_ptr<Engine>& engine() {
    static std::shared_ptr<Engine> e = std::make_shared<Engine>();
    return e;
}

extern "C" {

// ---- keys (routed through the native arpeggiator when it is on), arpeggiator config and status ----
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeKeyOn(JNIEnv*, jobject, jint note, jfloat vel, jboolean echo) {
    engine()->synth.keyOn(note, vel, echo == JNI_TRUE);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeKeyOff(JNIEnv*, jobject, jint note, jboolean echo) {
    engine()->synth.keyOff(note, echo == JNI_TRUE);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativePanic(JNIEnv*, jobject) {
    engine()->synth.panic();
}
// ints:   enabled, hold, randomMode, evolve, division, direction, octaveRange, scale, root, chordSize,
//         strumMs, intervalShift, loopLength, nRoutes
// floats: bpm, humanize
// steps:  64 x (enabled, probability, ratchets, octave, velocity, gate, shift)
// routes: n x (source, target, amount, bipolar)
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeArpConfig(JNIEnv* env, jobject, jintArray ints, jfloatArray floats,
                                                                          jfloatArray steps, jfloatArray routes) {
    if (!ints || !floats || !steps || !routes) return;
    if (env->GetArrayLength(ints) < 14 || env->GetArrayLength(floats) < 2 ||
        env->GetArrayLength(steps) < ob::kArpSteps * ob::kArpStepFields) return;
    jint i[14]; jfloat f[2];
    env->GetIntArrayRegion(ints, 0, 14, i);
    env->GetFloatArrayRegion(floats, 0, 2, f);
    ob::ArpConfigData c;
    c.enabled = i[0] != 0; c.hold = i[1] != 0; c.randomMode = i[2] != 0; c.evolve = i[3] != 0;
    c.division = i[4]; c.direction = i[5]; c.octaveRange = i[6]; c.scale = i[7]; c.root = i[8]; c.chordSize = i[9];
    c.strumMs = i[10]; c.intervalShift = i[11]; c.loopLength = i[12];
    c.bpm = f[0]; c.humanize = f[1];
    float sd[ob::kArpSteps * ob::kArpStepFields];
    env->GetFloatArrayRegion(steps, 0, ob::kArpSteps * ob::kArpStepFields, sd);
    for (int k = 0; k < ob::kArpSteps; ++k) {
        const float* p = sd + k * ob::kArpStepFields;
        c.steps[k] = {p[0], p[1], p[2], p[3], p[4], p[5], p[6]};
    }
    const int nr = std::min<int>(std::min<int>(i[13], ob::kArpRoutes), env->GetArrayLength(routes) / ob::kArpRouteFields);
    float rd[ob::kArpRoutes * ob::kArpRouteFields];
    if (nr > 0) env->GetFloatArrayRegion(routes, 0, nr * ob::kArpRouteFields, rd);
    c.nRoutes = std::max(0, nr);
    for (int k = 0; k < c.nRoutes; ++k) {
        const float* p = rd + k * ob::kArpRouteFields;
        c.routes[k] = {static_cast<int>(p[0]), static_cast<int>(p[1]), p[2], p[3] > 0.5f};
    }
    engine()->synth.arpConfig(c);
}
// out[0]=running, out[1]=step being played, out[2]=number of pattern mutations so far
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeArpStatus(JNIEnv* env, jobject, jfloatArray out) {
    if (!out || env->GetArrayLength(out) < 3) return;
    const ob::Arp& a = engine()->synth.arp();
    const float t[3] = {a.isRunning() ? 1.0f : 0.0f, static_cast<float>(a.currentStep()), static_cast<float>(a.mutationCount())};
    env->SetFloatArrayRegion(out, 0, 3, t);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeArpSteps(JNIEnv* env, jobject, jfloatArray out) {
    if (!out || env->GetArrayLength(out) < ob::kArpSteps * ob::kArpStepFields) return;
    float t[ob::kArpSteps * ob::kArpStepFields];
    engine()->synth.arp().readSteps(t);
    env->SetFloatArrayRegion(out, 0, ob::kArpSteps * ob::kArpStepFields, t);
}
// Notes the engine played since the last call, packed as (on << 16) | (note << 8) | velocity. Returns the count.
JNIEXPORT jint JNICALL Java_com_oberjein_synth_SynthEngine_nativeDrainMidiOut(JNIEnv* env, jobject, jintArray out) {
    if (!out) return 0;
    const int cap = std::min<int>(env->GetArrayLength(out), 128);
    int tmp[128];
    const int n = engine()->synth.drainMidiOut(tmp, cap);
    if (n > 0) env->SetIntArrayRegion(out, 0, n, tmp);
    return n;
}

JNIEXPORT jboolean JNICALL Java_com_oberjein_synth_SynthEngine_nativeStart(JNIEnv*, jobject) {
    return engine()->start() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeStop(JNIEnv*, jobject) {
    engine()->stop();
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeSetParam(JNIEnv*, jobject, jint id, jfloat v) {
    engine()->synth.setParam(id, v);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeNoteOn(JNIEnv*, jobject, jint note, jfloat vel) {
    engine()->synth.noteOn(note, vel);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeNoteOff(JNIEnv*, jobject, jint note) {
    engine()->synth.noteOff(note);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeAllNotesOff(JNIEnv*, jobject) {
    engine()->synth.allNotesOff();
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativePitchBend(JNIEnv*, jobject, jfloat v) {
    engine()->synth.pitchBend(v);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeSetFxParam(JNIEnv*, jobject, jint id, jfloat value) {
    engine()->synth.setFxParam(id, value);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeFxTapTempo(JNIEnv*, jobject, jfloat bpm) {
    engine()->synth.fxTapTempo(bpm);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeFxHold(JNIEnv*, jobject, jboolean enabled) {
    engine()->synth.fxHold(enabled == JNI_TRUE);
}
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeFxLooperCommand(JNIEnv*, jobject, jint command) {
    engine()->synth.fxLooperCommand(command);
}
// Fills `out` (length >= 9) with live FX status: loopState, loopPos(0..1), loopSeconds, inPeak, outPeak,
// beatPhase(0..1), holdActive, onsetCount, activeVoices.
JNIEXPORT void JNICALL Java_com_oberjein_synth_SynthEngine_nativeFxReadStatus(JNIEnv* env, jobject, jfloatArray out) {
    if (out == nullptr || env->GetArrayLength(out) < 9) return;
    float tmp[9] = {0};
    engine()->synth.fxReadStatus(tmp, 9);
    env->SetFloatArrayRegion(out, 0, 9, tmp);
}

}  // extern "C"
