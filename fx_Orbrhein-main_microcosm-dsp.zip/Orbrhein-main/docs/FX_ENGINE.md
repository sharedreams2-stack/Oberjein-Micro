# FX engine (Microcosm-style)

Signal path, as in the Hologram Microcosm manual:

```
input -> [looper PRE-FX] -> hold sampler -> EFFECT -> pitch modulation -> reverb (4 modes) -> low-pass filter
      -> mix with dry -> [looper POST-FX] -> output
```

| File | Role |
|---|---|
| `cpp/fx_dsp.h` | Hermite interpolation, TPT state-variable filter, 8-line FDN reverb, modulated-delay pitch mod, loop/one-shot `Voice` |
| `cpp/fx_engine.h` | Public API, parameter cache, per-sample signal chain |
| `cpp/fx_engine_body.inc` | Onsets, voices, grains, the 11 algorithms, multi-delay, hold sampler, phrase looper (included inside the class) |
| `java/.../FxParams.kt` | Parameter ids (mirror of `FxEngine::FxParam`), help texts, 44 factory starting points |
| `java/.../ui/FxScreen.kt` | UI |

## What changed versus the first version
* Every effect used to be one delay line read in different ways. Now sample-based effects capture real slices of the
  last notes (onset detector + exact note-on hint from the synth) into private voice buffers, and loop them with
  two-tap Hann crossfades (click-free at any speed, loop length modulatable live).
* Haze/Strum/Blocks/Interrupt use a Hann-windowed grain engine; Glide/Tunnel modulate loop speed/length;
  Seq/Arp are step sequencers over recent onsets; Pattern/Warp are feedback multitap delays with per-tap
  envelope filters, resonant band-pass, delay-line pitch shifters or double-speed cross-fades.
* Repeats = time (to -40 dB, 0.4 s .. ~25 s, infinite at max), not a raw feedback gain. Shape = envelope contour.
* Reverb (SPACE): 8-line FDN, 4 voicings (Bright Room, Dark Medium, Large Hall, Ambient) with 6-stage input
  diffusion, an allpass inside every feedback line, outputs taken after the mixing matrix, 10 early reflections and a
  diffused-input tap so the onset has no gap. Measure it with `tools/fx_host_tests/revir.cpp` + `irmetrics.py`.
  Filter: resonant 12 dB SVF, bypassed at max.
* Tempo changes are slewed (no zipper); TIME knob = 6 subdivisions (1/4 ... 8x) or BPM in TEMPO mode.
* Looper: separate overdub layer, UNDO, STOP with fade, ERASE, REVERSE, speed 1/4x..4x, QUANTIZE, BURST,
  PRE-FX, LOOPER ONLY, REC>PLAY>DUB / REC>DUB>PLAY. State is owned by the audio thread and polled by the UI.
* Hold sampler freezes ~one beat and feeds it back into the effect (momentary or latch).
* Bypass is transparent; TRAILS lets tails ring out; the engine goes idle (no CPU) once tails are gone.

## Not done / known limits
* Loops are not stored inside user presets (settings are).
* FWD/REV does not reverse Pattern/Warp (feedback delays).
* The hardware MIDI CC map from the manual is not wired (only MIDI-learn on the 7 expression targets).
* Output trims per effect (`kCalDb`) were measured with a synthetic test signal; tune by ear if desired.
