# Audit: stability, performance, arpeggiator

## Why the UI felt "truncated" and the arp lagged
| Cause | Where | Fix |
|---|---|---|
| `Knob` computed `current - drag` from the last *composed* value, so every drag event arriving between two recompositions was thrown away; plus a ~8 dp touch-slop dead zone | `ui/Components.kt` | local accumulator, immediate drag, double-tap = default |
| `values` / `fxValues` were one `mutableStateListOf`: reading any element subscribes to the whole list, so one knob drag recomposed every knob/toggle/cycle button on each touch event | `SynthViewModel.kt` | `ParamStore`: one `mutableFloatStateOf` per parameter |
| `set()` copied every list into an undo snapshot on each event (~100x/s) and flooded the 100-entry undo stack | `SynthViewModel.kt` | edits of the same control within 700 ms = one undo step |
| The arpeggiator was a `Handler.postDelayed` loop on the **main thread**: each step was scheduled relative to when the previous callback actually ran, so any UI work delayed notes and the delay accumulated; ms truncation on top | `Arpeggiator.kt` | sequencer moved to the audio thread (`cpp/arp.h`) with a sample clock |
| External MIDI notes were posted through the main thread | `MidiBridge.kt` | notes/pitch bend go straight to the engine; only CCs touch the UI |
| `render()` consumed note events *before* publishing the current parameters, so the first note after a change used last block's settings (voice count, unison, ...) | `synth.h` | parameters are refreshed before events |

## Audio engine
* Filter coefficients (one division per sample per voice, x2-4) are now computed once per control tick.
* Two `sin()` per voice-sample were evaluated even with BRIGHT = 0; now skipped, and a fast sine is used otherwise.
* FTZ/DAZ enabled on the audio thread (denormals are expensive on ARM).
* Continuous parameters are smoothed (~12 ms) at control rate: no stepping while a knob is dragged.
* Oboe `LatencyTuner`: the buffer grows by one burst whenever an underrun is detected.
* Measured on the host: 31-41% less CPU for the same sound (bit-identical with BRIGHT = 0).

## Arpeggiator
* Native, sample-accurate, 0 samples of drift over 20 s in the tests; the first key starts the pattern immediately.
* Chords are now stacked thirds inside the scale (C major, 3 notes = C E G). The old code added scale *degrees 0,1,2*, giving C D E, and semitone clusters in CHROMATIC.
* DOWN_UP really goes down then up (the old code only reversed UP_DOWN); AS_PLAYED honours the octave range.
* Modulation routes can no longer target structural parameters (UNISON, OVERSAMPLING, VOICE COUNT, UNI VOICES, LEGATO, PERSISTENT VOICING): modulating them every step silenced or clicked the voices. `POLES` was removed from the list (the DSP never reads it).
* Enabling/disabling the arp releases the other mode's voices; changing octave or leaving the keyboard releases held keys (before, the arp kept playing stuck notes).

## Other
* Backups with a different parameter count are accepted (missing values = defaults).
* Audio service: the Oboe stream is opened off the main thread, retried on every start, wake lock expires (4 h, renewed).
* Release build is non-debuggable (signed with the debug key for sideloading): judge smoothness with it, not the debug APK.

## Not verified / known
* Nothing was run on a phone. Kotlin and JNI were reviewed by reading and compiled only through stubs; the C++ is tested on a PC.
* `P_POLES` is kept in the id table only so old backups keep their layout.
