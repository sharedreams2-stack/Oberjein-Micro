#include "fx_dsp.h"
#include <cstdio>
#include <vector>
int main(int argc,char**argv){
  const float SR=48000; const char* tag = argc>1?argv[1]:"old";
  for(int m=0;m<4;m++){
    ob::fxdsp::FdnReverb r; r.init(SR); r.setMode(m,1.0f,true);
    std::vector<float> L,R; const int N=int(6*SR);
    for(int i=0;i<N;i++){ float oL,oR; r.process(i==0?1.f:0.f, i==0?1.f:0.f, oL,oR); L.push_back(oL); R.push_back(oR); }
    char fn[64]; snprintf(fn,64,"ir_%s_%d.raw",tag,m); FILE*f=fopen(fn,"wb"); fwrite(L.data(),4,N,f); fwrite(R.data(),4,N,f); fclose(f);
  }
}
