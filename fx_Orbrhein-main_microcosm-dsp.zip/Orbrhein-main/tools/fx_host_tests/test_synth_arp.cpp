// Real Synth + native arpeggiator, driven exactly like the app (keyOn/keyOff, config staging, audio blocks).
#include "synth.h"
#include <cstdio>
#include <random>
#include <vector>
using namespace ob;
static int fails = 0;
#define CHECK(c, msg, ...) do { if (!(c)) { printf("  FAIL: " msg "\n", ##__VA_ARGS__); ++fails; } else printf("  ok:   " msg "\n", ##__VA_ARGS__); } while (0)
static void voice(Synth& s) {
  s.setParam(P_VCO1_SAW,1); s.setParam(P_VCO1_LEVEL,0.8f); s.setParam(P_VCO2_SAW,1); s.setParam(P_VCO2_LEVEL,0.6f); s.setParam(P_CUTOFF,0.6f);
  s.setParam(P_A_A,0.01f); s.setParam(P_A_D,0.3f); s.setParam(P_A_S,0.6f); s.setParam(P_A_R,0.2f); s.setParam(P_VOLUME,0.7f); s.setParam(P_VOICE_COUNT,0.47f); }
struct Out { std::vector<float> a; long nan = 0; };
static Out render(Synth& s, double sec, std::vector<int>* midi = nullptr) {
  Out o; std::vector<float> b(2*192); int n = (int)(sec*48000/192);
  for (int i = 0; i < n; ++i) { s.render(b.data(), 192); for (float x : b) { if (!std::isfinite(x)) ++o.nan; o.a.push_back(x); }
    if (midi) { int tmp[64]; int k = s.drainMidiOut(tmp, 64); for (int j = 0; j < k; ++j) midi->push_back(tmp[j]); } }
  return o; }
static double rms(const std::vector<float>& v, size_t a, size_t b) { double s = 0; for (size_t i = a; i < b && i < v.size(); ++i) s += v[i]*v[i]; return std::sqrt(s / std::max<size_t>(1, b - a)); }
int main() {
  printf("== arp drives the real synth\n");
  { Synth s; s.setSampleRate(48000); voice(s); ArpConfigData c; c.enabled = true; c.bpm = 120; c.division = 16; s.arpConfig(c); render(s, 0.05);
    s.keyOn(48, 0.8f, true); s.keyOn(52, 0.8f, true); s.keyOn(55, 0.8f, true); std::vector<int> midi; auto o = render(s, 4.0, &midi);
    int ons = 0, offs = 0; for (int e : midi) { if (e & 0x10000) ++ons; else ++offs; }
    printf("  MIDI-out: %d note-ons, %d note-offs in 4 s\n", ons, offs);
    CHECK(ons >= 31 && ons <= 33, "32 sixteenth-notes in 4 s at 120 bpm (%d)", ons); CHECK(o.nan == 0 && rms(o.a, 20000, o.a.size()) > 0.01, "audible, no NaN (rms %.3f)", rms(o.a, 20000, o.a.size()));
    s.keyOff(48,true); s.keyOff(52,true); s.keyOff(55,true); std::vector<int> m2; auto o2 = render(s, 1.5, &m2);
    CHECK(rms(o2.a, o2.a.size() - 9600, o2.a.size()) < 1e-3, "silent after keys are released (rms %.5f)", rms(o2.a, o2.a.size()-9600, o2.a.size())); }

  printf("== modulation route changes the sound (param + arp offset)\n");
  { auto run = [&](bool route) { Synth s; s.setSampleRate(48000); voice(s); s.setParam(P_CUTOFF, 0.2f); ArpConfigData c; c.enabled = true; c.division = 16; c.bpm = 120;
      if (route) { c.nRoutes = 1; c.routes[0] = {SRC_VELOCITY, P_CUTOFF, 0.6f, false}; } s.arpConfig(c); render(s, 0.05); s.keyOn(48, 0.8f, false); auto o = render(s, 2.0); return rms(o.a, 24000, o.a.size()); };
    double a = run(false), b = run(true); CHECK(b > a * 1.3, "VELOCITY -> CUTOFF opens the filter (rms %.4f -> %.4f)", a, b); }

  printf("== mode switching with keys held never leaves a stuck note\n");
  { Synth s; s.setSampleRate(48000); voice(s); ArpConfigData c; c.bpm = 120; c.division = 16; s.arpConfig(c); render(s, 0.05);
    s.keyOn(60, 0.8f, true); s.keyOn(64, 0.8f, true); render(s, 0.5);                 // sounding as normal notes
    c.enabled = true; s.arpConfig(c); render(s, 1.0); s.keyOff(60, true); s.keyOff(64, true); render(s, 1.0);
    c.enabled = false; s.arpConfig(c); auto o = render(s, 2.5); CHECK(rms(o.a, o.a.size() - 9600, o.a.size()) < 1e-3, "silent after on/off round trip (rms %.5f)", rms(o.a, o.a.size()-9600, o.a.size()));
    s.keyOn(60, 0.8f, true); render(s, 0.3); c.enabled = true; s.arpConfig(c); render(s, 0.3); s.keyOff(60, true); c.enabled = false; s.arpConfig(c); auto o2 = render(s, 2.5);
    CHECK(rms(o2.a, o2.a.size() - 9600, o2.a.size()) < 1e-3, "key released while the mode flips: still silent (rms %.5f)", rms(o2.a, o2.a.size()-9600, o2.a.size())); }

  printf("== extreme settings: 8-note chords x 8 ratchets x 1/32 at 300 bpm, all voices, FX on\n");
  { Synth s; s.setSampleRate(48000); voice(s); s.setParam(P_VOICE_COUNT, 1.0f); s.setParam(P_OVERSAMPLING, 1.0f); s.setFxParam(FxEngine::ENABLE,1); s.setFxParam(FxEngine::SPACE,0.5f);
    ArpConfigData c; c.enabled = true; c.bpm = 300; c.division = 32; c.chordSize = 8; c.scale = 1; c.octaveRange = 4; c.humanize = 1; for (auto& st : c.steps) { st.ratchets = 8; st.gate = 1.0f; } s.arpConfig(c); render(s, 0.05);
    for (int n : {36, 40, 43, 47, 50, 55, 60, 64}) s.keyOn(n, 1.0f, true); auto o = render(s, 6.0); float pk = 0; for (float x : o.a) pk = std::max(pk, std::fabs(x));
    CHECK(o.nan == 0 && pk < 4.0f, "stable under overload (NaN %ld, peak %.2f)", o.nan, pk); }

  printf("== random abuse from the UI thread's point of view (config + keys + params), 60 s of audio\n");
  { Synth s; s.setSampleRate(48000); voice(s); std::mt19937 g(3); ArpConfigData c; c.enabled = true; long nan = 0; float pk = 0; std::vector<float> b(2*192);
    for (int i = 0; i < 60*48000/192; ++i) {
      if (g() % 15 == 0) { c.enabled = g() % 6 != 0; c.hold = g() % 4 == 0; c.direction = g() % 6; c.scale = g() % 7; c.octaveRange = 1 + g() % 4; c.chordSize = 1 + g() % 8; c.division = (int[]){1,2,4,8,16,32}[g()%6]; c.bpm = 30 + g() % 271; s.arpConfig(c); }
      if (g() % 6 == 0) s.keyOn(30 + g() % 70, 0.9f, true); if (g() % 6 == 0) s.keyOff(30 + g() % 70, true); if (g() % 400 == 0) s.panic();
      if (g() % 4 == 0) s.setParam(g() % 40, (g() % 1001) / 1000.f);
      s.render(b.data(), 192); for (float x : b) { if (!std::isfinite(x)) ++nan; pk = std::max(pk, std::fabs(x)); } }
    CHECK(nan == 0 && pk < 8.0f, "no NaN under random abuse (peak %.2f)", pk);
    c.enabled = false; s.arpConfig(c); s.panic(); auto o = render(s, 4.0); CHECK(rms(o.a, o.a.size() - 9600, o.a.size()) < 1e-3, "and it ends silent after panic (rms %.5f)", rms(o.a, o.a.size()-9600, o.a.size())); }
  printf("\n%s (%d failures)\n", fails ? "SOME TESTS FAILED" : "ALL SYNTH+ARP TESTS PASSED", fails); return fails ? 1 : 0; }
