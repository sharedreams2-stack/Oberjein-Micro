// Host benchmark of the synth core. Usage: ./synthbench  -> ns per output frame for several configs
#include "synth.h"
#include <chrono>
#include <cstdio>
#include <vector>
using namespace ob;
static double run(int voices, int os, bool lp24, bool bright, bool fx, int notes, int blocks=1500, int frames=192){
  Synth s; s.setSampleRate(48000);
  s.setParam(P_VCO1_SAW,1); s.setParam(P_VCO1_LEVEL,0.8f); s.setParam(P_VCO2_SAW,1); s.setParam(P_VCO2_LEVEL,0.8f);
  s.setParam(P_VCO2_SEMI,0.5f); s.setParam(P_VCO2_DETUNE,0.05f); s.setParam(P_CUTOFF,0.65f); s.setParam(P_RESO,0.3f);
  s.setParam(P_A_A,0.02f); s.setParam(P_A_D,0.5f); s.setParam(P_A_S,0.9f); s.setParam(P_A_R,0.5f); s.setParam(P_VOLUME,0.7f);
  s.setParam(P_VOICE_COUNT,(voices-1)/15.f); s.setParam(P_OVERSAMPLING, os==1?0.f:(os==2?0.5f:1.f));
  s.setParam(P_LP24,lp24?1.f:0.f); s.setParam(P_BRIGHT,bright?0.5f:0.f);
  s.setParam(P_LFO_PITCH,0.1f); s.setParam(P_LFO_RATE,0.4f);
  if(fx){ s.setFxParam(FxEngine::ENABLE,1); s.setFxParam(FxEngine::EFFECT,0.f); s.setFxParam(FxEngine::SPACE,0.4f); s.setFxParam(FxEngine::MIX,0.5f); }
  std::vector<float> buf(2*frames);
  s.render(buf.data(),frames);   // let the first control tick publish the parameters
  for(int n=0;n<notes;n++) s.noteOn(48+n*3,0.8f);
  for(int i=0;i<200;i++) s.render(buf.data(),frames);               // warm up
  auto t0=std::chrono::high_resolution_clock::now();
  for(int i=0;i<blocks;i++) s.render(buf.data(),frames);
  double sec=std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-t0).count();
  double audioSec=double(blocks)*frames/48000.0;
  return sec/audioSec*100.0;   // % of one core (real-time budget)
}
int main(){
  printf("%-46s %s\n","config (all voices sounding)","% of one core (host)");
  struct C{int v,os;bool lp24,br,fx;const char*n;} cs[]={
    {8,1,false,false,false,"8 voices, 1x, 12dB filter"},
    {8,1,true,false,false,"8 voices, 1x, LP24"},
    {16,1,false,false,false,"16 voices, 1x"},
    {16,1,true,true,false,"16 voices, 1x, LP24, BRIGHT"},
    {16,2,true,false,false,"16 voices, 2x, LP24"},
    {16,4,true,false,false,"16 voices, 4x, LP24"},
    {8,1,false,false,true,"8 voices, 1x + FX (Mosaic, reverb)"},
  };
  for(auto&c:cs) printf("%-46s %6.2f%%\n",c.n,run(c.v,c.os,c.lp24,c.br,c.fx,c.v));
}
