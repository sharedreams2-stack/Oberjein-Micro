import numpy as np, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.signal import spectrogram
SR=48000
def load(fx,v):
    a=np.fromfile(f'out_{fx}_{v}.raw',dtype=np.int16).astype(np.float32)/32768
    return a.reshape(-1,2).mean(1)
cases=[('MOSAIC A',0,0),('GLIDE D',2,3),('HAZE B',3,1),('TUNNEL B',4,1),('STRUM C',5,2),('BLOCKS D',6,3),('ARP B',8,1),('PATTERN D',9,3),('WARP C',10,2)]
fig,ax=plt.subplots(3,3,figsize=(15,9))
for a,(n,fx,v) in zip(ax.flat,cases):
    f,t,S=spectrogram(load(fx,v),fs=SR,nperseg=2048,noverlap=1536)
    m=f<4000
    a.pcolormesh(t,f[m],10*np.log10(S[m]+1e-10),vmin=-100,vmax=-30,shading='auto'); a.set_title(n); a.set_xlabel('s'); a.set_ylabel('Hz')
plt.tight_layout(); plt.savefig('spec.png',dpi=70)
