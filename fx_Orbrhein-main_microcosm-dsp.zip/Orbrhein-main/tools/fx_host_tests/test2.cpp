#include "fx_engine.h"
#include <cstdio>
#include <vector>
#include <random>
#include <cmath>
#include <complex>
static float SR=48000.f;
static int fails=0;
#define CHECK(c,msg,...) do{ if(!(c)){ printf("  FAIL: " msg "\n",##__VA_ARGS__); fails++; } else { printf("  ok:   " msg "\n",##__VA_ARGS__);} }while(0)
struct Run { FxEngine e; std::vector<float> L,R; 
  void feed(float secs,float f,float amp,bool silent=false){ int n=int(secs*SR); static double ph=0; for(int i=0;i<n;i++){ float x= silent?0.f:amp*std::sin(6.2831853*f*(float)(i)/SR); float l=x,r=x; e.process(l,r); L.push_back(l); R.push_back(r);} (void)ph; }
};
static double goertzel(const std::vector<float>&x,int a,int b,double f){ double w=2*M_PI*f/SR,c=2*std::cos(w),s1=0,s2=0; for(int i=a;i<b;i++){ double s=x[i]+c*s1-s2; s2=s1; s1=s; } double p=s1*s1+s2*s2-c*s1*s2; return std::sqrt(std::max(0.0,p))/(b-a)*2; }
static double rms(const std::vector<float>&x,int a,int b){ double s=0; for(int i=a;i<b;i++) s+=x[i]*x[i]; return std::sqrt(s/(b-a)); }
static float st(FxEngine&e,int i){ float v[FxEngine::ST_COUNT]; e.readStatus(v,FxEngine::ST_COUNT); return v[i]; }
int main(){
  printf("== LOOPER\n");
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.0f); r.e.setParam(FxEngine::LOOP_LEVEL,0.79f); r.e.setParam(FxEngine::LOOP_FADE,0.0f);
    r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(2.0f,440,0.3f);
    r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(0.01f,0,0,true);
    printf("  state after close: %.0f  len %.3f s\n",st(r.e,0),st(r.e,2));
    CHECK(std::fabs(st(r.e,2)-2.0f)<0.02f,"recorded length ~2.0 s (got %.3f)",st(r.e,2));
    CHECK(st(r.e,0)==2.0f,"state == PLAY");
    int a=(int)r.L.size(); r.feed(4.0f,0,0,true); // input silent -> only loop is heard
    double a440=goertzel(r.L,a+2000,a+90000,440);
    CHECK(a440>0.2,"loop plays back the 440 Hz tone with silent input (amp %.3f)",a440);
    // period: compare sample at t and t+len
    int p1=a+10000, p2=p1+96000; double dd=0,nn=0; for(int i=0;i<4000;i++){ dd+=std::fabs(r.L[p1+i]-r.L[p2+i]); nn+=std::fabs(r.L[p1+i]); }
    CHECK(dd/nn<0.02,"loop repeats seamlessly each 2.0 s (rel diff %.4f)",dd/nn);
    // click check at loop boundary
    int bnd=a+96000-50; float mx=0; for(int i=0;i<100;i++) mx=std::max(mx,std::fabs(r.L[bnd+i]-r.L[bnd+i-1])); CHECK(mx<0.12f,"no click at loop point (max step %.3f)",mx);
    // overdub a 880 Hz tone for one full loop
    r.e.commandLooper(FxEngine::LOOP_MAIN); int b=(int)r.L.size(); r.feed(2.0f,880,0.2f); r.e.commandLooper(FxEngine::LOOP_MAIN); int c=(int)r.L.size(); r.feed(2.5f,0,0,true);
    CHECK(st(r.e,0)==2.0f,"back to PLAY after overdub");
    double o880=goertzel(r.L,c+2000,c+90000,880), o440=goertzel(r.L,c+2000,c+90000,440);
    CHECK(o880>0.1&&o440>0.2,"overdub layer audible alongside phrase (440: %.3f, 880: %.3f)",o440,o880); (void)b;
    r.e.commandLooper(FxEngine::LOOP_UNDO); r.feed(1.0f,0,0,true); int d=(int)r.L.size(); r.feed(1.5f,0,0,true);
    double u880=goertzel(r.L,d+2000,d+60000,880),u440=goertzel(r.L,d+2000,d+60000,440);
    CHECK(u880<0.01&&u440>0.2,"UNDO removes overdub, keeps phrase (440: %.3f, 880: %.4f)",u440,u880);
    r.e.commandLooper(FxEngine::LOOP_STOP); r.feed(1.0f,0,0,true); int e2=(int)r.L.size(); r.feed(1.0f,0,0,true);
    CHECK(rms(r.L,e2,e2+40000)<1e-4,"STOP silences loop; state=%.0f (4=stopped)",st(r.e,0));
    CHECK(r.e.loopHasAudio(),"loop retained after stop");
    r.e.commandLooper(FxEngine::LOOP_PLAY); r.feed(1.0f,0,0,true); int f2=(int)r.L.size()-30000; CHECK(rms(r.L,f2,f2+20000)>0.05,"PLAY resumes");
    r.e.commandLooper(FxEngine::LOOP_ERASE); r.feed(0.5f,0,0,true); CHECK(!r.e.loopHasAudio()&&st(r.e,0)==0.0f,"ERASE empties looper");
  }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.0f); r.e.setParam(FxEngine::LOOP_QUANTIZE,1); r.e.setParam(FxEngine::TEMPO,120);
    r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(2.3f,300,0.3f); r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(0.01f,0,0,true);
    CHECK(std::fabs(st(r.e,2)-2.5f)<0.01f,"QUANTIZE rounds 2.3 s to 5 beats = 2.5 s (got %.3f)",st(r.e,2)); }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.0f); r.e.setParam(FxEngine::LOOP_BURST,1);
    r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(0.5f,300,0.3f); r.e.commandLooper(FxEngine::LOOP_REC_RELEASE); r.feed(0.05f,0,0,true);
    CHECK(std::fabs(st(r.e,2)-0.5f)<0.01f&&st(r.e,0)==2.0f,"BURST: records while held, plays on release (len %.3f)",st(r.e,2));
    r.e.commandLooper(FxEngine::LOOP_DUB); r.feed(0.1f,0,0,true); CHECK(st(r.e,0)==2.0f,"BURST disables overdub"); }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.0f); r.e.setParam(FxEngine::LOOP_LEVEL,0.79f); r.e.setParam(FxEngine::LOOP_FADE,0.0f);
    r.e.commandLooper(FxEngine::LOOP_MAIN); r.feed(2.0f,300,0.3f); r.e.commandLooper(FxEngine::LOOP_MAIN); r.e.setParam(FxEngine::LOOP_SPEED,1.0f); r.feed(1.0f,0,0,true); int a=(int)r.L.size(); r.feed(1.0f,0,0,true);
    double s1200=goertzel(r.L,a+1000,a+40000,1200), s300=goertzel(r.L,a+1000,a+40000,300);
    CHECK(s1200>0.15&&s300<0.05,"looper speed max = 4x (300 Hz -> 1200 Hz: %.3f / %.3f)",s1200,s300);
    r.e.setParam(FxEngine::LOOP_SPEED,0.5f); r.e.setParam(FxEngine::LOOP_REVERSE,1); r.feed(1.0f,0,0,true); int b=(int)r.L.size(); r.feed(0.5f,0,0,true);
    CHECK(goertzel(r.L,b,b+20000,300)>0.2,"reverse playback still carries the tone"); }

  printf("== HOLD / BYPASS / TRAILS\n");
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,1.0f); r.e.setParam(FxEngine::EFFECT,0.3f); r.e.setParam(FxEngine::ACTIVITY,0.6f);
    r.feed(0.6f,330,0.3f); r.e.setHold(true); r.feed(0.05f,330,0.3f); r.feed(4.0f,0,0,true); int n=(int)r.L.size();
    double h=rms(r.L,n-48000,n); CHECK(h>0.02,"HOLD sustains material after input stops (rms %.4f)",h);
    r.e.setHold(false); r.feed(6.0f,0,0,true); n=(int)r.L.size(); CHECK(rms(r.L,n-24000,n)<0.003,"releasing HOLD lets it decay (rms %.5f)",rms(r.L,n-24000,n)); }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.5f); r.e.setParam(FxEngine::SPACE,0.8f); r.e.setParam(FxEngine::EFFECT,0.9f);
    r.feed(1.0f,330,0.3f); r.e.setParam(FxEngine::ENABLE,0); r.e.setParam(FxEngine::BYPASS_MODE,0); r.feed(0.05f,330,0.3f); int a=(int)r.L.size(); r.feed(0.5f,330,0.3f);
    double e=0; for(int i=0;i<2000;i++){ float ref=0.3f*std::sin(6.2831853*330*(float)(i)/SR); (void)ref; }
    // bypass (no trails): output must equal input exactly
    double dmax=0; Run q; (void)q; { Run z; z.e.setSampleRate(SR); z.e.setParam(FxEngine::ENABLE,0); z.feed(0.3f,330,0.3f); int m=(int)z.L.size(); dmax=0; for(int i=2000;i<m;i++){ float ref=0.3f*std::sin(6.2831853*330*(float)(i)/SR); dmax=std::max(dmax,(double)std::fabs(z.L[i]-ref)); } }
    CHECK(dmax<1e-5,"disengaged pedal is transparent (max dev %.2e)",dmax); (void)a;(void)e; }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,0.6f); r.e.setParam(FxEngine::SPACE,0.9f); r.e.setParam(FxEngine::REVERB_MODE,1.0f); r.e.setParam(FxEngine::BYPASS_MODE,0.5f);
    r.feed(1.0f,330,0.3f); r.e.setParam(FxEngine::ENABLE,0); r.feed(0.3f,0,0,true); int a=(int)r.L.size(); r.feed(1.0f,0,0,true);
    CHECK(rms(r.L,a,a+24000)>1e-3,"TRAILS: reverb tail rings after bypass (rms %.4f)",rms(r.L,a,a+24000));
    r.feed(30.0f,0,0,true); int n=(int)r.L.size(); CHECK(rms(r.L,n-4800,n)<1e-5,"tail eventually dies and engine idles"); }
  { Run r; r.e.setSampleRate(SR); r.e.setParam(FxEngine::ENABLE,1); r.e.setParam(FxEngine::MIX,1.0f); r.e.setParam(FxEngine::SPACE,1.0f); r.e.setParam(FxEngine::FILTER,1.0f);
    for(int m=0;m<4;m++){ r.e.setParam(FxEngine::REVERB_MODE,m/3.0f); r.feed(0.05f,0,0,true);
      std::vector<float> imp; for(int i=0;i<int(8*SR);i++){ float l=(i==0)?0.5f:0,rr=l; r.e.process(l,rr); imp.push_back(l); }
      // RT: time for envelope to drop 30 dB below early peak
      double pk=0; int pi=0; std::vector<double> env(imp.size()); double e=0; for(size_t i=0;i<imp.size();i++){ e=std::max<double>(std::fabs(imp[i]),e*0.9995); env[i]=e; if(e>pk){pk=e;pi=(int)i;} }
      int t30=-1; for(size_t i=pi;i<imp.size();i++) if(env[i]<pk*0.0316){ t30=(int)i-pi; break; }
      printf("  reverb mode %c: peak %.3f, -30 dB at %.2f s\n",'A'+m,pk,t30<0?9.99:t30/SR); }
  }

  printf("== STRESS (random params / effects / looper) at several sample rates\n");
  for(float sr: {44100.f,48000.f,96000.f}){
    SR=sr; FxEngine e; e.setSampleRate(sr); std::mt19937 g(42); std::uniform_real_distribution<float> U(0,1);
    long bad=0; float pk=0; int N=int(60*sr);
    e.setParam(FxEngine::ENABLE,1); double ph=0;
    for(int i=0;i<N;i++){
      if(i%int(0.1*sr)==0){ for(int id: {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,20,21,22,23,24,25,26,27,28,29}) e.setParam(id,U(g)); e.setParam(FxEngine::TEMPO,40+U(g)*220); e.setParam(FxEngine::ENABLE,U(g)>0.1f); e.setParam(FxEngine::FILTER,U(g)>0.3f?1.f:U(g)); if(U(g)<0.3f) e.commandLooper(int(U(g)*7.99f)); if(U(g)<0.05f) e.setHold(U(g)<0.5f); if(U(g)<0.2f) e.onsetHint(); }
      ph+=2*M_PI*(110+ 220*(i/int(sr*0.5)%4))/sr; float x=0.3f*std::sin(ph)*((i/int(sr*0.25))%2?1.f:0.2f); float l=x,r=x*0.9f; e.process(l,r);
      if(!std::isfinite(l)||!std::isfinite(r)) { bad++; l=r=0; } pk=std::max(pk,std::max(std::fabs(l),std::fabs(r))); }
    printf("  sr %.0f: non-finite=%ld peak=%.2f\n",sr,bad,pk); CHECK(bad==0&&pk<6.0f,"stress test stable at %.0f Hz",sr);
  }
  printf("\n%s (%d failures)\n",fails?"SOME TESTS FAILED":"ALL TESTS PASSED",fails); return fails?1:0; }
