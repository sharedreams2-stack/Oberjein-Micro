#include "fx_engine.h"
#include <cstdio>
#include <chrono>
#include <vector>
#include <string>
#include <cstring>
static const float SR=48000.f;
// synth-like source: saw plucks with decaying low-pass, then a chord pad, then silence
struct Src {
  float t=0; int n=0;
  struct V{float f=0,ph=0,env=0,lp=0,age=0; bool on=false;} v[6];
  void note(int i,float f){ v[i].f=f; v[i].env=1; v[i].age=0; v[i].on=true; }
  void next(float& l,float& r){
    float sec=n/SR;
    // plucks 0..4s every 0.5 s
    if(sec<4.f && (n % 24000)==0){ static const float fr[4]={130.8f,164.8f,196.0f,246.9f}; note((n/24000)%4,fr[(n/24000)%4]); }
    if(n==4*48000){ note(0,130.8f); note(1,164.8f); note(2,196.f); note(3,261.6f); }
    float a=0,b=0;
    for(int i=0;i<6;i++){ auto&x=v[i]; if(!x.on) continue;
      x.ph+=x.f/SR; if(x.ph>=1) x.ph-=1;
      float saw=2*x.ph-1; float pad = sec>=4.f;
      float envv = pad? (sec<6.f? 1.f : std::max(0.f,1.f-(sec-6.f)*4.f)) : std::exp(-x.age*5.f);
      x.age+=1.f/SR; float cut = pad?0.2f:0.05f+0.4f*std::exp(-x.age*12.f);
      x.lp+=cut*(saw-x.lp);
      float o=x.lp*envv*0.25f; a+=o*(1.f-0.1f*i); b+=o*(0.9f+0.1f*i);
      if(envv<1e-4f) x.on=false; }
    l=a; r=b; n++; }
};
struct Res{ double peak=0, rmsWet=0, rmsDry=0, tail=0; long nan=0; double cent=0; };
static void setup(FxEngine&e,int fx,int var){
  e.setSampleRate(SR);
  e.setParam(FxEngine::ENABLE,1); e.setParam(FxEngine::EFFECT,fx/10.f); e.setParam(FxEngine::VARIATION,var/3.f);
  e.setParam(FxEngine::MIX,1.0f); e.setParam(FxEngine::SPACE,0.0f); e.setParam(FxEngine::FILTER,1.0f);
  e.setParam(FxEngine::ACTIVITY,0.6f); e.setParam(FxEngine::REPEATS,0.5f); e.setParam(FxEngine::SHAPE,0.5f);
  e.setParam(FxEngine::TEMPO,120); e.setParam(FxEngine::TIME,0.4f); e.setParam(FxEngine::FX_MASTER,0.8f);
}
int main(int argc,char**argv){
  std::string mode = argc>1? argv[1]:"all";
  if(mode=="all"){
    FILE* csv=fopen("metrics.csv","w");
    fprintf(csv,"fx,var,peak,rms_wet,rms_dry,tail_rms,nan,cpu_x\n");
    for(int fx=0;fx<11;fx++) for(int var=0;var<4;var++){
      FxEngine e; setup(e,fx,var);
      Src s; int N=int(11*SR); std::vector<int16_t> out; out.reserve(N*2);
      double sw=0,sd=0,tl=0; long nan=0; float pk=0; long cw=0,ct=0;
      auto t0=std::chrono::high_resolution_clock::now();
      for(int i=0;i<N;i++){ float l,r; s.next(l,r); float dl=l,dr=r; e.process(l,r);
        if(!std::isfinite(l)||!std::isfinite(r)){nan++; l=r=0;}
        pk=std::max(pk,std::max(std::fabs(l),std::fabs(r)));
        if(i<9*SR){ sw+=l*l+r*r; sd+=dl*dl+dr*dr; cw++; }
        if(i>=10*SR){ tl+=l*l+r*r; ct++; }
        out.push_back((int16_t)std::clamp(l*32767.f,-32768.f,32767.f)); out.push_back((int16_t)std::clamp(r*32767.f,-32768.f,32767.f)); }
      double secs=std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-t0).count();
      fprintf(csv,"%d,%d,%.4f,%.5f,%.5f,%.6f,%ld,%.4f\n",fx,var,pk,std::sqrt(sw/(2*cw)),std::sqrt(sd/(2*cw)),std::sqrt(tl/(2*ct)),nan,secs/11.0);
      char fn[128]; snprintf(fn,128,"out_%d_%d.raw",fx,var); FILE*f=fopen(fn,"wb"); fwrite(out.data(),2,out.size(),f); fclose(f);
    }
    fclose(csv);
  }
  return 0; }
