import numpy as np
from scipy.signal import stft
SR=48000
names=['MOSAIC','SEQ','GLIDE','HAZE','TUNNEL','STRUM','BLOCKS','INTERRUPT','ARP','PATTERN','WARP']
def load(fx,v):
    a=np.fromfile(f'out_{fx}_{v}.raw',dtype=np.int16).astype(np.float32)/32768
    return a.reshape(-1,2)
def logspec(x):
    f,t,Z=stft(x,fs=SR,nperseg=4096,noverlap=3072)
    return f,t,np.log10(np.abs(Z)+1e-5)
def bands(x, lo, hi):
    f,t,Z=stft(x,fs=SR,nperseg=8192)
    P=np.abs(Z)**2; m=(f>=lo)&(f<hi); return P[m].sum()/P.sum()
print("== band energy share (mono, whole render): <110 Hz | 110-300 | 300-700 | 700-2k | >2k")
def share(x):
    return [bands(x,lo,hi) for lo,hi in [(0,110),(110,300),(300,700),(700,2000),(2000,24000)]]
# dry reference
import subprocess
for fx in range(11):
    row=[]
    for v in range(4):
        x=load(fx,v).mean(1)
        s=share(x); row.append(s)
    print(names[fx])
    for v in range(4): print('  ','ABCD'[v],' '.join('%5.1f%%'%(100*q) for q in row[v]))
# pairwise dissimilarity of log spectrograms between variations of one effect (0=identical, higher = more different)
print("\n== mean |logspec diff| between variations (dB-ish; <0.05 means near identical)")
for fx in range(11):
    S=[logspec(load(fx,v).mean(1))[2] for v in range(4)]
    d=[]
    for i in range(4):
        for j in range(i+1,4):
            d.append(np.mean(np.abs(S[i]-S[j])))
    print('%-9s'%names[fx],' '.join('%.2f'%q for q in d),' min=%.2f'%min(d))
