import csv, math, re, ast
p='../../Oberjein/app/src/main/cpp/fx_engine_body.inc'
s=open(p).read()
m=re.search(r'static constexpr float kCalDb\[11\]\[4\] = \{(.*?)\};',s,re.S)
cur=[[float(x) for x in re.findall(r'-?\d+\.?\d*(?=f)',row)] for row in re.findall(r'\{(.*?)\}',m.group(1))]
rows=list(csv.DictReader(open('metrics.csv')))
worst=0
for r in rows:
    fx,v=int(r['fx']),int(r['var'])
    w=float(r['rms_wet']);d=float(r['rms_dry']); db=20*math.log10(max(w,1e-9)/d)
    tgt=-7.0 if fx not in (6,7,9,10) else -4.0
    if fx in (6,7): continue   # pass-through designs: keep natural level
    cur[fx][v]=round(max(-12,min(26,cur[fx][v]+tgt-db)),1); worst=max(worst,abs(tgt-db))
rowsS=',\n'.join('    {'+', '.join('%.1ff'%x for x in row)+'}' for row in cur)
s=s[:m.start()]+'static constexpr float kCalDb[11][4] = {\n'+rowsS+'};'+s[m.end():]
open(p,'w').write(s); print('worst dev before this update: %.1f dB'%worst)
