// Host tests for the native arpeggiator (arp.h). Build:  g++ -std=c++17 -O2 -I<cpp dir> -o test_arp test_arp.cpp
#include "arp.h"
#include <cstdio>
#include <cstdlib>
#include <map>
#include <random>
#include <vector>
using namespace ob;
static int fails = 0;
#define CHECK(c, msg, ...) do { if (!(c)) { printf("  FAIL: " msg "\n", ##__VA_ARGS__); ++fails; } else printf("  ok:   " msg "\n", ##__VA_ARGS__); } while (0)
static const float SR = 48000.f;

struct Ev { int64_t t; bool on; int note; float vel; };
struct Rig : ArpSink {
    Arp arp; std::vector<Ev> log; int64_t now = 0; std::map<int,int> sounding; float mod[kArpMaxParams] = {}; int modeChanges = 0; bool lastMode = false;
    Rig() { arp.setSink(this); arp.setSampleRate(SR); }
    void arpNoteOn(int n, float v) override { log.push_back({now, true, n, v}); sounding[n] = 1; }   // same pitch twice = retrigger of one voice
    void arpNoteOff(int n) override { log.push_back({now, false, n, 0}); sounding[n] = 0; }
    void arpMod(int id, float v) override { mod[id] = v; }
    void arpModeChanged(bool e) override { ++modeChanges; lastMode = e; }
    void run(double seconds) { const int64_t n = (int64_t)(seconds * SR); for (int64_t i = 0; i < n; ++i) { if (now % 192 == 0) arp.applyStaged(); arp.tick(); ++now; } }
    std::vector<int> ons() const { std::vector<int> v; for (auto& e : log) if (e.on) v.push_back(e.note); return v; }
    std::vector<int64_t> onTimes() const { std::vector<int64_t> v; for (auto& e : log) if (e.on) v.push_back(e.t); return v; }
    int stuck() const { int s = 0; for (auto& kv : sounding) s += kv.second > 0; return s; }
};
static ArpConfigData base() { ArpConfigData c; c.enabled = true; c.bpm = 120; c.division = 16; return c; }   // 16th at 120 = 125 ms
static bool eq(const std::vector<int>& a, std::initializer_list<int> b, size_t n) { if (a.size() < n) return false; size_t i = 0; for (int x : b) { if (i >= n) break; if (a[i++] != x) return false; } return true; }

int main() {
  printf("== timing is sample-exact (no drift, no jitter)\n");
  { Rig r; auto c = base(); r.arp.stage(c); r.arp.keyOn(60); r.run(0.01); r.arp.keyOn(64); r.run(20.0);
    auto t = r.onTimes(); double step = SR * 0.125; double maxDev = 0; for (size_t i = 1; i < t.size(); ++i) maxDev = std::max(maxDev, std::fabs((double)(t[i] - t[0]) - step * (double)i));
    printf("  %zu notes in 20 s, max deviation from the ideal grid: %.2f samples\n", t.size(), maxDev);
    CHECK(maxDev <= 2.0, "no drift over 20 s (max %.2f samples = %.3f ms)", maxDev, maxDev / SR * 1000);
    CHECK(t.size() >= 158 && t.size() <= 162, "~160 notes in 20 s at 16ths/120 bpm"); }

  printf("== first key starts the pattern immediately (playability)\n");
  { Rig r; auto c = base(); r.arp.stage(c); r.run(0.3); r.log.clear(); int64_t t0 = r.now; r.arp.keyOn(60); r.run(0.05);
    CHECK(!r.log.empty() && r.log[0].on && r.log[0].t - t0 <= 2, "first note within %lld samples of the key press", r.log.empty() ? -1LL : (long long)(r.log[0].t - t0)); }

  printf("== directions\n");
  struct D { int dir; std::vector<int> exp; const char* n; } ds[] = {
    {ARP_UP, {60,64,67,60,64,67}, "UP"}, {ARP_DOWN, {67,64,60,67,64,60}, "DOWN"}, {ARP_UP_DOWN, {60,64,67,64,60,64}, "UP_DOWN"},
    {ARP_DOWN_UP, {67,64,60,64,67,64}, "DOWN_UP"}};
  for (auto& d : ds) { Rig r; auto c = base(); c.direction = d.dir; r.arp.stage(c); r.run(0.01); r.arp.keyOn(67); r.arp.keyOn(60); r.arp.keyOn(64); r.run(1.0);
    auto o = r.ons(); std::vector<int> e = d.exp; bool ok = o.size() >= 6; for (size_t i = 0; ok && i < 6; ++i) ok = o[i] == e[i];
    CHECK(ok, "%s sequence %d,%d,%d,%d,%d,%d", d.n, o.size()>0?o[0]:-1,o.size()>1?o[1]:-1,o.size()>2?o[2]:-1,o.size()>3?o[3]:-1,o.size()>4?o[4]:-1,o.size()>5?o[5]:-1); }
  { Rig r; auto c = base(); c.direction = ARP_AS_PLAYED; c.octaveRange = 2; r.arp.stage(c); r.run(0.01); r.arp.keyOn(67); r.arp.keyOn(60); r.arp.keyOn(64); r.run(1.0);
    CHECK(eq(r.ons(), {67,60,64,79,72,76}, 6), "AS_PLAYED keeps press order and now honours the octave range"); }
  { Rig r; auto c = base(); c.octaveRange = 3; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.arp.keyOn(64); r.run(2.0);
    CHECK(eq(r.ons(), {60,64,72,76,84,88,60}, 7), "UP over 3 octaves"); }

  printf("== latch (HOLD)\n");
  { Rig r; auto c = base(); c.hold = true; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.arp.keyOff(60); r.arp.keyOn(64); r.arp.keyOff(64); r.run(1.0);
    auto o = r.ons(); CHECK(eq(o, {60,64,60,64}, 4), "notes keep playing after key release");
    r.arp.keyOn(60); r.log.clear(); r.run(1.0); auto o2 = r.ons(); bool only64 = !o2.empty(); for (int n : o2) only64 &= n == 64;
    CHECK(only64, "pressing a latched key again removes just that pitch"); }
  { Rig r; auto c = base(); r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.arp.keyOn(64); r.run(0.5);
    c.hold = true; r.arp.stage(c); r.run(0.01); r.arp.keyOff(60); r.arp.keyOff(64); r.log.clear(); r.run(0.6);
    CHECK(r.ons().size() >= 3, "enabling HOLD while keys are down latches them");
    c.hold = false; r.arp.stage(c); r.run(0.3); r.log.clear(); r.run(0.6); CHECK(r.ons().empty(), "disabling HOLD releases the latched notes"); }

  printf("== CHROMATIC mode: the arp keeps going\n");
  { Rig r; auto c = base(); c.scale = 0; c.division = 32; c.bpm = 180; r.arp.stage(c); r.run(0.01);
    std::mt19937 g(5); int pressed[16]; int np = 0; std::vector<double> gaps; int64_t lastOn = 0; size_t seen = 0; long silentWithKeys = 0;
    for (int blk = 0; blk < 4000; ++blk) {            // ~16 s of random playing, a key change every ~50 ms
      if (g() % 10 < 4) { if (np < 8 && (g() % 3)) { int n = 40 + g() % 40; bool dup = false; for (int i = 0; i < np; ++i) dup |= pressed[i] == n; if (!dup) { pressed[np++] = n; r.arp.keyOn(n); } }
                          else if (np > 0) { int i = g() % np; r.arp.keyOff(pressed[i]); pressed[i] = pressed[--np]; } }
      r.run(0.004);
      auto t = r.onTimes(); if (t.size() > seen) { lastOn = t.back(); seen = t.size(); }
      if (np > 0 && r.now - lastOn > (int64_t)(0.5 * SR)) ++silentWithKeys;      // keys down but nothing played for half a second
    }
    CHECK(silentWithKeys == 0, "never silent for >0.5 s while keys are held (chromatic, random key changes, 32nds @180 bpm)");
    for (int i = 0; i < np; ++i) r.arp.keyOff(pressed[i]); r.run(1.0); CHECK(r.stuck() == 0, "no stuck notes after all keys are released"); }
  { Rig r; auto c = base(); c.scale = 0; c.root = 7; c.intervalShift = -3; c.chordSize = 3; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.3);
    auto o = r.ons(); CHECK(o.size() >= 3 && o[0] == 60 - 3 && o[1] == 60 - 3 + 4 && o[2] == 60 - 3 + 7, "chromatic + root + shift + chord size 3 -> major triad %d,%d,%d", o.size()>0?o[0]:-1,o.size()>1?o[1]:-1,o.size()>2?o[2]:-1); }

  printf("== scales and chords\n");
  { Rig r; auto c = base(); c.scale = 1; c.chordSize = 3; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.05); auto o = r.ons();
    CHECK(eq(o, {60,64,67}, 3), "C major, 3 notes = C E G (was C D E before the fix)"); }
  { Rig r; auto c = base(); c.scale = 2; c.chordSize = 4; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.05); auto o = r.ons();
    CHECK(eq(o, {60,63,67,70}, 4), "C minor, 4 notes = C Eb G Bb"); }
  { Rig r; auto c = base(); c.scale = 1; r.arp.stage(c); r.run(0.01); r.arp.keyOn(61); r.run(0.05); CHECK(eq(r.ons(), {60}, 1) || eq(r.ons(), {62}, 1), "out-of-scale note snaps into C major"); }

  printf("== ratchets, strum, gate, humanize\n");
  { Rig r; auto c = base(); c.steps[0].ratchets = 4; c.steps[0].gate = 0.5f; c.loopLength = 1; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.13);
    auto t = r.onTimes(); CHECK(t.size() >= 4, "ratchets=4 -> 4 hits in one step (%zu)", t.size());
    double sp = t.size() >= 2 ? (double)(t[1] - t[0]) / SR * 1000 : 0; CHECK(std::fabs(sp - 31.25) < 1.0, "ratchet spacing %.2f ms (expected 31.25)", sp); }
  { Rig r; auto c = base(); c.chordSize = 3; c.scale = 1; c.strumMs = 20; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.1);
    auto t = r.onTimes(); CHECK(t.size() >= 3 && std::fabs((double)(t[1] - t[0]) / SR * 1000 - 20) < 0.5 && std::fabs((double)(t[2] - t[1]) / SR * 1000 - 20) < 0.5, "strum spaces chord notes by 20 ms"); }
  { Rig r; auto c = base(); c.steps[0].gate = 0.5f; c.loopLength = 1; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.3);
    int64_t on = -1, off = -1; for (auto& e : r.log) { if (e.on && on < 0) on = e.t; if (!e.on && off < 0) off = e.t; } CHECK(std::fabs((double)(off - on) / SR * 1000 - 62.5) < 1.0, "gate 50%% of a 125 ms step = 62.5 ms (got %.2f)", (double)(off - on) / SR * 1000); }
  { Rig r; auto c = base(); c.humanize = 1.0f; r.arp.stage(c); r.run(0.01); int64_t t0 = r.now; r.arp.keyOn(60); r.run(10.0);
    auto t = r.onTimes(); double mx = 0, mn = 1e9; for (size_t i = 0; i < t.size(); ++i) { double d = (double)(t[i] - t0) - SR * 0.125 * i; mx = std::max(mx, d); mn = std::min(mn, d); }
    CHECK(mn > -3 && mx < SR * 0.125 * 0.18 + 3, "humanize only delays notes, bounded by 18%% of a step, grid stays exact (%.1f..%.1f samples)", mn, mx); }
  { Rig r; auto c = base(); c.steps[1].enabled = 0; c.loopLength = 2; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(1.0); CHECK(r.ons().size() >= 3 && r.ons().size() <= 5, "disabled step is skipped (%zu notes in 1 s)", r.ons().size()); }

  printf("== modulation routes\n");
  { Rig r; auto c = base(); c.nRoutes = 1; c.routes[0] = {SRC_VELOCITY, 5, 0.5f, false}; c.steps[0].velocity = 0.8f; c.loopLength = 1; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(0.05);
    CHECK(std::fabs(r.mod[5] - 0.4f) < 1e-4, "route VELOCITY->param 5 applies %.3f", r.mod[5]);
    r.arp.keyOff(60); r.run(0.3); CHECK(r.mod[5] == 0.0f, "modulation returns to 0 when nothing is playing"); }

  printf("== enable / disable / panic\n");
  { Rig r; auto c = base(); r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.arp.keyOn(64); r.run(1.0); c.enabled = false; r.arp.stage(c); r.run(0.3);
    CHECK(r.stuck() == 0 && !r.arp.isRunning(), "disabling the arp releases every note"); CHECK(r.modeChanges == 2 || r.modeChanges == 1, "mode-change notifications (%d)", r.modeChanges); }
  { Rig r; auto c = base(); c.steps[0].gate = 1.0f; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.arp.keyOn(64); r.run(0.5); r.arp.requestPanic(); r.run(0.01);
    CHECK(r.stuck() == 0, "panic silences everything"); r.log.clear(); r.run(0.5); CHECK(r.ons().empty(), "panic also clears held keys"); }

  printf("== evolve publishes mutated steps\n");
  { Rig r; auto c = base(); c.evolve = true; c.randomMode = true; r.arp.stage(c); r.run(0.01); r.arp.keyOn(60); r.run(20.0); CHECK(r.arp.mutationCount() > 5, "pattern mutates and reports it (%d mutations)", r.arp.mutationCount());
    float out[kArpSteps * kArpStepFields]; r.arp.readSteps(out); bool changed = false; for (int i = 0; i < kArpSteps; ++i) changed |= out[i * kArpStepFields + 1] < 0.999f || out[i * kArpStepFields + 2] > 1.0f; CHECK(changed, "mutated steps are readable by the UI"); }

  printf("== stress: random config changes, keys, panics (no stuck notes, no crash)\n");
  { Rig r; std::mt19937 g(9); auto c = base(); r.arp.stage(c); long cfgChanges = 0;
    for (int blk = 0; blk < 12000; ++blk) {
      if (g() % 20 == 0) { c.enabled = g() % 8 != 0; c.hold = g() % 4 == 0; c.direction = g() % 6; c.octaveRange = 1 + g() % 4; c.scale = g() % 7; c.root = g() % 12; c.chordSize = 1 + g() % 8; c.strumMs = g() % 60;
        c.division = (int[]){1,2,4,8,16,32}[g() % 6]; c.bpm = 30 + g() % 271; c.humanize = (g() % 100) / 100.f; c.loopLength = 1 + g() % 64; c.intervalShift = (int)(g() % 13) - 6; c.randomMode = g() % 5 == 0; c.evolve = g() % 5 == 0;
        for (int i = 0; i < 64; ++i) { c.steps[i].ratchets = 1 + g() % 8; c.steps[i].gate = (g() % 101) / 100.f; c.steps[i].enabled = g() % 6 != 0; c.steps[i].probability = (g() % 101) / 100.f; c.steps[i].octave = (int)(g() % 5) - 2; }
        c.nRoutes = g() % 4; for (int k = 0; k < c.nRoutes; ++k) c.routes[k] = {(int)(g() % 5), (int)(g() % 60), 0.3f, g() % 2 == 0};
        r.arp.stage(c); ++cfgChanges; }
      if (g() % 5 == 0) r.arp.keyOn(30 + g() % 70); if (g() % 5 == 0) r.arp.keyOff(30 + g() % 70); if (g() % 700 == 0) r.arp.requestPanic();
      r.run(0.004); }
    c.enabled = false; r.arp.stage(c); r.run(2.0);
    printf("  %ld config changes, %zu note events\n", cfgChanges, r.log.size()); CHECK(r.stuck() == 0, "no stuck notes after disabling"); }

  printf("\n%s (%d failures)\n", fails ? "SOME TESTS FAILED" : "ALL ARP TESTS PASSED", fails); return fails ? 1 : 0; }
