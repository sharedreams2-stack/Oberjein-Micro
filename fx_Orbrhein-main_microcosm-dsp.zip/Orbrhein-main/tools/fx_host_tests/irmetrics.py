import numpy as np, sys
SR=48000; tag=sys.argv[1]
names=['A bright room','B dark medium','C large hall','D ambient']
def ned(x, win=int(0.02*SR)):
    # normalized echo density (Abel & Huang): fraction of samples outside 1 std, normalised by Gaussian value 0.3173
    out=[]
    for s in range(0,int(0.5*SR),win//2):
        seg=x[s:s+win]; sd=seg.std()+1e-12; out.append(np.mean(np.abs(seg)>sd)/0.3173)
    return np.array(out)
def logspec(seg):
    w=np.hanning(len(seg)); S=np.abs(np.fft.rfft(seg*w))**2
    f=np.fft.rfftfreq(len(seg),1/SR); m=(f>200)&(f<6000)
    return f[m],10*np.log10(S[m]+1e-20)
def persistence(x):
    # tonal/modal ringing: correlation of fine spectral structure between two late windows
    a=x[int(0.25*SR):int(0.25*SR)+32768]; b=x[int(0.9*SR):int(0.9*SR)+32768]
    fa,A=logspec(a); fb,B=logspec(b)
    k=15; sm=lambda v: np.convolve(v,np.ones(k)/k,mode='same')
    A=A-sm(A); B=B-sm(B)
    return np.corrcoef(A,B)[0,1], A.std()
for m in range(4):
    d=np.fromfile(f'ir_{tag}_{m}.raw',dtype=np.float32).reshape(2,-1); x=d[0]
    n=ned(x); t=np.arange(len(n))*0.01
    mix=t[np.argmax(n>0.9)] if (n>0.9).any() else 9
    c,sd=persistence(x)
    inter=np.corrcoef(d[0][:int(1*SR)],d[1][:int(1*SR)])[0,1]
    print(f'{names[m]:14s} mixing-time(NED>0.9) {mix*1000:5.0f} ms | modal persistence {c:5.2f} | fine-structure std {sd:4.1f} dB | L/R corr {inter:5.2f}')
