# FX engine host tests

The FX engine (`Oberjein/app/src/main/cpp/fx_engine.h`, `fx_engine_body.inc`, `fx_dsp.h`) is plain C++17 with
no Android dependencies, so it can be built and tested on a PC. None of this is part of the Gradle build.

```bash
CPP=../../Oberjein/app/src/main/cpp
g++ -std=c++17 -O2 -I$CPP -o fxtest fxtest.cpp && ./fxtest all       # renders 44 variations -> metrics.csv + out_*.raw
g++ -std=c++17 -O2 -I$CPP -o test2  test2.cpp  && ./test2            # looper / hold / bypass / trails / reverb / stress
g++ -std=c++17 -O2 -I$CPP -o synthtest synthtest.cpp && ./synthtest  # real Synth + FX, end to end
g++ -std=c++17 -O2 -I$CPP -o test_arp test_arp.cpp && ./test_arp               # native arpeggiator: timing, directions, latch, chromatic continuity, chords, stress
g++ -std=c++17 -O2 -I$CPP -o test_synth_arp test_synth_arp.cpp && ./test_synth_arp   # real Synth + arp: mode switching, modulation routes, overload
g++ -std=c++17 -O2 -I$CPP -o synthbench synthbench.cpp && ./synthbench          # CPU cost of the synth core (% of one core)
python3 analyze.py     # band-energy share and variation-to-variation spectral difference
python3 spec.py        # spectrogram grid -> spec.png
g++ -std=c++17 -O2 -I$CPP -o revir revir.cpp && ./revir new && python3 irmetrics.py new   # reverb: echo density, ripple, L/R correlation
python3 recal.py       # re-derives the per-effect output trims (kCalDb) from metrics.csv
```

`test2` checks: loop length, seamless repeat and no click at the loop point, overdub layer, undo, stop/play/erase,
quantize rounding, burst, 4x speed, hold sustain and release, transparent bypass, trails, reverb modes, and a
60 s random-parameter stress test at 44.1 / 48 / 96 kHz (no NaN/Inf, bounded peak).
