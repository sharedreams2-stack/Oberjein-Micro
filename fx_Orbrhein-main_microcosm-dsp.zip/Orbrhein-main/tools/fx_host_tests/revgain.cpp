#include "fx_engine.h"
#include <cstdio>
#include <random>
int main(){ for(int m=0;m<4;m++){ FxEngine e; e.setSampleRate(48000); e.setParam(FxEngine::ENABLE,1); e.setParam(FxEngine::MIX,1); e.setParam(FxEngine::SPACE,1); e.setParam(FxEngine::EFFECT,0.9f); e.setParam(FxEngine::ACTIVITY,0.f); e.setParam(FxEngine::REVERB_MODE,m/3.f); e.setParam(FxEngine::REPEATS,0); e.setParam(FxEngine::FX_MASTER,0.5f);
  std::mt19937 g(1); std::normal_distribution<float> N(0,0.1f); double si=0,so=0; int n=0;
  for(int i=0;i<48000*6;i++){ float l=N(g),r=N(g); float il=l,ir=r; e.process(l,r); if(i>48000*2){ si+=il*il+ir*ir; so+=l*l+r*r; n++; } }
  printf("mode %c: out/in rms = %.2f (%.1f dB)\n",'A'+m,std::sqrt(so/si),10*std::log10(so/si)); } }
