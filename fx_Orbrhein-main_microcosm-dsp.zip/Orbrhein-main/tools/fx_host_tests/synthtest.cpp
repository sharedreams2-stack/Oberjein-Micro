#include "synth.h"
#include <cstdio>
#include <vector>
#include <chrono>
int main(){
  const float SR=48000; int bad=0;
  for(int fx=0; fx<11; ++fx) for(int var=0; var<4; var+=3){
    ob::Synth s; s.setSampleRate(SR);
    s.setParam(ob::P_VCO1_SAW,1); s.setParam(ob::P_VCO1_LEVEL,0.8f); s.setParam(ob::P_VCO2_SAW,1); s.setParam(ob::P_VCO2_LEVEL,0.8f); s.setParam(ob::P_VCO2_SEMI,0.5f);
    s.setParam(ob::P_CUTOFF,0.65f); s.setParam(ob::P_A_A,0.02f); s.setParam(ob::P_A_D,0.5f); s.setParam(ob::P_A_S,0.8f); s.setParam(ob::P_A_R,0.35f); s.setParam(ob::P_VOLUME,0.7f); s.setParam(ob::P_VOICE_COUNT,1.f);
    s.setFxParam(FxEngine::ENABLE,1); s.setFxParam(FxEngine::EFFECT,fx/10.f); s.setFxParam(FxEngine::VARIATION,var/3.f);
    s.setFxParam(FxEngine::MIX,0.6f); s.setFxParam(FxEngine::SPACE,0.4f); s.setFxParam(FxEngine::ACTIVITY,0.7f); s.setFxParam(FxEngine::REPEATS,0.6f);
    std::vector<float> buf(2*512); double e=0; float pk=0; long n=0, nan=0;
    auto t0=std::chrono::high_resolution_clock::now();
    for(int blk=0; blk<(int)(6*SR/512); ++blk){
      if(blk%47==0) s.noteOn(48+ (blk/47)%5*4, 0.8f);
      if(blk%47==30) s.noteOff(48+ (blk/47)%5*4);
      s.render(buf.data(),512);
      for(float x: buf){ if(!std::isfinite(x)) nan++; else { pk=std::max(pk,std::fabs(x)); e+=x*x; n++; } } }
    double secs=std::chrono::duration<double>(std::chrono::high_resolution_clock::now()-t0).count();
    float st[9]; s.fxReadStatus(st,9);
    printf("fx %2d var %d: rms %.3f peak %.2f nan %ld onsets %.0f cpu %.1f%%\n",fx,var,std::sqrt(e/n),pk,nan,st[7],secs/6*100);
    bad+=nan;
  }
  printf(bad? "FAIL\n":"integration OK\n"); return bad!=0; }
